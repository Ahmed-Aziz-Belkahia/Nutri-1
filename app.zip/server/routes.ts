import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { db } from "@db";
import { users, recipes } from "@db/schema";
import { eq, desc } from "drizzle-orm";

export function registerRoutes(app: Express): Server {
  setupAuth(app);

  // Get user's recipes
  app.get("/api/recipes", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ error: 'Authentication required' });
      }

      // Get only recipes created by the authenticated user
      const userRecipes = await db.select({
        id: recipes.id,
        name: recipes.name,
        description: recipes.description,
        ingredients: recipes.ingredients,
        instructions: recipes.instructions,
        nutritionInfo: recipes.nutritionInfo,
        imageUrl: recipes.imageUrl,
        isPublic: recipes.isPublic,
        likesCount: recipes.likesCount,
        createdAt: recipes.createdAt,
      })
        .from(recipes)
        .where(eq(recipes.userId, req.user.id))
        .orderBy(desc(recipes.createdAt));

      res.json(userRecipes);
    } catch (error) {
      console.error('Error fetching recipes:', error);
      res.status(500).json({
        error: 'Failed to fetch recipes',
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  // Get global top recipes sorted by likes
  app.get("/api/recipes/top", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ error: 'Authentication required' });
      }

      // Get public recipes sorted by likes
      const topRecipes = await db
        .select({
          id: recipes.id,
          name: recipes.name,
          description: recipes.description,
          ingredients: recipes.ingredients,
          instructions: recipes.instructions,
          nutritionInfo: recipes.nutritionInfo,
          imageUrl: recipes.imageUrl,
          isPublic: recipes.isPublic,
          likesCount: recipes.likesCount,
          createdAt: recipes.createdAt,
        })
        .from(recipes)
        .where(eq(recipes.isPublic, true))
        .orderBy(desc(recipes.likesCount))
        .limit(10);

      res.json(topRecipes);
    } catch (error) {
      console.error('Error fetching top recipes:', error);
      res.status(500).json({
        error: 'Failed to fetch top recipes',
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  // Health check endpoint
  app.get("/api/health", (req, res) => {
    res.json({ status: "healthy" });
  });

  // Recipe generation endpoint
  app.post("/api/generate-recipe", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ error: 'Authentication required' });
      }

      const { mealType, calories, budget, days } = req.body;
      if (!mealType || !calories || !budget || !days) {
        return res.status(400).json({ error: 'Missing required fields' });
      }

      // Generate ingredients based on meal type and calories
      const generateIngredients = (mealType: string, targetCalories: number) => {
        const ingredients = [];
        let totalPrice = 0;
        let currentCalories = 0;

        type MealType = 'Breakfast' | 'Lunch' | 'Dinner' | 'Snack' | 'Dessert';
        const mealTypeIngredients: Record<MealType, string[]> = {
          'Breakfast': ['eggs', 'milk', 'bread', 'butter'],
          'Lunch': ['chicken breast', 'rice', 'vegetables'],
          'Dinner': ['pasta', 'ground beef', 'tomatoes', 'cheese'],
          'Snack': ['fruits', 'nuts', 'yogurt'],
          'Dessert': ['flour', 'sugar', 'butter', 'eggs']
        };

        const baseIngredients = mealTypeIngredients[mealType as MealType] || [];
        for (const ingredient of baseIngredients) {
          const price = ingredientPrices[ingredient] || 1.99;
          if (totalPrice + price <= budget) {
            ingredients.push(ingredient);
            totalPrice += price;
            currentCalories += 100; // Simplified calorie calculation
          }
        }

        return {
          ingredients,
          totalPrice: parseFloat(totalPrice.toFixed(2)),
          estimatedCalories: currentCalories
        };
      };

      const recipe = generateIngredients(mealType, calories);

      // Generate instructions based on ingredients
      const instructions = `1. Gather all ingredients: ${recipe.ingredients.join(', ')}\n` +
        `2. Prepare ingredients\n` +
        `3. Cook according to your preferences\n` +
        `4. Serve and enjoy!`;

      const response = {
        name: `Custom ${mealType} Recipe`,
        description: `A ${mealType.toLowerCase()} recipe designed for ${calories} calories and $${budget} budget`,
        ingredients: recipe.ingredients,
        instructions,
        nutritionInfo: {
          calories: recipe.estimatedCalories,
          protein: Math.round(recipe.estimatedCalories * 0.2 / 4), // 20% protein
          carbs: Math.round(recipe.estimatedCalories * 0.5 / 4),   // 50% carbs
          fat: Math.round(recipe.estimatedCalories * 0.3 / 9),     // 30% fat
        },
        estimatedPrice: recipe.totalPrice,
        daysPlanned: days
      };

      // Save the generated recipe
      const [savedRecipe] = await db.insert(recipes).values({
        userId: req.user.id,
        name: response.name,
        description: response.description,
        ingredients: response.ingredients,
        instructions: response.instructions,
        nutritionInfo: response.nutritionInfo,
        isPublic: true,
        likesCount: 0,
        commentsCount: 0,
      }).returning();

      res.json({ ...response, id: savedRecipe.id });
    } catch (error) {
      console.error('Recipe Generation Error:', error);
      res.status(500).json({
        error: 'Failed to generate recipe',
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  // Create sample recipes
  app.post("/api/sample-recipes", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ error: 'Authentication required' });
      }

      const sampleRecipes = [
        {
          name: "High-Protein Breakfast Bowl",
          description: "A nutritious breakfast bowl perfect for muscle recovery and energy",
          ingredients: [
            "2 large eggs",
            "1 cup quinoa",
            "1 avocado",
            "Cherry tomatoes",
            "Baby spinach",
            "Extra virgin olive oil",
            "Salt and pepper"
          ],
          instructions: "1. Cook quinoa according to package instructions\n2. Poach eggs until whites are set\n3. Slice avocado and tomatoes\n4. Arrange quinoa, eggs, avocado, tomatoes, and spinach in a bowl\n5. Drizzle with olive oil\n6. Season with salt and pepper",
          nutritionInfo: {
            calories: 450,
            protein: 20,
            carbs: 35,
            fat: 28
          },
          isPublic: true,
          imageUrl: "https://images.unsplash.com/photo-1607532941433-304659e8198a?w=800&auto=format&fit=crop"
        },
        {
          name: "Mediterranean Chicken Salad",
          description: "Light and fresh salad with lean protein",
          ingredients: [
            "200g chicken breast",
            "Mixed greens",
            "Cherry tomatoes",
            "Cucumber",
            "Feta cheese",
            "Olive oil",
            "Balsamic vinegar"
          ],
          instructions: "1. Grill chicken\n2. Chop vegetables\n3. Mix ingredients\n4. Dress and serve",
          nutritionInfo: {
            calories: 420,
            protein: 35,
            carbs: 15,
            fat: 25
          },
          isPublic: true,
          imageUrl: "https://images.unsplash.com/photo-1512852939750-1305098529bf?w=800&auto=format&fit=crop"
        }
      ];

      const createdRecipes = await Promise.all(
        sampleRecipes.map(recipe =>
          db.insert(recipes).values({
            ...recipe,
            userId: req.user.id,
            likesCount: 0,
            commentsCount: 0,
          }).returning()
        )
      );

      res.json(createdRecipes.map(([recipe]) => recipe));
    } catch (error) {
      console.error('Error creating sample recipes:', error);
      res.status(500).json({
        error: 'Failed to create sample recipes',
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });


  // Get user's badges
  app.get("/api/user/badges", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ error: 'Authentication required' });
      }

      const userBadgesData = await db
        .select({
          id: badges.id,
          name: badges.name,
          description: badges.description,
          icon: badges.icon,
          earnedAt: userBadges.earnedAt,
        })
        .from(userBadges)
        .innerJoin(badges, eq(userBadges.badgeId, badges.id))
        .where(eq(userBadges.userId, req.user.id))
        .orderBy(desc(userBadges.earnedAt))
        .limit(10);

      res.json(userBadgesData);
    } catch (error) {
      console.error('Error fetching badges:', error);
      res.status(500).json({
        error: 'Failed to fetch badges',
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  // Get user's notifications
  app.get("/api/notifications", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ error: 'Authentication required' });
      }

      const userNotifications = await db
        .select()
        .from(notifications)
        .where(eq(notifications.userId, req.user.id))
        .orderBy(desc(notifications.createdAt))
        .limit(20);

      res.json(userNotifications);
    } catch (error) {
      console.error('Error fetching notifications:', error);
      res.status(500).json({
        error: 'Failed to fetch notifications',
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  // Mark notification as read
  app.post("/api/notifications/:id/read", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ error: 'Authentication required' });
      }

      const notificationId = parseInt(req.params.id);

      const [notification] = await db
        .select()
        .from(notifications)
        .where(and(
          eq(notifications.id, notificationId),
          eq(notifications.userId, req.user.id)
        ))
        .limit(1);

      if (!notification) {
        return res.status(404).json({ error: 'Notification not found' });
      }

      await db
        .update(notifications)
        .set({ isRead: true })
        .where(eq(notifications.id, notificationId));

      res.json({ ok: true });
    } catch (error) {
      console.error('Error marking notification as read:', error);
      res.status(500).json({
        error: 'Failed to mark notification as read',
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  // Create new recipe
  app.post("/api/recipes", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ error: 'Authentication required' });
      }

      const { name, description, ingredients, instructions, nutritionInfo, isPublic } = req.body;

      // Create recipe with user ID
      const [recipe] = await db.insert(recipes).values({
        userId: req.user.id,
        name,
        description,
        ingredients,
        instructions,
        nutritionInfo,
        isPublic: isPublic || false,
        likesCount: 0,
        commentsCount: 0,
      }).returning();

      res.json(recipe);
    } catch (error) {
      console.error('Error saving recipe:', error);
      res.status(500).json({
        error: 'Failed to save recipe',
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  // New endpoint for recipe proposals
  app.post("/api/recipe-proposals", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ error: 'Authentication required' });
      }

      const { mealType, calories, budget } = req.body;

      // Filter and sort proposals based on user preferences
      const proposals = recipeProposals
        .filter(recipe =>
          Math.abs(recipe.nutritionInfo.calories - calories) <= 100 // Within 100 calories
        )
        .sort((a, b) => b.avgRating - a.avgRating); // Sort by rating

      res.json(proposals);
    } catch (error) {
      console.error('Error fetching recipe proposals:', error);
      res.status(500).json({
        error: 'Failed to fetch recipe proposals',
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

// Sample ingredient data with proper types
type IngredientPrices = {
  [key: string]: number;
};

const ingredientPrices: IngredientPrices = {
  "eggs": 0.50,
  "milk": 2.99,
  "bread": 3.49,
  "chicken breast": 5.99,
  "rice": 1.99,
  "pasta": 2.49,
  "tomatoes": 0.99,
  "onions": 0.79,
  "garlic": 0.49,
  "olive oil": 6.99,
  "butter": 4.99,
  "cheese": 3.99,
  "ground beef": 6.99,
  "potatoes": 0.99,
  "carrots": 0.89,
};

// Sample recipe data - Removed original sampleRecipes array

// Add new type for recipe proposals
type RecipeProposal = {
  name: string;
  description: string;
  ingredients: string[];
  instructions: string;
  nutritionInfo: {
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
  };
  reviews: {
    rating: number;
    comment: string;
    userName: string;
  }[];
  avgRating: number;
  imageUrl: string; // Added imageUrl field
};

// Sample recipe proposals with reviews
const recipeProposals: RecipeProposal[] = [
  {
    name: "High-Protein Breakfast Bowl",
    description: "A nutritious breakfast bowl perfect for muscle recovery and energy",
    ingredients: [
      "2 large eggs",
      "1 cup quinoa",
      "1 avocado",
      "Cherry tomatoes",
      "Baby spinach",
      "Extra virgin olive oil",
      "Salt and pepper"
    ],
    instructions: "1. Cook quinoa\n2. Poach eggs\n3. Arrange all ingredients\n4. Season and serve",
    nutritionInfo: {
      calories: 450,
      protein: 20,
      carbs: 35,
      fat: 28
    },
    reviews: [
      {
        rating: 5,
        comment: "Perfect portion size and really filling!",
        userName: "FitFoodie"
      },
      {
        rating: 4,
        comment: "Great taste, added some hot sauce for extra kick",
        userName: "HealthyEater"
      }
    ],
    avgRating: 4.5,
    imageUrl: "https://images.unsplash.com/photo-1607532941433-304659e8198a?w=800&auto=format&fit=crop"
  },
  {
    name: "Power Smoothie Bowl",
    description: "Energizing smoothie bowl packed with superfoods",
    ingredients: [
      "1 banana",
      "1 cup mixed berries",
      "1 scoop protein powder",
      "1 tbsp chia seeds",
      "1 cup almond milk",
      "Granola for topping"
    ],
    instructions: "1. Blend all ingredients except granola\n2. Pour into bowl\n3. Top with granola\n4. Serve immediately",
    nutritionInfo: {
      calories: 380,
      protein: 25,
      carbs: 45,
      fat: 12
    },
    reviews: [
      {
        rating: 5,
        comment: "My go-to pre-workout meal!",
        userName: "GymLover"
      },
      {
        rating: 5,
        comment: "Delicious and nutritious",
        userName: "NutritionPro"
      }
    ],
    avgRating: 5,
    imageUrl: "https://images.unsplash.com/photo-1626078293023-97c7980e31ca?w=800&auto=format&fit=crop"
  },
  {
    name: "Mediterranean Chicken Salad",
    description: "Light and fresh salad with lean protein",
    ingredients: [
      "200g chicken breast",
      "Mixed greens",
      "Cherry tomatoes",
      "Cucumber",
      "Feta cheese",
      "Olive oil",
      "Balsamic vinegar"
    ],
    instructions: "1. Grill chicken\n2. Chop vegetables\n3. Mix ingredients\n4. Dress and serve",
    nutritionInfo: {
      calories: 420,
      protein: 35,
      carbs: 15,
      fat: 25
    },
    reviews: [
      {
        rating: 4,
        comment: "Perfect for meal prep!",
        userName: "MealPrepper"
      },
      {
        rating: 5,
        comment: "Light yet satisfying",
        userName: "HealthCoach"
      }
    ],
    avgRating: 4.5,
    imageUrl: "https://images.unsplash.com/photo-1512852939750-1305098529bf?w=800&auto=format&fit=crop"
  }
];