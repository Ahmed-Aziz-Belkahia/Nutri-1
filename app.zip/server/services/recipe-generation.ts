import OpenAI from 'openai';
import { z } from 'zod';
import { insertRecipeSchema } from '@db/schema';

// Validation schemas
const GeneratedRecipeSchema = z.object({
  name: z.string(),
  description: z.string(),
  ingredients: z.array(z.string()),
  instructions: z.string(),
  nutritionInfo: z.object({
    calories: z.number(),
    protein: z.number(),
    carbs: z.number(),
    fat: z.number(),
  }),
});

export type GeneratedRecipe = z.infer<typeof GeneratedRecipeSchema>;

export async function generateRecipe(ingredients: string[]): Promise<GeneratedRecipe> {
  try {
    if (!process.env.OPENAI_API_KEY) {
      throw new Error('OpenAI API key not found');
    }

    const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

    const prompt = `
      Create a healthy recipe using some or all of these ingredients: ${ingredients.join(', ')}.

      Requirements:
      1. The recipe should be practical and easy to follow
      2. Include any additional basic ingredients that might be needed (oil, salt, spices, etc.)
      3. Break down the instructions into clear steps
      4. Provide realistic nutritional information

      Return the response in this JSON format:
      {
        "name": "Creative and descriptive recipe name",
        "description": "A brief, appetizing description of the dish",
        "ingredients": ["ingredient 1 with amount", "ingredient 2 with amount", ...],
        "instructions": "1. First step\\n2. Second step\\n3. Third step...",
        "nutritionInfo": {
          "calories": number,
          "protein": number (in grams),
          "carbs": number (in grams),
          "fat": number (in grams)
        }
      }
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.7,
      max_tokens: 1000,
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error('Empty response from OpenAI');
    }

    const recipe = JSON.parse(content);
    return GeneratedRecipeSchema.parse(recipe);

  } catch (error) {
    console.error('Recipe generation error:', error);
    throw new Error('Failed to generate recipe');
  }
}