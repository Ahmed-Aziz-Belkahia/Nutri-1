import { ImageAnnotatorClient } from '@google-cloud/vision';
import OpenAI from 'openai';
import { z } from 'zod';
import axios from 'axios';

// Schema for food recognition response
const FoodRecognitionSchema = z.object({
  name: z.string(),
  calories: z.number(),
  protein: z.string(),
  carbs: z.string(),
  fat: z.string(),
  confidence: z.number(),
  isEstimate: z.boolean().optional(),
  servingSize: z.string().optional(),
});

type FoodRecognition = z.infer<typeof FoodRecognitionSchema>;

// Configuration for Nutritionix API
const nutritionixConfig = {
  headers: {
    'x-app-id': process.env.NUTRITIONIX_APP_ID,
    'x-app-key': process.env.NUTRITIONIX_API_KEY,
  }
};

const CONFIDENCE_THRESHOLD = 0.7;
const HIGH_CONFIDENCE = 0.9;

async function getNutritionalInfo(foodName: string): Promise<FoodRecognition | null> {
  try {
    const response = await axios.post(
      'https://trackapi.nutritionix.com/v2/natural/nutrients',
      { query: foodName },
      nutritionixConfig
    );

    if (!response.data.foods?.length) {
      return null;
    }

    const food = response.data.foods[0];
    return {
      name: food.food_name,
      calories: Math.round(food.nf_calories),
      protein: food.nf_protein.toFixed(1),
      carbs: food.nf_total_carbohydrate.toFixed(1),
      fat: food.nf_total_fat.toFixed(1),
      confidence: HIGH_CONFIDENCE,
      servingSize: food.serving_weight_grams ? `${food.serving_weight_grams}g` : undefined,
    };
  } catch (error) {
    console.error('Nutritionix API Error:', error);
    return null;
  }
}

async function analyzeWithOpenAI(imageBase64: string): Promise<string | null> {
  try {
    if (!process.env.OPENAI_API_KEY) {
      throw new Error('OpenAI API key not found in environment variables');
    }

    console.log('Starting OpenAI analysis...');
    const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

    // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "user",
          content: [
            { 
              type: "text", 
              text: "What specific food item is shown in this image? Please include details about preparation method if visible (e.g., 'grilled chicken breast' instead of just 'chicken'). For packaged foods, include brand if visible. Return JSON in this format: { 'food_name': 'specific food name', 'preparation': 'cooking method if visible', 'is_packaged': boolean }" 
            },
            {
              type: "image_url",
              image_url: {
                url: `data:image/jpeg;base64,${imageBase64}`
              }
            }
          ],
        }
      ],
      max_tokens: 100,
      temperature: 0.1,
      response_format: { type: "json_object" }
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error('Empty response from OpenAI');
    }

    const result = JSON.parse(content);
    const foodName = [
      result.food_name,
      result.preparation && !result.food_name.includes(result.preparation) ? result.preparation : ''
    ].filter(Boolean).join(' ').toLowerCase().trim();

    console.log('OpenAI Analysis Result:', foodName);
    return foodName || null;

  } catch (error) {
    console.error('OpenAI API Error:', error);
    return null;
  }
}

async function analyzeWithGoogleVision(imageBase64: string): Promise<string[]> {
  try {
    console.log('Starting Google Vision analysis...');
    const vision = new ImageAnnotatorClient({
      credentials: JSON.parse(process.env.GOOGLE_CLOUD_VISION_CREDENTIALS || '{}'),
    });

    const [result] = await vision.labelDetection({
      image: { content: Buffer.from(imageBase64, 'base64') }
    });

    const labels = (result.labelAnnotations || [])
      .filter(label => label.score && label.score >= CONFIDENCE_THRESHOLD)
      .map(label => label.description?.toLowerCase().trim() || '')
      .filter(Boolean);

    console.log('Google Vision Labels:', labels);
    return labels;
  } catch (error) {
    console.error('Google Vision API Error:', error);
    return [];
  }
}

function findBestMatch(openAIFood: string | null, labels: string[]): { name: string; confidence: number } {
  // Direct match from OpenAI with specific details
  if (openAIFood && openAIFood.includes(' ')) {
    return { name: openAIFood, confidence: 0.95 };
  }

  // Simple OpenAI match
  if (openAIFood) {
    return { name: openAIFood, confidence: 0.9 };
  }

  // Check Google Vision labels for food-specific matches
  const foodLabels = labels.filter(label => 
    !label.includes('food') && 
    !label.includes('cuisine') && 
    !label.includes('dish') &&
    !label.includes('meal')
  );

  if (foodLabels.length > 0) {
    // Combine related labels for more specific identification
    const combinedLabels = foodLabels.slice(0, 2).join(' ');
    return { name: combinedLabels, confidence: 0.8 };
  }

  return { name: 'Unknown Food', confidence: 0 };
}

export async function analyzeFoodImage(imageBase64: string): Promise<FoodRecognition> {
  try {
    console.log('Starting food analysis...');
    const base64Image = imageBase64.replace(/^data:image\/[a-z]+;base64,/, '');

    // Run both analyses in parallel
    const [openAIResult, gvisionLabels] = await Promise.allSettled([
      analyzeWithOpenAI(base64Image),
      analyzeWithGoogleVision(base64Image)
    ]);

    const openAIFood = openAIResult.status === 'fulfilled' ? openAIResult.value : null;
    const labels = gvisionLabels.status === 'fulfilled' ? gvisionLabels.value : [];

    console.log('Analysis results:', {
      openAI: openAIFood,
      gvision: labels
    });

    const { name, confidence } = findBestMatch(openAIFood, labels);

    // Get nutritional information if confidence is high enough
    if (confidence >= CONFIDENCE_THRESHOLD) {
      const nutritionInfo = await getNutritionalInfo(name);
      if (nutritionInfo) {
        return nutritionInfo;
      }
    }

    // Fallback to estimated values with lower confidence
    return {
      name,
      confidence,
      calories: 200,
      protein: '10',
      carbs: '25',
      fat: '8',
      isEstimate: true,
    };

  } catch (error) {
    console.error('Food recognition error:', error);
    throw new Error('Failed to analyze food image');
  }
}

// Enhanced food database with detailed nutritional info (largely unused now, kept for potential fallback)
const FOOD_NUTRITION_DATABASE: Record<string, FoodNutrition> = {
  // Fruits
  'apple': { name: 'Apple', calories: 95, protein: '0.5', carbs: '25', fat: '0.3' },
  'red apple': { name: 'Red Apple', calories: 95, protein: '0.5', carbs: '25', fat: '0.3' },
  'green apple': { name: 'Green Apple', calories: 95, protein: '0.5', carbs: '25', fat: '0.3' },
  'banana': { name: 'Banana', calories: 105, protein: '1.3', carbs: '27', fat: '0.4' },
  'orange': { name: 'Orange', calories: 62, protein: '1.2', carbs: '15', fat: '0.2' },

  // Vegetables
  'carrot': { name: 'Carrot', calories: 41, protein: '0.9', carbs: '10', fat: '0.2' },
  'broccoli': { name: 'Broccoli', calories: 55, protein: '3.7', carbs: '11', fat: '0.6' },
  'spinach': { name: 'Spinach', calories: 23, protein: '2.9', carbs: '3.6', fat: '0.4' },
  'lettuce': { name: 'Lettuce', calories: 15, protein: '1.4', carbs: '2.9', fat: '0.2' },
  'tomato': { name: 'Tomato', calories: 22, protein: '1.1', carbs: '4.8', fat: '0.2' },

  // Protein sources
  'chicken breast': { name: 'Chicken Breast', calories: 165, protein: '31', carbs: '0', fat: '3.6' },
  'salmon': { name: 'Salmon', calories: 208, protein: '22', carbs: '0', fat: '13' },
  'egg': { name: 'Egg', calories: 72, protein: '6.3', carbs: '0.4', fat: '4.8' },
  'steak': { name: 'Beef Steak', calories: 271, protein: '26', carbs: '0', fat: '18' },

  // Grains and starches
  'rice': { name: 'White Rice', calories: 130, protein: '2.7', carbs: '28', fat: '0.3' },
  'brown rice': { name: 'Brown Rice', calories: 216, protein: '4.5', carbs: '45', fat: '1.8' },
  'bread': { name: 'Bread Slice', calories: 79, protein: '3.1', carbs: '14', fat: '1' },
  'pasta': { name: 'Pasta', calories: 158, protein: '5.8', carbs: '31', fat: '0.9' },
};

type FoodNutrition = Omit<FoodRecognition, 'confidence'>;