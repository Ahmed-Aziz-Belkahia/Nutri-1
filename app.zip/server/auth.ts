import passport from "passport";
import { IVerifyOptions, Strategy as LocalStrategy } from "passport-local";
import { type Express } from "express";
import session from "express-session";
import createMemoryStore from "memorystore";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { users, userNutritionPreferences, insertUserSchema } from "@db/schema";
import { db } from "@db";
import { eq } from "drizzle-orm";

const scryptAsync = promisify(scrypt);
const crypto = {
  hash: async (password: string) => {
    const salt = randomBytes(16).toString("hex");
    const buf = (await scryptAsync(password, salt, 64)) as Buffer;
    return `${buf.toString("hex")}.${salt}`;
  },
  compare: async (suppliedPassword: string, storedPassword: string) => {
    const [hashedPassword, salt] = storedPassword.split(".");
    const hashedPasswordBuf = Buffer.from(hashedPassword, "hex");
    const suppliedPasswordBuf = (await scryptAsync(
      suppliedPassword,
      salt,
      64
    )) as Buffer;
    return timingSafeEqual(hashedPasswordBuf, suppliedPasswordBuf);
  },
};

// Map activity level from quiz format to database enum
function mapActivityLevel(level: string): 'sedentary' | 'light' | 'moderate' | 'very_active' {
  switch (level) {
    case "0-2":
      return 'sedentary';
    case "3-5":
      return 'moderate';
    case "6+":
      return 'very_active';
    default:
      return 'moderate'; // fallback
  }
}

declare global {
  namespace Express {
    interface User {
      id: number;
      email: string;
      hasCompletedOnboarding: boolean;
      currentStreak: number;
      longestStreak: number;
      experiencePoints: number;
      level: number;
    }
  }
}

export function setupAuth(app: Express) {
  const MemoryStore = createMemoryStore(session);
  const sessionSettings: session.SessionOptions = {
    secret: process.env.REPL_ID || "nutri-ai-secret",
    resave: false,
    saveUninitialized: false,
    cookie: {},
    store: new MemoryStore({
      checkPeriod: 86400000, // prune expired entries every 24h
    }),
  };

  if (app.get("env") === "production") {
    app.set("trust proxy", 1);
    sessionSettings.cookie = {
      secure: true,
    };
  }

  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(
      { usernameField: 'email' },
      async (email, password, done) => {
        try {
          const [user] = await db
            .select()
            .from(users)
            .where(eq(users.email, email))
            .limit(1);

          if (!user) {
            return done(null, false, { message: "Email not found" });
          }

          const isMatch = await crypto.compare(password, user.password);
          if (!isMatch) {
            return done(null, false, { message: "Incorrect password" });
          }

          return done(null, {
            id: user.id,
            email: user.email,
            hasCompletedOnboarding: user.hasCompletedOnboarding || false,
            currentStreak: user.currentStreak || 0,
            longestStreak: user.longestStreak || 0,
            experiencePoints: user.experiencePoints || 0,
            level: user.level || 1,
          });
        } catch (err) {
          console.error('Authentication error:', err);
          return done(err);
        }
      }
    )
  );

  passport.serializeUser((user, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id: number, done) => {
    try {
      const [user] = await db
        .select()
        .from(users)
        .where(eq(users.id, id))
        .limit(1);

      if (!user) {
        return done(null, false);
      }

      done(null, {
        id: user.id,
        email: user.email,
        hasCompletedOnboarding: user.hasCompletedOnboarding || false,
        currentStreak: user.currentStreak || 0,
        longestStreak: user.longestStreak || 0,
        experiencePoints: user.experiencePoints || 0,
        level: user.level || 1,
      });
    } catch (err) {
      console.error('Session deserialization error:', err);
      done(err);
    }
  });

  app.post("/api/register", async (req, res) => {
    try {
      const { email, password, profile } = req.body;

      // Check if user already exists
      const [existingUser] = await db
        .select()
        .from(users)
        .where(eq(users.email, email))
        .limit(1);

      if (existingUser) {
        return res.status(400).json({
          error: "Registration failed",
          details: "This email is already registered"
        });
      }

      const hashedPassword = await crypto.hash(password);

      // Create user first
      const [newUser] = await db
        .insert(users)
        .values({
          email,
          password: hashedPassword,
          hasCompletedOnboarding: false,
        })
        .returning();

      // If profile data is provided, create nutrition preferences
      if (profile) {
        await db.insert(userNutritionPreferences).values({
          userId: newUser.id,
          weight: profile.weight,
          goalWeight: profile.goalWeight,
          weightGoal: profile.weightGoal,
          activityLevel: mapActivityLevel(profile.activityLevel),
          calorieGoal: profile.calorieGoal,
          proteinGoal: profile.proteinGoal,
          carbsGoal: profile.carbsGoal,
          fatGoal: profile.fatGoal,
        });

        // Mark onboarding as completed since they filled out the quiz
        await db
          .update(users)
          .set({ hasCompletedOnboarding: true })
          .where(eq(users.id, newUser.id));

        newUser.hasCompletedOnboarding = true;
      }

      // Log the user in after registration
      const userForAuth: Express.User = {
        id: newUser.id,
        email: newUser.email,
        hasCompletedOnboarding: newUser.hasCompletedOnboarding || false,
        currentStreak: 0,
        longestStreak: 0,
        experiencePoints: 0,
        level: 1,
      };

      req.login(userForAuth, (err) => {
        if (err) {
          console.error("Login error after registration:", err);
          return res.status(500).json({
            error: "Registration failed",
            details: "Could not create session"
          });
        }
        return res.json({ ok: true });
      });
    } catch (error: any) {
      console.error('Registration error:', error);
      return res.status(500).json({
        error: "Registration failed",
        details: error.message || "An unexpected error occurred"
      });
    }
  });

  app.post("/api/login", (req, res, next) => {
    passport.authenticate("local", (err: any, user: Express.User | false, info: IVerifyOptions) => {
      if (err) {
        console.error("Login error:", err);
        return res.status(500).json({
          error: "Login failed",
          details: "An unexpected error occurred"
        });
      }

      if (!user) {
        return res.status(400).json({
          error: "Login failed",
          details: info.message || "Invalid credentials"
        });
      }

      req.logIn(user, (err) => {
        if (err) {
          console.error("Session creation error:", err);
          return res.status(500).json({
            error: "Login failed",
            details: "Could not create session"
          });
        }

        return res.json({ ok: true });
      });
    })(req, res, next);
  });

  app.post("/api/logout", (req, res) => {
    req.logout((err) => {
      if (err) {
        return res.status(500).json({
          error: "Logout failed",
          details: "Failed to log out"
        });
      }
      res.json({ ok: true });
    });
  });

  app.get("/api/user", (req, res) => {
    if (req.isAuthenticated()) {
      return res.json(req.user);
    }
    res.status(401).json({
      error: "Not authenticated",
      details: "User is not logged in"
    });
  });
}