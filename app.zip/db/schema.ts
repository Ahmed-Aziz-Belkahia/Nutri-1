import { pgTable, text, serial, integer, boolean, decimal, timestamp, jsonb, date } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { z } from 'zod';

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").unique().notNull(),
  password: text("password").notNull(),
  hasCompletedOnboarding: boolean("has_completed_onboarding").default(false),
  currentStreak: integer("current_streak").default(0),
  longestStreak: integer("longest_streak").default(0),
  lastActivityDate: date("last_activity_date"),
  experiencePoints: integer("experience_points").default(0),
  level: integer("level").default(1),
});

// User nutrition preferences schema
export const userNutritionPreferences = pgTable("user_nutrition_preferences", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  weight: decimal("weight").notNull(),
  goalWeight: decimal("goal_weight").notNull(),
  weightGoal: text("weight_goal").notNull(), // 'gain', 'loss', 'maintain'
  activityLevel: text("activity_level").notNull(), // 'sedentary', 'light', 'moderate', 'very_active'
  calorieGoal: decimal("calorie_goal").notNull(),
  proteinGoal: decimal("protein_goal").notNull(),
  carbsGoal: decimal("carbs_goal").notNull(),
  fatGoal: decimal("fat_goal").notNull(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Weight logs schema
export const weightLogs = pgTable("weight_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  weight: decimal("weight").notNull(),
  note: text("note"),
  loggedAt: timestamp("logged_at").notNull().defaultNow(),
});

// Food logs schema
export const foodLogs = pgTable("food_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  name: text("name").notNull(),
  calories: integer("calories").notNull(),
  protein: decimal("protein"),
  carbs: decimal("carbs"),
  fat: decimal("fat"),
  date: timestamp("date").notNull().defaultNow(),
  image: text("image"),
});

// Recipes schema
export const recipes = pgTable("recipes", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  name: text("name").notNull(),
  description: text("description"),
  ingredients: jsonb("ingredients").$type<string[]>().notNull(),
  instructions: text("instructions").notNull(),
  nutritionInfo: jsonb("nutrition_info").$type<{
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
  }>(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
  imageUrl: text("image_url"),
  rating: decimal("rating").default("0"),
  likesCount: integer("likes_count").default(0),
  commentsCount: integer("comments_count").default(0),
  isPublic: boolean("is_public").default(false),
});

// Recipe likes schema
export const recipeLikes = pgTable("recipe_likes", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  recipeId: integer("recipe_id").notNull().references(() => recipes.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Recipe comments schema
export const recipeComments = pgTable("recipe_comments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  recipeId: integer("recipe_id").notNull().references(() => recipes.id),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// New table for badges/achievements
export const badges = pgTable("badges", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  icon: text("icon").notNull(),
  requirement: jsonb("requirement").$type<{
    type: 'streak' | 'weight_goal' | 'logging_streak' | 'meal_variety',
    threshold: number,
  }>().notNull(),
  experiencePoints: integer("experience_points").notNull(),
});

// User badges junction table
export const userBadges = pgTable("user_badges", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  badgeId: integer("badge_id").notNull().references(() => badges.id),
  earnedAt: timestamp("earned_at").notNull().defaultNow(),
});

// Daily progress tracking
export const dailyProgress = pgTable("daily_progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  date: date("date").notNull(),
  caloriesLogged: boolean("calories_logged").default(false),
  waterLogged: boolean("water_logged").default(false),
  exerciseLogged: boolean("exercise_logged").default(false),
  weightLogged: boolean("weight_logged").default(false),
  completedTasks: integer("completed_tasks").default(0),
  totalTasks: integer("total_tasks").default(0),
});

// Notifications table
export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  type: text("type").notNull(), // 'streak', 'badge', 'reminder', 'milestone'
  title: text("title").notNull(),
  message: text("message").notNull(),
  isRead: boolean("is_read").default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  scheduledFor: timestamp("scheduled_for"),
  data: jsonb("data"),
});


// Add ProgressPhoto type to schema.ts
export const progressPhotos = pgTable("progress_photos", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  photoUrl: text("photo_url").notNull(),
  caption: text("caption"),
  type: text("type").notNull(), // 'latest' | 'favorite' | 'first'
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  foodLogs: many(foodLogs),
  recipes: many(recipes),
  recipeLikes: many(recipeLikes),
  recipeComments: many(recipeComments),
  badges: many(userBadges),
  dailyProgress: many(dailyProgress),
  notifications: many(notifications),
  progressPhotos: many(progressPhotos), 
}));

export const recipesRelations = relations(recipes, ({ many }) => ({
  likes: many(recipeLikes),
  comments: many(recipeComments),
}));

export const badgesRelations = relations(badges, ({ many }) => ({
  userBadges: many(userBadges),
}));

// Types and validation schemas
export type SelectUser = typeof users.$inferSelect;
export type Recipe = typeof recipes.$inferSelect;
export type RecipeLike = typeof recipeLikes.$inferSelect;
export type RecipeComment = typeof recipeComments.$inferSelect;
export type FoodLog = typeof foodLogs.$inferSelect;
export type UserNutritionPreferences = typeof userNutritionPreferences.$inferSelect;
export type Badge = typeof badges.$inferSelect;
export type DailyProgress = typeof dailyProgress.$inferSelect;
export type Notification = typeof notifications.$inferSelect;
export type ProgressPhoto = typeof progressPhotos.$inferSelect;
export type InsertProgressPhoto = typeof progressPhotos.$inferInsert;

export const insertUserSchema = z.object({
  email: z.string().email("Invalid email format"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

export const insertRecipeSchema = z.object({
  name: z.string().min(1, "Recipe name is required"),
  description: z.string().optional(),
  ingredients: z.array(z.string()),
  instructions: z.string(),
  nutritionInfo: z.object({
    calories: z.number(),
    protein: z.number(),
    carbs: z.number(),
    fat: z.number(),
  }).optional(),
  imageUrl: z.string().optional(),
  isPublic: z.boolean().default(true),
});

export const insertBadgeSchema = z.object({
  name: z.string().min(1, "Badge name is required"),
  description: z.string().min(1, "Badge description is required"),
  icon: z.string().min(1, "Badge icon is required"),
  requirement: z.object({
    type: z.enum(['streak', 'weight_goal', 'logging_streak', 'meal_variety']),
    threshold: z.number().positive(),
  }),
  experiencePoints: z.number().positive(),
});

export const insertDailyProgressSchema = z.object({
  date: z.date(),
  caloriesLogged: z.boolean().optional(),
  waterLogged: z.boolean().optional(),
  exerciseLogged: z.boolean().optional(),
  weightLogged: z.boolean().optional(),
  completedTasks: z.number().min(0).optional(),
  totalTasks: z.number().min(0).optional(),
});

export const insertNotificationSchema = z.object({
  type: z.enum(['streak', 'badge', 'reminder', 'milestone']),
  title: z.string().min(1, "Notification title is required"),
  message: z.string().min(1, "Notification message is required"),
  scheduledFor: z.date().optional(),
  data: z.record(z.unknown()).optional(),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertRecipe = z.infer<typeof insertRecipeSchema>;
export type InsertBadge = z.infer<typeof insertBadgeSchema>;
export type InsertDailyProgress = z.infer<typeof insertDailyProgressSchema>;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;