interface FoodAnalysis {
  name: string;
  calories: number;
  protein: string;
  carbs: string;
  fat: string;
}

export async function analyzeFoodImage(imageData: string): Promise<FoodAnalysis> {
  try {
    console.log('Sending image to server for analysis...');

    const response = await fetch('/api/analyze-food', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ image: imageData }),
      credentials: 'include'
    });

    if (!response.ok) {
      const error = await response.text();
      console.error('Food analysis error:', error);
      throw new Error(error);
    }

    const result = await response.json();

    if (!result || !result.name) {
      throw new Error('Invalid response format from food analysis');
    }

    return {
      name: result.name,
      calories: result.calories,
      protein: result.protein,
      carbs: result.carbs,
      fat: result.fat,
    };

  } catch (error) {
    console.error('Food Analysis Error:', error);
    throw new Error('Failed to analyze food image: ' + (error instanceof Error ? error.message : 'Unknown error'));
  }
}