import { toast } from "@/components/ui/use-toast";

export interface ProductInfo {
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  image?: string;
}

export async function lookupBarcode(barcode: string): Promise<ProductInfo> {
  try {
    // First try the Open Food Facts database
    const response = await fetch(
      `https://world.openfoodfacts.org/api/v0/product/${barcode}.json`
    );

    if (!response.ok) {
      throw new Error('Product not found');
    }

    const data = await response.json();
    
    if (data.status === 1 && data.product) {
      const product = data.product;
      const nutriments = product.nutriments || {};
      
      // Ensure all nutritional values are positive numbers or default to 0
      const validateNumber = (value: number | null | undefined): number => {
        const num = Number(value);
        return !isNaN(num) && num >= 0 ? Math.round(num) : 0;
      };

      return {
        name: product.product_name || `Barcode: ${barcode}`,
        calories: validateNumber(nutriments['energy-kcal_100g']),
        protein: validateNumber(nutriments.proteins_100g),
        carbs: validateNumber(nutriments.carbohydrates_100g),
        fat: validateNumber(nutriments.fat_100g),
        image: product.image_url,
      };
    }
    
    throw new Error('Product not found');
  } catch (error) {
    console.error('Failed to lookup barcode:', error);
    // Return a default object if lookup fails
    return {
      name: `Barcode: ${barcode}`,
      calories: 0,
      protein: 0,
      carbs: 0,
      fat: 0
    };
  }
}
