import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useUser } from "../hooks/use-user";
import Navigation from "../components/Navigation";

export default function Analytics() {
  const { user, updateProfile } = useUser();
  const [isUpdatingWeight, setIsUpdatingWeight] = useState(false);
  const [isUpdatingGoal, setIsUpdatingGoal] = useState(false);
  const [newWeight, setNewWeight] = useState(user?.weight || 70);
  const [newGoalWeight, setNewGoalWeight] = useState(user?.goalWeight || 101);

  const handleUpdateWeight = async () => {
    setIsUpdatingWeight(true);
    try {
      await updateProfile({ ...user!, weight: newWeight });
    } catch (error) {
      console.error('Failed to update weight:', error);
    } finally {
      setIsUpdatingWeight(false);
    }
  };

  const handleUpdateGoalWeight = async () => {
    setIsUpdatingGoal(true);
    try {
      await updateProfile({ ...user!, goalWeight: newGoalWeight });
    } catch (error) {
      console.error('Failed to update goal weight:', error);
    } finally {
      setIsUpdatingGoal(false);
    }
  };
  const [selectedPeriod, setSelectedPeriod] = useState<"90 Days" | "6 Months" | "1 Year" | "All time">("90 Days");
  const [selectedNutritionPeriod, setSelectedNutritionPeriod] = useState<"This week" | "Last week" | "2 wks. ago" | "3 wks. ago">("This week");

  // Calculate BMI and progress from user data
  const currentWeight = user?.weight || 70;
  const goalWeight = user?.goalWeight || 101;
  const height = user?.height || 175; // height in cm
  const bmi = Math.round((currentWeight / Math.pow(height/100, 2)) * 10) / 10;
  const goalProgress = Math.round(((currentWeight - user?.initialWeight!) / (goalWeight - user?.initialWeight!)) * 100);

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <div className="flex-1 p-4 space-y-6">
        {/* Overview Section */}
        <section className="space-y-4">
          <h2 className="text-2xl font-bold">Overview</h2>
          
          {/* Goal Weight Card */}
          <Card className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-amber-500 text-xl">🏆</span>
              <span className="text-lg">Goal Weight {goalWeight} kg</span>
            </div>
            {isUpdatingGoal ? (
              <div className="space-y-2">
                <Input
                  type="number"
                  value={newGoalWeight}
                  onChange={(e) => setNewGoalWeight(Number(e.target.value))}
                  className="w-full"
                />
                <div className="flex gap-2">
                  <Button variant="outline" className="flex-1" onClick={() => setIsUpdatingGoal(false)}>
                    Cancel
                  </Button>
                  <Button className="flex-1" onClick={handleUpdateGoalWeight}>
                    Save
                  </Button>
                </div>
              </div>
            ) : (
              <Button 
                variant="outline" 
                className="w-full border-2 hover:bg-gray-50"
                onClick={() => setIsUpdatingGoal(true)}
              >
                Update
              </Button>
            )}
          </Card>
          
          {/* Current Weight */}
          <Card className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-xl">⚖️</span>
              <span className="text-lg">Current Weight {currentWeight} kg</span>
            </div>
            <div className="text-sm text-gray-500 mb-3">
              Remember to update this at least once a week so we can adjust your plan to hit your goal
            </div>
            {isUpdatingWeight ? (
              <div className="space-y-2">
                <Input
                  type="number"
                  value={newWeight}
                  onChange={(e) => setNewWeight(Number(e.target.value))}
                  className="w-full"
                />
                <div className="flex gap-2">
                  <Button variant="outline" className="flex-1" onClick={() => setIsUpdatingWeight(false)}>
                    Cancel
                  </Button>
                  <Button className="flex-1 bg-black text-white hover:bg-black/90" onClick={handleUpdateWeight}>
                    Save
                  </Button>
                </div>
              </div>
            ) : (
              <Button 
                variant="default" 
                className="w-full bg-black text-white hover:bg-black/90"
                onClick={() => setIsUpdatingWeight(true)}
              >
                Update your weight
              </Button>
            )}
          </Card>

          {/* BMI Section */}
          <Card className="p-4">
            <h2 className="text-lg mb-4">Your BMI</h2>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <div>
                  <div className="text-2xl font-medium">{bmi}</div>
                  <div className="text-sm text-gray-500">Your weight is</div>
                  <div className="inline-flex items-center gap-1 mt-1">
                    <div className="w-2 h-2 rounded-full bg-green-500"></div>
                    <span className="text-sm">Healthy</span>
                  </div>
                </div>
                <Button variant="ghost" size="sm" className="text-gray-500">
                  ?
                </Button>
              </div>
              
              <div className="relative h-2 bg-gradient-to-r from-[#0177FB] via-[#4CD964] to-[#FF3B30] rounded-full overflow-hidden">
                <div 
                  className="absolute w-2 h-4 bg-black -top-1 rounded-full"
                  style={{ left: `${(bmi / 40) * 100}%` }}
                />
              </div>
              
              <div className="flex justify-between text-xs text-gray-500">
                <span>Underweight</span>
                <span className="text-green-500">Healthy</span>
                <span>Overweight</span>
                <span className="text-right">Obese</span>
              </div>
            </div>
          </Card>

          {/* Goal Progress */}
          <Card className="p-4">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg">Goal Progress</h2>
              <div className="flex items-center gap-1">
                <span className="text-sm">{goalProgress}%</span>
                <span className="text-sm text-gray-500">Goal achieved</span>
              </div>
            </div>
            
            {/* Time Period Selector */}
            <div className="flex gap-2 mb-6 bg-gray-100 p-1 rounded-lg">
              {["90 Days", "6 Months", "1 Year", "All time"].map((period) => (
                <Button
                  key={period}
                  variant={selectedPeriod === period ? "default" : "ghost"}
                  className={`flex-1 h-8 text-sm ${
                    selectedPeriod === period 
                      ? "bg-white shadow-sm text-black" 
                      : "text-gray-500 hover:text-gray-900 hover:bg-transparent"
                  }`}
                  onClick={() => setSelectedPeriod(period as "90 Days" | "6 Months" | "1 Year" | "All time")}
                >
                  {period}
                </Button>
              ))}
            </div>

            {/* Progress Graph */}
            <div className="h-48 bg-gray-50 rounded-lg" />
          </Card>
        </section>

        {/* Nutrition Section */}
          <section className="space-y-4">
            <h2 className="text-lg font-medium">Nutrition</h2>
            
            {/* Time Period Selector */}
            <div className="flex gap-2 mb-4 bg-gray-100 p-1 rounded-lg">
              {["This week", "Last week", "2 wks. ago", "3 wks. ago"].map((period) => (
                <Button
                  key={period}
                  variant="ghost"
                  className={`flex-1 h-8 text-sm ${
                    selectedNutritionPeriod === period
                      ? "bg-white shadow-sm text-black" 
                      : "text-gray-500 hover:text-gray-900 hover:bg-transparent"
                  }`}
                  onClick={() => setSelectedNutritionPeriod(period as "This week" | "Last week" | "2 wks. ago" | "3 wks. ago")}
                >
                  {period}
                </Button>
              ))}
            </div>

            <Card className="p-4">
              <div className="space-y-4">
                <div className="flex justify-between">
                  <div>
                    <div className="text-2xl font-medium">1463</div>
                    <div className="text-sm text-gray-500">Total calories</div>
                  </div>
                  <div>
                    <div className="text-2xl font-medium">1463</div>
                    <div className="text-sm text-gray-500">Daily avg.</div>
                  </div>
                </div>

                {/* Weekly Bar Chart */}
                <div className="relative h-48">
                  <div className="absolute left-0 right-0 bottom-8">
                    <div className="flex items-end justify-between gap-2 h-40">
                      {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day, i) => (
                        <div key={day} className="flex-1 flex flex-col items-center">
                          <div 
                            className="w-full bg-black rounded-sm transition-all duration-300" 
                            style={{ 
                              height: i === 2 ? '60%' : '0%',
                              opacity: i === 2 ? 1 : 0.1
                            }} 
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="absolute bottom-0 left-0 right-0">
                    <div className="flex justify-between">
                      {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
                        <div key={day} className="flex-1 text-center">
                          <span className="text-xs text-gray-500">{day[0]}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          </section>
      </div>
      <Navigation />
    </div>
  );
}