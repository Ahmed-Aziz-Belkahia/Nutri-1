import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useUser } from "../hooks/use-user";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { calculateDailyCalories, calculateMacros } from "../lib/nutrition";
import { ArrowLeft, ChevronUp, ChevronDown, TrendingUp, TrendingDown, Minus } from "lucide-react";
import { useLocation } from "wouter";
import HeightWeightInput from '@/components/HeightWeightInput';

type WeightGoal = "gain" | "lose" | "maintain";

type Step = {
  id: number;
  question: string;
  description?: string;
  type: "gender" | "age" | "height_weight" | "weight_goal" | "goal_weight" | "activity" | "experience" | "auth";
};

const steps: Step[] = [
  {
    id: 1,
    question: "What is your gender?",
    description: "We'll personalize your experience based on your gender",
    type: "gender",
  },
  {
    id: 2,
    question: "How many workouts do you do per week?",
    description: "This will be used to calibrate your custom plan.",
    type: "activity",
  },
  {
    id: 3,
    question: "Have you tried other calorie tracking apps?",
    type: "experience",
  },
  {
    id: 4,
    question: "Height & Weight",
    description: "This will be used to calibrate your custom plan.",
    type: "height_weight",
  },
  {
    id: 5,
    question: "How old are you?",
    description: "Your age helps us determine your nutritional needs",
    type: "age",
  },
  {
    id: 6,
    question: "What's your weight goal?",
    description: "Tell us what you want to achieve",
    type: "weight_goal",
  },
  {
    id: 7,
    question: "Your Goal Weight",
    description: "This will be used to calibrate your custom plan.",
    type: "goal_weight",
  },
  {
    id: 8,
    question: "Create your account",
    description: "Set up your login credentials to save your progress",
    type: "auth",
  },
];

export default function Onboarding() {
  const { register } = useUser();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    gender: "",
    age: "25",
    heightFt: "5",
    heightIn: "8",
    height: "173", // for metric
    weight: "",
    weightGoal: "" as WeightGoal, // "gain", "lose", or "maintain"
    goalWeight: "",
    activityLevel: "",
    experience: "",
    unitPreference: "imperial",
    email: "",
    password: "",
  });

  const handleNext = async () => {
    if (currentStep === steps.length) {
      try {
        await handleSubmit();
      } catch (error: any) {
        console.error('Failed to submit form:', error);
        toast({
          variant: "destructive",
          title: "Error",
          description: error.message,
        });
      }
    } else {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep((prev) => prev - 1);
    }
  };

  const handleSubmit = async () => {
    try {
      // Calculate measurements and targets
      let height;
      if (formData.unitPreference === "imperial") {
        height = (parseFloat(formData.heightFt) * 12 + parseFloat(formData.heightIn)) * 2.54;
      } else {
        height = parseFloat(formData.height);
      }

      const dailyCalories = calculateDailyCalories(
        parseInt(formData.age),
        parseFloat(formData.weight),
        height,
        formData.activityLevel,
        formData.weightGoal as "maintain" | "lose" | "gain"
      );

      const macros = calculateMacros(dailyCalories);

      // Register with all collected data
      await register({
        email: formData.email,
        password: formData.password,
        profile: {
          age: parseInt(formData.age),
          height,
          weight: parseFloat(formData.weight),
          goalWeight: parseFloat(formData.goalWeight),
          activityLevel: formData.activityLevel,
          gender: formData.gender,
          weightGoal: formData.weightGoal,
          calorieGoal: dailyCalories,
          proteinGoal: macros.protein,
          carbsGoal: macros.carbs,
          fatGoal: macros.fat,
          hasCompletedOnboarding: true,
        }
      });

      toast({
        title: "Welcome to Nutri AI!",
        description: "Your account has been created successfully.",
      });

      setLocation("/dashboard");
    } catch (error: any) {
      console.error('Setup error:', error);
      toast({
        variant: "destructive",
        title: "Registration Failed",
        description: error.message || "Failed to complete registration. Please try again.",
      });
      throw error;
    }
  };

  const currentStepData = steps[currentStep - 1];

  // Helper function to check if current step is valid
  const isCurrentStepValid = () => {
    switch (currentStepData.type) {
      case "gender":
        return !!formData.gender;
      case "age":
        return !!formData.age && !isNaN(Number(formData.age));
      case "height_weight":
        return !!formData.weight;
      case "weight_goal":
        return !!formData.weightGoal;
      case "goal_weight":
        return !!formData.goalWeight && !isNaN(Number(formData.goalWeight)) && Number(formData.goalWeight) > 0;
      case "activity":
        return !!formData.activityLevel;
      case "experience":
        return !!formData.experience;
      case "auth":
        return !!formData.email && !!formData.password;
      default:
        return false;
    }
  };

  return (
    <div className="min-h-screen w-full flex justify-center bg-gray-100">
      <div className="w-full max-w-[500px] bg-white min-h-screen flex flex-col">
        {/* Header with back button and progress bar */}
        <div className="relative h-14 flex items-center px-4 border-b">
          {currentStep > 1 && (
            <Button
              variant="ghost"
              size="icon"
              className="absolute left-2 -ml-2"
              onClick={handleBack}
            >
              <ArrowLeft className="h-6 w-6" />
            </Button>
          )}
          <div className="w-full pl-8">
            <div className="h-1 bg-gray-100 rounded-full">
              <motion.div
                className="h-full bg-black rounded-full"
                initial={false}
                animate={{
                  width: `${(currentStep / steps.length) * 100}%`
                }}
                transition={{
                  type: "spring",
                  stiffness: 400,
                  damping: 40
                }}
              />
            </div>
          </div>
        </div>

        <div className="flex-1 px-6 pt-8 pb-8 overflow-y-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentStep}
              initial={{ opacity: 0, x: 20 }}
              animate={{
                opacity: 1,
                x: 0,
                transition: {
                  type: "spring",
                  stiffness: 300,
                  damping: 30
                }
              }}
              exit={{
                opacity: 0,
                x: -20,
                transition: {
                  duration: 0.2
                }
              }}
              className="w-full max-w-[400px] mx-auto"
            >
              <div className="space-y-8">
                <div className="space-y-2">
                  <h2 className="text-2xl font-semibold text-gray-900">
                    {currentStepData.question}
                  </h2>
                  {currentStepData.description && (
                    <p className="text-sm text-gray-600">
                      {currentStepData.description}
                    </p>
                  )}
                </div>

                <div className="space-y-4">
                  {currentStepData.type === "gender" && (
                    <div className="space-y-3">
                      {["male", "female", "other"].map((gender) => (
                        <motion.button
                          key={gender}
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          transition={{
                            type: "spring",
                            stiffness: 400,
                            damping: 17
                          }}
                          className={`w-full h-14 justify-center text-base rounded-xl border ${
                            formData.gender === gender
                              ? "bg-gray-900 text-white hover:bg-gray-800 border-transparent"
                              : "hover:bg-gray-50 border-gray-200"
                          }`}
                          onClick={() => setFormData({ ...formData, gender })}
                        >
                          {gender.charAt(0).toUpperCase() + gender.slice(1)}
                        </motion.button>
                      ))}
                    </div>
                  )}

                  {currentStepData.type === "experience" && (
                    <div className="space-y-3">
                      <motion.button
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        transition={{
                          type: "spring",
                          stiffness: 400,
                          damping: 17
                        }}
                        className={`w-full p-4 justify-start rounded-xl border ${
                          formData.experience === "no" ? "bg-gray-900 text-white hover:bg-gray-800 border-transparent" : "hover:bg-gray-50 border-gray-200"
                        }`}
                        onClick={() => setFormData({ ...formData, experience: "no" })}
                      >
                        <div className="flex items-center gap-4">
                          <div className="text-2xl">👎</div>
                          <div className="text-base font-medium">No</div>
                        </div>
                      </motion.button>
                      <motion.button
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        transition={{
                          type: "spring",
                          stiffness: 400,
                          damping: 17
                        }}
                        className={`w-full p-4 justify-start rounded-xl border ${
                          formData.experience === "yes" ? "bg-gray-900 text-white hover:bg-gray-800 border-transparent" : "hover:bg-gray-50 border-gray-200"
                        }`}
                        onClick={() => setFormData({ ...formData, experience: "yes" })}
                      >
                        <div className="flex items-center gap-4">
                          <div className="text-2xl">👍</div>
                          <div className="text-base font-medium">Yes</div>
                        </div>
                      </motion.button>
                    </div>
                  )}

                  {currentStepData.type === "age" && (
                    <div className="relative">
                      <div className="border rounded-xl bg-white p-4">
                        <div className="flex flex-col items-center">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="w-full h-10 hover:bg-gray-50"
                            onClick={() => {
                              const currentAge = parseInt(formData.age) || 25;
                              const newAge = Math.min(100, currentAge + 1);
                              setFormData({ ...formData, age: newAge.toString() });
                            }}
                          >
                            <ChevronUp className="h-5 w-5" />
                          </Button>
                          <div className="py-3 text-center">
                            <span className="text-3xl font-medium">{formData.age || '25'}</span>
                            <span className="text-sm text-gray-500 ml-2">years</span>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="w-full h-10 hover:bg-gray-50"
                            onClick={() => {
                              const currentAge = parseInt(formData.age) || 25;
                              const newAge = Math.max(13, currentAge - 1);
                              setFormData({ ...formData, age: newAge.toString() });
                            }}
                          >
                            <ChevronDown className="h-5 w-5" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  )}

                  {currentStepData.type === "height_weight" && (
                    <HeightWeightInput
                      onHeightChange={({ ft, in: inches }) => {
                        setFormData(prev => ({
                          ...prev,
                          heightFt: (ft ?? 5).toString(),
                          heightIn: (inches ?? 8).toString()
                        }));
                      }}
                      onWeightChange={(weight) => {
                        setFormData(prev => ({
                          ...prev,
                          weight: weight.toString()
                        }));
                      }}
                    />
                  )}

                  {currentStepData.type === "auth" && (
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="email" className="text-sm font-medium text-gray-700">
                          Email
                        </Label>
                        <Input
                          id="email"
                          type="email"
                          value={formData.email}
                          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                          className="h-12 rounded-xl bg-gray-50 border-0 text-[16px] placeholder:text-gray-400 focus-visible:ring-2 focus-visible:ring-gray-200"
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="password" className="text-sm font-medium text-gray-700">
                          Password
                        </Label>
                        <Input
                          id="password"
                          type="password"
                          value={formData.password}
                          onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                          className="h-12 rounded-xl bg-gray-50 border-0 text-[16px] placeholder:text-gray-400 focus-visible:ring-2 focus-visible:ring-gray-200"
                          required
                        />
                      </div>
                    </div>
                  )}

                  {currentStepData.type === "goal_weight" && (
                    <div>
                      <div className="flex items-center justify-between mb-6">
                        <button
                          className={`px-4 py-2 rounded-full text-sm font-medium ${
                            formData.unitPreference === "imperial"
                              ? "bg-black text-white"
                              : "text-gray-500"
                          }`}
                          onClick={() => setFormData({ ...formData, unitPreference: "imperial" })}
                        >
                          Imperial
                        </button>
                        <button
                          className={`px-4 py-2 rounded-full text-sm font-medium ${
                            formData.unitPreference === "metric"
                              ? "bg-black text-white"
                              : "text-gray-500"
                          }`}
                          onClick={() => setFormData({ ...formData, unitPreference: "metric" })}
                        >
                          Metric
                        </button>
                      </div>

                      <div className="border rounded-xl bg-white p-4">
                        <div className="flex flex-col items-center">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="w-full h-10 hover:bg-gray-50"
                            onClick={() => {
                              const currentWeight = parseInt(formData.goalWeight) || 150;
                              const increment = formData.unitPreference === "imperial" ? 1 : 0.5;
                              const newWeight = (currentWeight + increment).toString();
                              setFormData({ ...formData, goalWeight: newWeight });
                            }}
                          >
                            <ChevronUp className="h-5 w-5" />
                          </Button>
                          <div className="py-3 text-center">
                            <span className="text-3xl font-medium">
                              {formData.goalWeight || (formData.unitPreference === "imperial" ? "150" : "68")}
                            </span>
                            <span className="text-sm text-gray-500 ml-2">
                              {formData.unitPreference === "imperial" ? "lb" : "kg"}
                            </span>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="w-full h-10 hover:bg-gray-50"
                            onClick={() => {
                              const currentWeight = parseInt(formData.goalWeight) || 150;
                              const decrement = formData.unitPreference === "imperial" ? 1 : 0.5;
                              const newWeight = Math.max(0, currentWeight - decrement).toString();
                              setFormData({ ...formData, goalWeight: newWeight });
                            }}
                          >
                            <ChevronDown className="h-5 w-5" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  )}

                  {currentStepData.type === "weight_goal" && (
                    <div className="space-y-3">
                      {[
                        {
                          value: "lose" as WeightGoal,
                          label: "Lose Weight",
                          description: "I want to lose weight",
                          icon: <TrendingDown className="h-6 w-6" />
                        },
                        {
                          value: "maintain" as WeightGoal,
                          label: "Maintain Weight",
                          description: "I want to maintain my current weight",
                          icon: <Minus className="h-6 w-6" />
                        },
                        {
                          value: "gain" as WeightGoal,
                          label: "Gain Weight",
                          description: "I want to gain weight",
                          icon: <TrendingUp className="h-6 w-6" />
                        }
                      ].map((goal) => (
                        <motion.button
                          key={goal.value}
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          transition={{
                            type: "spring",
                            stiffness: 400,
                            damping: 17
                          }}
                          className={`w-full p-4 justify-start rounded-xl border ${
                            formData.weightGoal === goal.value
                              ? "bg-gray-900 text-white hover:bg-gray-800 border-transparent"
                              : "hover:bg-gray-50 border-gray-200"
                          }`}
                          onClick={() => setFormData({ ...formData, weightGoal: goal.value })}
                        >
                          <div className="flex items-center gap-4">
                            <div className={`${formData.weightGoal === goal.value ? "text-white" : "text-gray-500"}`}>
                              {goal.icon}
                            </div>
                            <div className="flex flex-col items-start gap-0.5">
                              <span className="text-base font-medium">{goal.label}</span>
                              <span className={`text-sm ${
                                formData.weightGoal === goal.value ? "text-gray-200" : "text-gray-500"
                              }`}>
                                {goal.description}
                              </span>
                            </div>
                          </div>
                        </motion.button>
                      ))}
                    </div>
                  )}

                  {currentStepData.type === "activity" && (
                    <div className="space-y-3">
                      {[
                        {
                          value: "0-2",
                          label: "0 - 2",
                          description: "Workouts now and then",
                          icon: "•"
                        },
                        {
                          value: "3-5",
                          label: "3 - 5",
                          description: "A few workouts per week",
                          icon: "••"
                        },
                        {
                          value: "6+",
                          label: "6+",
                          description: "Dedicated athlete",
                          icon: "•••"
                        }
                      ].map((level) => (
                        <motion.button
                          key={level.value}
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          transition={{
                            type: "spring",
                            stiffness: 400,
                            damping: 17
                          }}
                          className={`w-full p-4 justify-start rounded-xl border ${
                            formData.activityLevel === level.value ? "bg-gray-900 text-white hover:bg-gray-800 border-transparent" : "hover:bg-gray-50 border-gray-200"
                          }`}
                          onClick={() => setFormData({ ...formData, activityLevel: level.value })}
                        >
                          <div className="flex items-center gap-4">
                            <div className="text-2xl">{level.icon}</div>
                            <div className="flex flex-col items-start gap-0.5">
                              <span className="text-base font-medium">{level.label}</span>
                              <span className={`text-sm ${
                                formData.activityLevel === level.value ? "text-gray-200" : "text-gray-500"
                              }`}>
                                {level.description}
                              </span>
                            </div>
                          </div>
                        </motion.button>
                      ))}
                    </div>
                  )}
                </div>

                <div className="pt-8">
                  <Button
                    onClick={handleNext}
                    className={`w-full h-14 rounded-xl text-base ${
                      isCurrentStepValid()
                        ? 'bg-black text-white hover:bg-black/90'
                        : 'bg-gray-100 text-gray-400'
                    }`}
                    disabled={!isCurrentStepValid()}
                  >
                    Continue
                  </Button>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}