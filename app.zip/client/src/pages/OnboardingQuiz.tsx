import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useMutation } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

type OnboardingData = {
  weight: number;
  goalWeight: number;
  weightGoal: 'loss' | 'maintain' | 'gain';
  activityLevel: string;
};

const calculateCalories = (data: OnboardingData) => {
  // Base BMR calculation (Harris-Benedict equation)
  const bmr = 1800; // This is a placeholder - we should get actual height/age/gender for accuracy

  // Activity level multipliers
  const activityMultipliers = {
    '0-2': 1.2, // Sedentary
    '3-5': 1.55, // Moderate
    '6+': 1.725, // Very active
  };

  // Calculate TDEE (Total Daily Energy Expenditure)
  const tdee = bmr * activityMultipliers[data.activityLevel as keyof typeof activityMultipliers];

  // Adjust based on goal
  const adjustments = {
    loss: -500, // Deficit for weight loss
    maintain: 0,
    gain: 500, // Surplus for weight gain
  };

  return Math.round(tdee + adjustments[data.weightGoal]);
};

const calculateMacros = (calories: number) => {
  return {
    protein: Math.round((calories * 0.3) / 4), // 30% protein (4 calories per gram)
    carbs: Math.round((calories * 0.4) / 4),   // 40% carbs (4 calories per gram)
    fat: Math.round((calories * 0.3) / 9),     // 30% fat (9 calories per gram)
  };
};

export default function OnboardingQuiz() {
  const [, setLocation] = useLocation();
  const [step, setStep] = useState(1);
  const { toast } = useToast();
  const [formData, setFormData] = useState<OnboardingData>({
    weight: 0,
    goalWeight: 0,
    weightGoal: 'maintain',
    activityLevel: '3-5',
  });

  const savePreferences = async (data: OnboardingData) => {
    const calorieGoal = calculateCalories(data);
    const macros = calculateMacros(calorieGoal);

    const response = await fetch('/api/register/complete-onboarding', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        profile: {
          weight: data.weight,
          goalWeight: data.goalWeight,
          weightGoal: data.weightGoal,
          activityLevel: data.activityLevel,
          calorieGoal,
          proteinGoal: macros.protein,
          carbsGoal: macros.carbs,
          fatGoal: macros.fat,
        }
      }),
      credentials: 'include',
    });

    if (!response.ok) {
      throw new Error(await response.text());
    }

    return response.json();
  };

  const mutation = useMutation({
    mutationFn: savePreferences,
    onSuccess: () => {
      toast({
        title: "Profile completed!",
        description: "Your nutrition preferences have been saved.",
      });
      setLocation('/dashboard');
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to save preferences",
      });
    },
  });

  const handleNext = () => {
    if (step === 4) {
      mutation.mutate(formData);
    } else {
      setStep(step + 1);
    }
  };

  const handleBack = () => {
    if (step > 1) {
      setStep(step - 1);
    }
  };

  const isNextDisabled = () => {
    switch (step) {
      case 1:
        return formData.weight <= 0;
      case 2:
        return formData.goalWeight <= 0;
      case 3:
        return !formData.weightGoal;
      case 4:
        return !formData.activityLevel;
      default:
        return false;
    }
  };

  return (
    <div className="min-h-screen bg-[#00BCD4] flex items-center justify-center p-4">
      <Card className="w-full max-w-[500px] p-6">
        <div className="mb-8">
          <div className="flex justify-between mb-2">
            <span className="text-sm text-gray-500">Step {step} of 4</span>
            <span className="text-sm text-gray-500">{Math.round((step / 4) * 100)}%</span>
          </div>
          <div className="h-2 bg-gray-100 rounded-full">
            <div 
              className="h-full bg-[#00BCD4] rounded-full transition-all duration-300"
              style={{ width: `${(step / 4) * 100}%` }}
            />
          </div>
        </div>

        {step === 1 && (
          <div className="space-y-4">
            <h2 className="text-2xl font-semibold text-gray-900">Current Weight</h2>
            <p className="text-gray-500">What is your current weight in kg?</p>
            <Input
              type="number"
              value={formData.weight || ''}
              onChange={(e) => setFormData(prev => ({ ...prev, weight: Number(e.target.value) }))}
              className="h-14 text-lg"
              placeholder="Enter your weight"
              min="30"
              max="300"
              required
            />
          </div>
        )}

        {step === 2 && (
          <div className="space-y-4">
            <h2 className="text-2xl font-semibold text-gray-900">Goal Weight</h2>
            <p className="text-gray-500">What is your target weight in kg?</p>
            <Input
              type="number"
              value={formData.goalWeight || ''}
              onChange={(e) => setFormData(prev => ({ ...prev, goalWeight: Number(e.target.value) }))}
              className="h-14 text-lg"
              placeholder="Enter your goal weight"
              min="30"
              max="300"
              required
            />
          </div>
        )}

        {step === 3 && (
          <div className="space-y-4">
            <h2 className="text-2xl font-semibold text-gray-900">Weight Goal</h2>
            <p className="text-gray-500">What is your primary goal?</p>
            <Select
              value={formData.weightGoal}
              onValueChange={(value: 'loss' | 'maintain' | 'gain') => 
                setFormData(prev => ({ ...prev, weightGoal: value }))
              }
            >
              <SelectTrigger className="h-14">
                <SelectValue placeholder="Select your goal" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="loss">Lose Weight</SelectItem>
                <SelectItem value="maintain">Maintain Weight</SelectItem>
                <SelectItem value="gain">Gain Weight</SelectItem>
              </SelectContent>
            </Select>
          </div>
        )}

        {step === 4 && (
          <div className="space-y-4">
            <h2 className="text-2xl font-semibold text-gray-900">Activity Level</h2>
            <p className="text-gray-500">How many days per week do you exercise?</p>
            <Select
              value={formData.activityLevel}
              onValueChange={(value: string) => 
                setFormData(prev => ({ ...prev, activityLevel: value }))
              }
            >
              <SelectTrigger className="h-14">
                <SelectValue placeholder="Select activity level" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="0-2">0-2 days (Light activity)</SelectItem>
                <SelectItem value="3-5">3-5 days (Moderate activity)</SelectItem>
                <SelectItem value="6+">6+ days (Heavy activity)</SelectItem>
              </SelectContent>
            </Select>
          </div>
        )}

        <div className="flex justify-between mt-8">
          <Button
            variant="ghost"
            onClick={handleBack}
            disabled={step === 1}
            className="h-14 px-6"
          >
            Back
          </Button>
          <Button
            onClick={handleNext}
            disabled={mutation.isPending || isNextDisabled()}
            className="h-14 px-6 bg-[#00BCD4] hover:bg-[#00ACC1] text-white"
          >
            {mutation.isPending ? (
              <Loader2 className="h-5 w-5 animate-spin" />
            ) : step === 4 ? (
              "Complete"
            ) : (
              "Next"
            )}
          </Button>
        </div>
      </Card>
    </div>
  );
}