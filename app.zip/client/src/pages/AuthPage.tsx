import { useState } from "react";
import { useUser } from "../hooks/use-user";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Loader2, ArrowLeft } from "lucide-react";
import { useLocation } from "wouter";

export default function AuthPage() {
  const [isLogin, setIsLogin] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    confirmPassword: '',
  });

  const { login, register } = useUser();
  const [isLoading, setIsLoading] = useState(false);
  const [, setLocation] = useLocation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    try {
      if (!isLogin && formData.password !== formData.confirmPassword) {
        setError("Passwords do not match");
        setIsLoading(false);
        return;
      }

      const result = await (isLogin ? login : register)({ 
        email: formData.email, 
        password: formData.password 
      });

      if (!result.ok) {
        setError(result.message);
        return;
      }

      setLocation("/dashboard");
    } catch (error: any) {
      console.error('Auth error:', error);
      setError(error.message || "An unexpected error occurred");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0CC5BA]/5 to-blue-500/5 flex flex-col">
      {/* Back Button */}
      <div className="absolute top-4 left-4">
        <Button
          variant="ghost"
          size="icon"
          className="h-10 w-10 text-gray-600 hover:text-gray-900 hover:bg-black/5"
          onClick={() => setLocation("/")}
        >
          <ArrowLeft className="h-6 w-6" />
        </Button>
      </div>

      <div className="flex-1 px-6 py-12 flex flex-col items-center justify-center">
        <div className="w-full max-w-md space-y-6">
          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-xl">
              <div className="font-medium">Authentication failed</div>
              <div className="text-sm opacity-90">{error}</div>
            </div>
          )}

          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-center bg-gradient-to-r from-[#0CC5BA] via-[#0CBACC] to-[#0C9CCC] bg-clip-text text-transparent mb-4">
              {isLogin ? "Welcome Back" : "Create Account"}
            </h1>
            <p className="text-gray-600">
              {isLogin 
                ? "Enter your credentials to access your account" 
                : "Sign up to start tracking your nutrition"}
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <Input
              type="email"
              value={formData.email}
              onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
              className="h-14 rounded-xl bg-white border border-gray-200 text-gray-900 placeholder:text-gray-500"
              placeholder="Email"
              required
            />

            <Input
              type="password"
              value={formData.password}
              onChange={(e) => setFormData(prev => ({ ...prev, password: e.target.value }))}
              className="h-14 rounded-xl bg-white border border-gray-200 text-gray-900 placeholder:text-gray-500"
              placeholder="Password"
              required
            />

            {!isLogin && (
              <Input
                type="password"
                value={formData.confirmPassword}
                onChange={(e) => setFormData(prev => ({ ...prev, confirmPassword: e.target.value }))}
                className="h-14 rounded-xl bg-white border border-gray-200 text-gray-900 placeholder:text-gray-500"
                placeholder="Confirm Password"
                required
              />
            )}

            <Button 
              type="submit" 
              className="w-full h-14 bg-gradient-to-r from-[#0CC5BA] via-[#0CBACC] to-[#0C9CCC] text-white font-medium rounded-xl hover:opacity-90 transition-opacity" 
              disabled={isLoading}
            >
              {isLoading ? (
                <Loader2 className="h-5 w-5 animate-spin" />
              ) : (
                isLogin ? "Sign In" : "Create Account"
              )}
            </Button>

            <button
              type="button"
              onClick={() => {
                setIsLogin(!isLogin);
                setError(null);
                setFormData({ email: '', password: '', confirmPassword: '' });
              }}
              className="w-full text-center mt-4 text-gray-600 hover:text-gray-900 font-medium"
            >
              {isLogin 
                ? "Don't have an account? Sign up" 
                : "Already have an account? Sign in"}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}