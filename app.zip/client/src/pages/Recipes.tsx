import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { motion } from "framer-motion";
import { Plus, Camera, Heart } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";
import BottomNav from "@/components/BottomNav";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";

interface Recipe {
  id: number;
  name: string;
  description?: string;
  nutritionInfo: {
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
  };
  ingredients: string[];
  instructions: string;
  isPublic: boolean;
  likesCount: number;
  imageUrl?: string;
  createdAt: string;
}

// Default recipe images with single image per type
const DEFAULT_RECIPE_IMAGES: Record<string, string> = {
  "Mediterranean Chicken Salad": "https://images.unsplash.com/photo-1512852939750-1305098529bf?w=800&auto=format&fit=crop",
  "High-Protein Breakfast Bowl": "https://images.unsplash.com/photo-1607532941433-304659e8198a?w=800&auto=format&fit=crop",
  "Power Smoothie": "https://images.unsplash.com/photo-1557872943-16a5ac26437e?w=800&auto=format&fit=crop",
  "Grilled Salmon": "https://images.unsplash.com/photo-1467003909585-2f8a72700288?w=800&auto=format&fit=crop",
  "Quinoa Buddha Bowl": "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=800&auto=format&fit=crop",
  "Chicken Stir Fry": "https://images.unsplash.com/photo-1603133872878-684f208fb84b?w=800&auto=format&fit=crop",
  "Greek Salad": "https://images.unsplash.com/photo-1540189549336-e6e99c3679fe?w=800&auto=format&fit=crop",
  "Berry Parfait": "https://images.unsplash.com/photo-1488477181946-6428a0291777?w=800&auto=format&fit=crop",
  "Veggie Pasta": "https://images.unsplash.com/photo-1556761223-4c4282c73f77?w=800&auto=format&fit=crop",
  "Protein Pancakes": "https://images.unsplash.com/photo-1554520735-0a6b8b6ce8b7?w=800&auto=format&fit=crop",
  // Default fallback image for unknown recipes
  "default": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&auto=format&fit=crop"
};

export default function Recipes() {
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();

  // Fetch my recipes with refetch interval
  const { data: myRecipes, isLoading: isLoadingMyRecipes } = useQuery<Recipe[]>({
    queryKey: ["/api/recipes"],
    refetchInterval: 5000, // Refetch every 5 seconds to keep data fresh
    staleTime: 0, // Consider data stale immediately to allow instant updates
  });

  // Fetch top recipes with refetch interval
  const { data: topRecipes, isLoading: isLoadingTopRecipes } = useQuery<Recipe[]>({
    queryKey: ["/api/recipes/top"],
    refetchInterval: 5000,
    staleTime: 0,
  });

  // Helper function to get default image based on recipe name
  const getDefaultImage = (recipe: Recipe): string => {
    // If recipe has its own image URL, use that
    if (recipe.imageUrl) {
      return recipe.imageUrl;
    }

    // Look for exact recipe name match
    if (DEFAULT_RECIPE_IMAGES[recipe.name]) {
      return DEFAULT_RECIPE_IMAGES[recipe.name];
    }

    // Find closest matching recipe type based on name
    const recipeName = recipe.name.toLowerCase();
    for (const [key, value] of Object.entries(DEFAULT_RECIPE_IMAGES)) {
      if (recipeName.includes(key.toLowerCase())) {
        return value;
      }
    }

    // Fallback to default image
    return DEFAULT_RECIPE_IMAGES.default;
  };

  if (isLoadingMyRecipes || isLoadingTopRecipes) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-[#0CC5BA]" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0CC5BA]/5 to-blue-500/5">
      <motion.header
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="sticky top-0 w-full bg-white/80 border-b border-zinc-100/80 backdrop-blur-xl z-10"
      >
        <div className="max-w-[500px] mx-auto px-6 py-6">
          <div className="space-y-6">
            <motion.h1
              initial={{ x: -20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              className="text-3xl font-bold bg-gradient-to-br from-[#0CC5BA] via-[#0CBACC] to-[#0C9CCC] bg-clip-text text-transparent"
            >
              My Meals
            </motion.h1>
            <motion.div
              initial={{ x: -20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: 0.1 }}
              className="flex items-center gap-6"
            >
              <Link href="/dashboard">
                <span className="text-base font-medium cursor-pointer text-gray-500 hover:text-[#0CC5BA] transition-colors">
                  Overview
                </span>
              </Link>
              <Link href="/recipes">
                <span className="text-base font-medium cursor-pointer bg-gradient-to-br from-[#0CC5BA] via-[#0CBACC] to-[#0C9CCC] bg-clip-text text-transparent">
                  Recipes
                </span>
              </Link>
            </motion.div>
          </div>
        </div>
      </motion.header>

      <motion.main
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="flex-1 px-4 pb-24 max-w-[500px] mx-auto"
      >
        <div className="grid grid-cols-2 gap-4 mt-6 mb-8">
          <Card
            className="p-6 rounded-[28px] border-[#0CC5BA]/10 bg-gradient-to-br from-[#0CC5BA]/5 to-blue-500/5 backdrop-blur-xl hover:shadow-lg hover:shadow-[#0CC5BA]/20 transition-all duration-300 cursor-pointer"
            onClick={() => setLocation("/create-recipe")}
          >
            <div className="flex flex-col items-start gap-4">
              <div className="flex-1">
                <h3 className="text-lg font-bold bg-gradient-to-br from-[#0CC5BA] via-[#0CBACC] to-[#0C9CCC] bg-clip-text text-transparent">Create Recipe</h3>
                <p className="text-sm text-gray-500">Add your own recipe</p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-[#0CC5BA] to-blue-500 rounded-full flex items-center justify-center shadow-lg shadow-[#0CC5BA]/20">
                <Plus className="w-6 h-6 text-white" />
              </div>
            </div>
          </Card>

          <Card
            className="p-6 rounded-[28px] border-[#0CC5BA]/10 bg-gradient-to-br from-[#0CC5BA]/5 to-blue-500/5 backdrop-blur-xl hover:shadow-lg hover:shadow-[#0CC5BA]/20 transition-all duration-300 cursor-pointer"
            onClick={() => setLocation("/scan-recipe")}
          >
            <div className="flex flex-col items-start gap-4">
              <div className="flex-1">
                <h3 className="text-lg font-bold bg-gradient-to-br from-[#0CC5BA] via-[#0CBACC] to-[#0C9CCC] bg-clip-text text-transparent">Scan Recipe</h3>
                <p className="text-sm text-gray-500">Scan ingredients</p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-[#0CC5BA] to-blue-500 rounded-full flex items-center justify-center shadow-lg shadow-[#0CC5BA]/20">
                <Camera className="w-6 h-6 text-white" />
              </div>
            </div>
          </Card>
        </div>

        <section className="space-y-4 mb-8">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold bg-gradient-to-br from-[#0CC5BA] via-[#0CBACC] to-[#0C9CCC] bg-clip-text text-transparent">My Meals</h2>
            <span className="text-sm text-gray-500">Personal Recipes</span>
          </div>
          {myRecipes && myRecipes.length > 0 ? (
            <Carousel className="w-full">
              <CarouselContent className="-ml-4">
                {myRecipes.map((recipe) => (
                  <CarouselItem key={recipe.id} className="pl-4 basis-[280px]">
                    <Card className="overflow-hidden rounded-[28px] border-[#0CC5BA]/10 bg-gradient-to-br from-[#0CC5BA]/5 to-blue-500/5 backdrop-blur-xl hover:shadow-lg hover:shadow-[#0CC5BA]/20 transition-all duration-300 cursor-pointer">
                      <div className="aspect-square bg-gradient-to-br from-[#0CC5BA]/5 to-blue-500/5 relative group-hover:scale-[1.02] transition-transform duration-300">
                        <img
                          src={getDefaultImage(recipe)}
                          alt={recipe.name}
                          className="w-full h-48 object-cover"
                        />
                        {recipe.isPublic && (
                          <div className="absolute top-2 right-2 bg-white/80 backdrop-blur-sm rounded-full px-2 py-1 text-xs text-[#0CC5BA]">
                            Public
                          </div>
                        )}
                      </div>
                      <div className="p-4">
                        <h3 className="text-lg font-bold bg-gradient-to-br from-[#0CC5BA] via-[#0CBACC] to-[#0C9CCC] bg-clip-text text-transparent">
                          {recipe.name}
                        </h3>
                        <p className="text-sm text-gray-500 mt-1">{recipe.nutritionInfo?.calories || 0} Kcal</p>
                        {recipe.description && (
                          <p className="text-sm text-gray-500 mt-2 line-clamp-2">
                            {recipe.description}
                          </p>
                        )}
                      </div>
                    </Card>
                  </CarouselItem>
                ))}
              </CarouselContent>
              <CarouselPrevious className="text-[#0CC5BA] hover:text-[#0CC5BA] hover:bg-[#0CC5BA]/10" />
              <CarouselNext className="text-[#0CC5BA] hover:text-[#0CC5BA] hover:bg-[#0CC5BA]/10" />
            </Carousel>
          ) : (
            <div className="text-center py-8 text-gray-500">
              <p>No personal recipes yet. Create your first recipe!</p>
            </div>
          )}
        </section>

        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold bg-gradient-to-br from-[#0CC5BA] via-[#0CBACC] to-[#0C9CCC] bg-clip-text text-transparent">Top 10 Recipes</h2>
            <span className="text-sm text-gray-500">Global Favorites</span>
          </div>
          {topRecipes && topRecipes.length > 0 ? (
            <Carousel className="w-full">
              <CarouselContent className="-ml-4">
                {topRecipes.map((recipe) => (
                  <CarouselItem key={recipe.id} className="pl-4 basis-[280px]">
                    <Card className="overflow-hidden rounded-[28px] border-[#0CC5BA]/10 bg-gradient-to-br from-[#0CC5BA]/5 to-blue-500/5 backdrop-blur-xl hover:shadow-lg hover:shadow-[#0CC5BA]/20 transition-all duration-300 cursor-pointer">
                      <div className="aspect-square bg-gradient-to-br from-[#0CC5BA]/5 to-blue-500/5 relative group-hover:scale-[1.02] transition-transform duration-300">
                        <img
                          src={getDefaultImage(recipe)}
                          alt={recipe.name}
                          className="w-full h-48 object-cover"
                        />
                      </div>
                      <div className="p-4">
                        <h3 className="text-lg font-bold bg-gradient-to-br from-[#0CC5BA] via-[#0CBACC] to-[#0C9CCC] bg-clip-text text-transparent">
                          {recipe.name}
                        </h3>
                        <p className="text-sm text-gray-500 mt-1">{recipe.nutritionInfo?.calories || 0} Kcal</p>
                        <div className="flex items-center gap-2 mt-2">
                          <Heart className="w-4 h-4 text-red-500 fill-current" />
                          <span className="text-sm text-gray-500">{recipe.likesCount}</span>
                        </div>
                        {recipe.description && (
                          <p className="text-sm text-gray-500 mt-2 line-clamp-2">
                            {recipe.description}
                          </p>
                        )}
                      </div>
                    </Card>
                  </CarouselItem>
                ))}
              </CarouselContent>
              <CarouselPrevious className="text-[#0CC5BA] hover:text-[#0CC5BA] hover:bg-[#0CC5BA]/10" />
              <CarouselNext className="text-[#0CC5BA] hover:text-[#0CC5BA] hover:bg-[#0CC5BA]/10" />
            </Carousel>
          ) : (
            <div className="text-center py-8 text-gray-500">
              <p>No top recipes available yet</p>
            </div>
          )}
        </section>
        <BottomNav />
      </motion.main>
    </div>
  );
}