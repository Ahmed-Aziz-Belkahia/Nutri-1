import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, Camera, Heart } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";
import BottomNav from "@/components/BottomNav";
import { useFoodLog } from "../hooks/use-food-log";
import { useUser } from "../hooks/use-user";
import { Zap, ChevronRight } from "lucide-react";
import { Suspense, lazy } from "react";


// Animation variants
const containerVariants = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.2
    }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 }
};

function getMealTime(date: Date): string {
  const hour = date.getHours();
  if (hour < 10) return "Breakfast";
  if (hour < 14) return "Lunch";
  if (hour < 18) return "Snack";
  return "Dinner";
}

const formatNumber = (value: number | null | undefined): string => {
  if (value === null || value === undefined) return "0";
  const num = Number(value);
  if (num >= 1000) {
    return (num / 1000).toFixed(1) + 'k';
  }
  return num.toFixed(0);
};

export default function Dashboard() {
  const [, setLocation] = useLocation();
  const { foodLogs, todayTotals, isLoadingLogs } = useFoodLog();
  const { logout } = useUser();
  const [showScanner, setShowScanner] = useState(false);

  // Calorie calculation
  const calorieGoal = 2000; // TODO: Get this from user preferences
  const caloriePercentage = Math.min(Math.round((Number(todayTotals.calories || 0) / calorieGoal) * 100), 100);

  const handleLogout = async () => {
    try {
      await logout();
      setLocation('/');
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  if (isLoadingLogs) {
    return (
      <motion.div 
        className="min-h-screen flex items-center justify-center"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
      >
        <Loader2 className="h-8 w-8 animate-spin text-[#0CC5BA]" />
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen bg-gradient-to-br from-[#0CC5BA]/5 to-blue-500/5"
    >
      <motion.header
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="sticky top-0 w-full bg-white/80 border-b border-zinc-100/80 backdrop-blur-xl z-10"
      >
        <div className="max-w-[500px] mx-auto px-6 py-6">
          <div className="space-y-6">
            <motion.h1
              initial={{ x: -20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              className="text-3xl font-bold bg-gradient-to-br from-[#0CC5BA] via-[#0CBACC] to-[#0C9CCC] bg-clip-text text-transparent"
            >
              Dashboard
            </motion.h1>
            <motion.div
              variants={containerVariants}
              initial="hidden"
              animate="show"
              className="flex items-center gap-6"
            >
              <Link href="/dashboard">
                <motion.span 
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="text-base font-medium bg-gradient-to-br from-[#0CC5BA] via-[#0CBACC] to-[#0C9CCC] bg-clip-text text-transparent"
                >
                  Overview
                </motion.span>
              </Link>
              <Link href="/recipes">
                <motion.span 
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="text-base font-medium text-gray-500 hover:text-[#0CC5BA] transition-colors"
                >
                  Recipes
                </motion.span>
              </Link>
              <Link href="/progress">
                <motion.span 
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="text-base font-medium text-gray-500 hover:text-[#0CC5BA] transition-colors"
                >
                  Progress
                </motion.span>
              </Link>
            </motion.div>
          </div>
        </div>
      </motion.header>

      <motion.main
        variants={containerVariants}
        initial="hidden"
        animate="show"
        className="flex-1 px-4 pb-24 max-w-[500px] mx-auto"
      >
        <motion.div variants={itemVariants}>
          <Card className="mt-6 p-6 rounded-[28px] border-[#0CC5BA]/10 bg-white/80 backdrop-blur-xl overflow-hidden group hover:shadow-lg hover:shadow-[#0CC5BA]/20 transition-all duration-300">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <motion.div
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#0CC5BA]/10 to-blue-500/10 flex items-center justify-center group-hover:scale-110 transition-transform duration-300 border border-[#0CC5BA]/20 shadow-[0_0_15px_rgba(12,197,186,0.1)]"
                >
                  <Zap className="w-6 h-6 text-[#0CC5BA]" strokeWidth={2} />
                </motion.div>
                <div>
                  <div className="text-3xl font-medium text-gray-900 leading-none tracking-tight">
                    {formatNumber(todayTotals.calories)}
                    <span className="text-xl ml-1 text-gray-400">kcal</span>
                  </div>
                  <div className="text-sm text-gray-500 mt-1">
                    of {formatNumber(calorieGoal)} kcal goal
                  </div>
                </div>
              </div>

              <div className="relative" style={{ width: "120px", height: "120px" }}>
                <svg viewBox="0 0 100 100" className="transform -rotate-90">
                  <circle
                    cx="50"
                    cy="50"
                    r="45"
                    fill="none"
                    stroke="rgba(0,0,0,0.05)"
                    strokeWidth="6"
                  />
                  <motion.circle
                    cx="50"
                    cy="50"
                    r="45"
                    fill="none"
                    stroke="url(#progressGradient)"
                    strokeWidth="6"
                    strokeDasharray={`${2 * Math.PI * 45}`}
                    initial={{ strokeDashoffset: 2 * Math.PI * 45 }}
                    animate={{ strokeDashoffset: 2 * Math.PI * 45 * (1 - caloriePercentage / 100) }}
                    transition={{ duration: 1.5, ease: "easeOut" }}
                    className="drop-shadow-[0_0_8px_rgba(12,197,186,0.3)]"
                  />
                  <defs>
                    <linearGradient id="progressGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#0CC5BA" />
                      <stop offset="100%" stopColor="#3B82F6" />
                    </linearGradient>
                  </defs>
                </svg>
                <motion.div 
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.5, type: "spring" }}
                  className="absolute inset-0 flex items-center justify-center"
                >
                  <span className="text-2xl font-medium text-gray-900">
                    {caloriePercentage}%
                  </span>
                </motion.div>
              </div>
            </div>

            <motion.div variants={itemVariants} className="grid grid-cols-3 gap-6 mt-8">
              {[
                { label: "Carbs", value: todayTotals.carbs, max: 250, delay: 0 },
                { label: "Protein", value: todayTotals.protein, max: 150, delay: 0.2 },
                { label: "Fat", value: todayTotals.fat, max: 65, delay: 0.4 }
              ].map((macro, index) => (
                <motion.div
                  key={macro.label}
                  variants={itemVariants}
                  className="space-y-2"
                >
                  <div className="h-[6px] bg-black/5 rounded-full overflow-hidden">
                    <motion.div
                      className="h-full bg-gradient-to-r from-[#0CC5BA] to-blue-500 rounded-full origin-left shadow-[0_0_8px_rgba(12,197,186,0.2)]"
                      initial={{ scaleX: 0 }}
                      animate={{ scaleX: Math.min((Number(macro.value || 0) / macro.max), 1) }}
                      transition={{ duration: 1, ease: "easeOut", delay: macro.delay }}
                    />
                  </div>
                  <div className="space-y-0.5">
                    <motion.div 
                      variants={itemVariants}
                      className="text-[13px] text-gray-900 font-medium"
                    >
                      {formatNumber(Number(macro.value))}g
                    </motion.div>
                    <motion.div 
                      variants={itemVariants}
                      className="text-[13px] text-gray-400"
                    >
                      {macro.label}
                    </motion.div>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </Card>
        </motion.div>

        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => setShowScanner(true)}
          className="fixed bottom-8 right-8 w-16 h-16 rounded-full bg-[#0CC5BA] text-white shadow-lg shadow-[#0CC5BA]/20 flex items-center justify-center hover:bg-[#0CC5BA]/90 transition-colors"
        >
          <Camera className="w-8 h-8" />
        </motion.button>

        <div className="mt-8 space-y-4">
          <motion.div variants={itemVariants} className="flex items-center justify-between">
            <h2 className="text-[22px] font-bold bg-gradient-to-br from-[#0CC5BA] via-[#0CBACC] to-[#0C9CCC] bg-clip-text text-transparent">
              Today's Meals
            </h2>
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button
                variant="ghost"
                size="sm"
                className="text-[#0CC5BA] hover:text-[#0CC5BA]/80 hover:bg-[#0CC5BA]/5 -mr-2 group"
              >
                View all
                <motion.span
                  className="inline-block ml-1"
                  whileHover={{ x: 2 }}
                  transition={{ type: "spring", stiffness: 300 }}
                >
                  →
                </motion.span>
              </Button>
            </motion.div>
          </motion.div>

          <AnimatePresence>
            {foodLogs && foodLogs.length > 0 ? (
              <motion.div
                variants={containerVariants}
                initial="hidden"
                animate="show"
                className="grid grid-cols-2 gap-4"
              >
                {foodLogs.map((log, index) => (
                  <motion.div
                    key={log.id}
                    variants={itemVariants}
                    whileHover={{ y: -5 }}
                    transition={{ type: "spring", stiffness: 300 }}
                  >
                    <Link href={`/food/${log.id}`}>
                      <Card className="overflow-hidden rounded-[28px] border-[#0CC5BA]/10 bg-white/80 backdrop-blur-xl hover:shadow-lg hover:shadow-[#0CC5BA]/20 transition-all duration-300 cursor-pointer group">
                        <motion.div
                          className="aspect-square bg-gradient-to-br from-[#0CC5BA]/5 to-blue-500/5 relative group-hover:scale-[1.02] transition-transform duration-300"
                          whileHover={{ scale: 1.05 }}
                        >
                          {log.image ? (
                            <img
                              src={log.image}
                              alt={log.name}
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-5xl">
                              🍽️
                            </div>
                          )}
                        </motion.div>
                        <div className="p-4">
                          <motion.h3
                            variants={itemVariants}
                            className="text-[17px] font-medium text-gray-900 group-hover:text-[#0CC5BA] transition-colors"
                          >
                            {log.name}
                          </motion.h3>
                          <motion.p
                            variants={itemVariants}
                            className="text-[13px] text-gray-400"
                          >
                            {getMealTime(new Date(log.date))}
                          </motion.p>
                          <motion.p
                            variants={itemVariants}
                            className="text-[15px] text-gray-900 mt-2 font-medium"
                          >
                            {formatNumber(log.calories)} Kcal
                          </motion.p>
                        </div>
                      </Card>
                    </Link>
                  </motion.div>
                ))}
              </motion.div>
            ) : (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="text-center py-8"
              >
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", stiffness: 200 }}
                  className="text-4xl mb-3"
                >
                  🍽️
                </motion.div>
                <motion.p
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.2 }}
                  className="text-gray-500"
                >
                  No meals logged today.
                </motion.p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.main>
      <AnimatePresence>
        {showScanner && (
          <Suspense fallback={
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center">
              <div className="text-white text-center">
                <div className="animate-spin rounded-full h-12 w-12 border-4 border-white border-t-transparent mx-auto mb-4"></div>
                <p>Loading camera...</p>
              </div>
            </div>
          }>
            <ScannerUI onClose={() => setShowScanner(false)} />
          </Suspense>
        )}
      </AnimatePresence>
    </motion.div>
  );
}