import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Camera, Plus, Upload } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useProgressPhotos } from "@/hooks/use-progress-photos";
import { Progress as ProgressBar } from "@/components/ui/progress";
import { useState } from "react";
import { Link } from "wouter";

// Animation variants
const containerVariants = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.3
    }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 }
};

export default function ProgressPage() {
  const [currentWeight, setCurrentWeight] = useState(78);
  const [targetWeight, setTargetWeight] = useState(85);
  const { photos = [], isLoading, addPhoto } = useProgressPhotos();

  // Streak data (to be connected to backend later)
  const streakData = {
    currentStreak: 0,
    longestStreak: 0,
    level: 1,
    xp: 0,
    xpNeeded: 100
  };

  // Filter photos by type
  const lastPhoto = photos.find(p => p.type === 'latest');
  const favoritePhoto = photos.find(p => p.type === 'favorite');
  const firstPhoto = photos.find(p => p.type === 'first');

  const handlePhotoUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Convert to base64 for storage/preview
    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64String = reader.result as string;
      try {
        await addPhoto({
          photoUrl: base64String,
          type: 'latest',
        });
      } catch (error) {
        console.error('Failed to upload photo:', error);
      }
    };
    reader.readAsDataURL(file);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen bg-gradient-to-br from-[#0CC5BA]/5 to-blue-500/5"
    >
      {/* Header */}
      <motion.header
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="sticky top-0 w-full bg-white/80 border-b border-zinc-100/80 backdrop-blur-xl z-10"
      >
        <div className="max-w-[500px] mx-auto px-6 py-6">
          <div className="space-y-6">
            <motion.h1
              initial={{ x: -20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              className="text-3xl font-bold bg-gradient-to-br from-[#0CC5BA] via-[#0CBACC] to-[#0C9CCC] bg-clip-text text-transparent"
            >
              My Progress
            </motion.h1>
            <motion.div
              variants={containerVariants}
              initial="hidden"
              animate="show"
              className="flex items-center gap-6"
            >
              <Link href="/dashboard">
                <motion.span
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="text-base font-medium text-gray-500 hover:text-[#0CC5BA] transition-colors"
                >
                  Overview
                </motion.span>
              </Link>
              <Link href="/recipes">
                <motion.span
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="text-base font-medium text-gray-500 hover:text-[#0CC5BA] transition-colors"
                >
                  Recipes
                </motion.span>
              </Link>
              <Link href="/progress">
                <motion.span
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="text-base font-medium bg-gradient-to-br from-[#0CC5BA] via-[#0CBACC] to-[#0C9CCC] bg-clip-text text-transparent"
                >
                  Progress
                </motion.span>
              </Link>
            </motion.div>
          </div>
        </div>
      </motion.header>

      <motion.main
        variants={containerVariants}
        initial="hidden"
        animate="show"
        className="flex-1 px-4 pb-24 max-w-[500px] mx-auto"
      >
        {/* Streak Section */}
        <motion.div variants={itemVariants}>
          <Card className="p-6 rounded-[28px] border-[#0CC5BA]/10 bg-white mt-6">
            <div className="flex items-center gap-3">
              <motion.div
                whileHover={{ scale: 1.1, rotate: 360 }}
                transition={{ duration: 0.5 }}
                className="w-12 h-12 flex items-center justify-center"
              >
                <svg viewBox="0 0 24 24" className="w-8 h-8 text-[#0CC5BA]">
                  <path fill="currentColor" d="M11 9.47V11h2V9.47a4.505 4.505 0 0 0 3.5-4.4A4.481 4.481 0 0 0 12 .5 4.481 4.481 0 0 0 7.5 5.07c0 2.1 1.4 3.8 3.5 4.4zM12 2.5c1.93 0 3.5 1.57 3.5 3.5S13.93 9.5 12 9.5 8.5 7.93 8.5 6 10.07 2.5 12 2.5zM12 11.5c-1.93 0-3.5 1.57-3.5 3.5s1.57 3.5 3.5 3.5 3.5-1.57 3.5-3.5-1.57-3.5-3.5-3.5zm0 5c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5z"/>
                </svg>
              </motion.div>
              <div>
                <motion.div
                  variants={itemVariants}
                  className="text-3xl font-bold"
                >
                  {streakData.currentStreak} Day Streak
                </motion.div>
                <motion.div
                  variants={itemVariants}
                  className="text-gray-500"
                >
                  Longest: {streakData.longestStreak} days
                </motion.div>
              </div>
            </div>

            {/* Level and XP Progress */}
            <motion.div
              variants={itemVariants}
              className="mt-4"
            >
              <div className="flex justify-between items-center text-sm mb-2">
                <span className="text-gray-500">Level {streakData.level}</span>
                <span className="text-gray-500">{streakData.xp} XP</span>
              </div>
              <motion.div
                initial={{ scaleX: 0 }}
                animate={{ scaleX: 1 }}
                transition={{ duration: 1, ease: "easeOut" }}
              >
                <ProgressBar 
                  value={(streakData.xp / streakData.xpNeeded) * 100} 
                  className="h-1"
                />
              </motion.div>
            </motion.div>

            {/* Motivational Message */}
            <motion.div
              variants={itemVariants}
              className="mt-4 text-sm text-gray-500 bg-gray-50 p-4 rounded-xl"
            >
              🎯 Keep up the momentum! You're making great progress on your health journey.
            </motion.div>
          </Card>
        </motion.div>

        {/* Weight Cards Grid */}
        <motion.div
          variants={containerVariants}
          className="grid grid-cols-2 gap-4 mt-6 mb-8"
        >
          {/* Current Weight Card */}
          <motion.div whileHover={{ scale: 1.02 }} transition={{ duration: 0.2 }}>
            <Card className="p-6 rounded-[28px] border-[#0CC5BA]/10 bg-gradient-to-br from-[#0CC5BA]/5 to-blue-500/5 backdrop-blur-xl">
              <div className="flex flex-col items-start gap-4">
                <div className="flex-1">
                  <motion.h3
                    variants={itemVariants}
                    className="text-lg font-bold bg-gradient-to-br from-[#0CC5BA] via-[#0CBACC] to-[#0C9CCC] bg-clip-text text-transparent"
                  >
                    Current Weight
                  </motion.h3>
                  <motion.p
                    variants={itemVariants}
                    className="text-3xl font-bold text-[#0CC5BA] mt-2"
                  >
                    {currentWeight} kg
                  </motion.p>
                </div>
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button 
                    onClick={() => {/* Add weight update logic */}} 
                    className="bg-[#0CC5BA] hover:bg-[#0CC5BA]/90 shadow-lg shadow-[#0CC5BA]/20"
                  >
                    Update Weight
                  </Button>
                </motion.div>
              </div>
            </Card>
          </motion.div>

          {/* Target Weight Card */}
          <motion.div whileHover={{ scale: 1.02 }} transition={{ duration: 0.2 }}>
            <Card className="p-6 rounded-[28px] border-[#0CC5BA]/10 bg-gradient-to-br from-[#0CC5BA]/5 to-blue-500/5 backdrop-blur-xl">
              <div className="flex flex-col items-start gap-4">
                <div className="flex-1">
                  <motion.h3
                    variants={itemVariants}
                    className="text-lg font-bold bg-gradient-to-br from-[#0CC5BA] via-[#0CBACC] to-[#0C9CCC] bg-clip-text text-transparent"
                  >
                    Target Weight
                  </motion.h3>
                  <motion.p
                    variants={itemVariants}
                    className="text-3xl font-bold text-[#0CC5BA] mt-2"
                  >
                    {targetWeight} kg
                  </motion.p>
                </div>
              </div>
            </Card>
          </motion.div>
        </motion.div>

        {/* Photo Upload Section */}
        <motion.div variants={itemVariants}>
          <Card className="p-6 rounded-[28px] border-[#0CC5BA]/10 bg-gradient-to-br from-[#0CC5BA]/5 to-blue-500/5 backdrop-blur-xl mb-8">
            <div className="flex justify-between items-center">
              <div>
                <motion.h2
                  variants={itemVariants}
                  className="text-lg font-bold bg-gradient-to-br from-[#0CC5BA] via-[#0CBACC] to-[#0C9CCC] bg-clip-text text-transparent"
                >
                  Progress Documentation
                </motion.h2>
                <motion.p
                  variants={itemVariants}
                  className="text-sm text-gray-500 mt-1"
                >
                  Add photos regularly to track your transformation
                </motion.p>
              </div>
            </div>
            <motion.div
              variants={itemVariants}
              className="flex justify-end mt-4"
            >
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button 
                  className="bg-[#0CC5BA] hover:bg-[#0CC5BA]/90 shadow-lg shadow-[#0CC5BA]/20"
                  onClick={() => document.getElementById('photo-upload')?.click()}
                >
                  <Upload className="w-4 h-4 mr-2" />
                  Add Photo to Gallery
                </Button>
              </motion.div>
              <input
                id="photo-upload"
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handlePhotoUpload}
              />
            </motion.div>
          </Card>
        </motion.div>

        {/* Gallery */}
        <motion.section
          variants={containerVariants}
          className="space-y-4 mb-8"
        >
          <div className="flex items-center justify-between">
            <motion.h2
              variants={itemVariants}
              className="text-xl font-bold bg-gradient-to-br from-[#0CC5BA] via-[#0CBACC] to-[#0C9CCC] bg-clip-text text-transparent"
            >
              Transformation Gallery
            </motion.h2>
            <motion.span
              variants={itemVariants}
              className="text-sm text-gray-500"
            >
              Progress Photos
            </motion.span>
          </div>
          <motion.div
            variants={containerVariants}
            className="grid grid-cols-3 gap-4"
          >
            {[
              { type: 'Latest Photo', photo: lastPhoto },
              { type: 'Favorite Photo', photo: favoritePhoto },
              { type: 'First Photo', photo: firstPhoto }
            ].map((item) => (
              <motion.div
                key={item.type}
                whileHover={{ scale: 1.05 }}
                transition={{ duration: 0.2 }}
              >
                <Card 
                  className="overflow-hidden rounded-[28px] border-[#0CC5BA]/10 bg-gradient-to-br from-[#0CC5BA]/5 to-blue-500/5 backdrop-blur-xl hover:shadow-lg hover:shadow-[#0CC5BA]/20 transition-all duration-300"
                >
                  <motion.div
                    className="aspect-[3/4] relative group"
                    whileHover={{ scale: 1.05 }}
                    transition={{ duration: 0.3 }}
                  >
                    {item.photo ? (
                      <img
                        src={item.photo.photoUrl}
                        alt={item.type}
                        className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-gray-100">
                        <Camera className="w-8 h-8 text-gray-400" />
                      </div>
                    )}
                    <motion.div
                      initial={{ opacity: 0 }}
                      whileHover={{ opacity: 1 }}
                      className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300"
                    />
                  </motion.div>
                  <motion.div
                    variants={itemVariants}
                    className="p-2"
                  >
                    <p className="text-xs text-center text-gray-600">{item.type}</p>
                  </motion.div>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </motion.section>
      </motion.main>
    </motion.div>
  );
}