import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ChevronLeft, Shield } from "lucide-react";
import { useLocation } from "wouter";
import { useState } from "react";

export default function SecurityPage() {
  const [, setLocation] = useLocation();
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    // TODO: Implement password change logic
  };

  return (
    <div className="min-h-screen bg-white">
      <header className="sticky top-0 bg-white/80 backdrop-blur-lg border-b border-zinc-100/80 z-10">
        <div className="px-4 py-4">
          <div className="flex items-center">
            <button onClick={() => setLocation("/settings")} className="-ml-2 p-2">
              <ChevronLeft className="h-6 w-6" />
            </button>
            <h1 className="text-lg font-medium ml-2">Security</h1>
          </div>
        </div>
      </header>

      <div className="px-4 py-6">
        <form onSubmit={handlePasswordChange} className="space-y-4">
          <div>
            <label className="text-sm font-medium">Current Password</label>
            <Input
              type="password"
              value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
              className="mt-1"
            />
          </div>

          <div>
            <label className="text-sm font-medium">New Password</label>
            <Input
              type="password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              className="mt-1"
            />
          </div>

          <div>
            <label className="text-sm font-medium">Confirm New Password</label>
            <Input
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              className="mt-1"
            />
          </div>

          <Button type="submit" className="w-full bg-[#10c4bc] hover:bg-[#0fb3ab] text-white">
            Change Password
          </Button>
        </form>

        <div className="mt-8 space-y-4">
          <Button 
            variant="outline" 
            className="w-full"
            onClick={() => {/* TODO: Implement 2FA setup */}}
          >
            Setup Two-Factor Authentication
          </Button>

          <Button 
            variant="outline" 
            className="w-full text-red-500 hover:text-red-600"
            onClick={() => {/* TODO: Implement account deletion */}}
          >
            Delete Account
          </Button>
        </div>
      </div>
    </div>
  );
}
