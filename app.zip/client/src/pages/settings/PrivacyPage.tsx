import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { ChevronLeft, Lock } from "lucide-react";
import { useLocation } from "wouter";
import { useState } from "react";

export default function PrivacyPage() {
  const [, setLocation] = useLocation();
  const [profileVisibility, setProfileVisibility] = useState(true);
  const [dataSharing, setDataSharing] = useState(false);
  const [analyticsCollection, setAnalyticsCollection] = useState(true);

  return (
    <div className="min-h-screen bg-white">
      <header className="sticky top-0 bg-white/80 backdrop-blur-lg border-b border-zinc-100/80 z-10">
        <div className="px-4 py-4">
          <div className="flex items-center">
            <button onClick={() => setLocation("/settings")} className="-ml-2 p-2">
              <ChevronLeft className="h-6 w-6" />
            </button>
            <h1 className="text-lg font-medium ml-2">Privacy</h1>
          </div>
        </div>
      </header>

      <div className="px-4 py-6 space-y-6">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <div className="text-sm font-medium">Profile Visibility</div>
            <div className="text-sm text-gray-500">Make your profile visible to other users</div>
          </div>
          <Switch
            checked={profileVisibility}
            onCheckedChange={setProfileVisibility}
            className="data-[state=checked]:bg-[#10c4bc]"
          />
        </div>

        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <div className="text-sm font-medium">Data Sharing</div>
            <div className="text-sm text-gray-500">Share your progress with the community</div>
          </div>
          <Switch
            checked={dataSharing}
            onCheckedChange={setDataSharing}
            className="data-[state=checked]:bg-[#10c4bc]"
          />
        </div>

        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <div className="text-sm font-medium">Analytics Collection</div>
            <div className="text-sm text-gray-500">Help us improve by sharing usage data</div>
          </div>
          <Switch
            checked={analyticsCollection}
            onCheckedChange={setAnalyticsCollection}
            className="data-[state=checked]:bg-[#10c4bc]"
          />
        </div>

        <div className="mt-8">
          <Button 
            variant="outline" 
            className="w-full text-red-500 hover:text-red-600"
            onClick={() => {/* TODO: Implement data deletion */}}
          >
            Delete All My Data
          </Button>
        </div>
      </div>
    </div>
  );
}
