import { ChevronLeft, ExternalLink } from "lucide-react";
import { useLocation } from "wouter";

export default function HelpPage() {
  const [, setLocation] = useLocation();

  const helpItems = [
    {
      title: "Getting Started",
      description: "Learn the basics of using Nutri AI",
      link: "#"
    },
    {
      title: "Tracking Meals",
      description: "How to log and track your meals effectively",
      link: "#"
    },
    {
      title: "Progress Tracking",
      description: "Understanding your progress metrics",
      link: "#"
    },
    {
      title: "FAQ",
      description: "Frequently asked questions",
      link: "#"
    },
    {
      title: "Contact Support",
      description: "Get help from our support team",
      link: "#"
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      <header className="sticky top-0 bg-white/80 backdrop-blur-lg border-b border-zinc-100/80 z-10">
        <div className="px-4 py-4">
          <div className="flex items-center">
            <button onClick={() => setLocation("/settings")} className="-ml-2 p-2">
              <ChevronLeft className="h-6 w-6" />
            </button>
            <h1 className="text-lg font-medium ml-2">Help</h1>
          </div>
        </div>
      </header>

      <div className="px-4 py-6">
        <div className="space-y-4">
          {helpItems.map((item) => (
            <a
              key={item.title}
              href={item.link}
              className="block p-4 rounded-lg border border-gray-100 hover:border-[#10c4bc] transition-colors"
            >
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">{item.title}</h3>
                  <p className="text-sm text-gray-500 mt-1">{item.description}</p>
                </div>
                <ExternalLink className="h-5 w-5 text-gray-400" />
              </div>
            </a>
          ))}
        </div>
      </div>
    </div>
  );
}
