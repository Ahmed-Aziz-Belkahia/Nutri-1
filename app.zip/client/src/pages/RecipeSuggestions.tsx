import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Camera, Loader2, PlayCircle, ChevronRight, ArrowLeft } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import Webcam from "react-webcam";
import Navigation from "../components/Navigation";
import { useMutation } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";

export default function RecipeSuggestions() {
  const [showCamera, setShowCamera] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const webcamRef = useRef<Webcam>(null);
  const { toast } = useToast();
  const [suggestedRecipes, setSuggestedRecipes] = useState<any[]>([]);
  const [, setLocation] = useLocation();

  const analyzeImageMutation = useMutation({
    mutationFn: async (imageData: string) => {
      const response = await fetch('/api/analyze-ingredients', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ image: imageData }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to analyze ingredients');
      }

      return response.json();
    },
    onSuccess: (data) => {
      setSuggestedRecipes(data.recipes);
      toast({
        title: "Recipes Generated! 👩‍🍳",
        description: "Here are some recipes you can make with your ingredients",
      });
    },
    onError: (error: Error) => {
      console.error('Failed to analyze image:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to analyze ingredients. Please try again.",
        variant: "destructive",
      });
    },
  });

  const captureImage = async () => {
    if (!webcamRef.current) return;

    setIsAnalyzing(true);
    try {
      const imageSrc = webcamRef.current.getScreenshot();
      if (!imageSrc) {
        throw new Error("Failed to capture image");
      }

      await analyzeImageMutation.mutateAsync(imageSrc);
      setShowCamera(false);
    } catch (error) {
      console.error('Failed to process image:', error);
      toast({
        title: "Error",
        description: "Failed to process the image. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  if (showCamera) {
    return (
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.3 }}
        className="fixed inset-0 bg-black/95 z-50"
      >
        <motion.div 
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2, type: "spring", stiffness: 300, damping: 30 }}
          className="fixed top-0 left-0 right-0 bg-black/50 backdrop-blur-xl px-4 py-3 flex items-center z-10"
        >
          <div className="flex items-center justify-between w-full max-w-[500px] mx-auto">
            <Button 
              variant="ghost" 
              size="icon" 
              className="text-white hover:bg-white/10 transition-colors -ml-2"
              onClick={() => setShowCamera(false)}
            >
              <ArrowLeft className="h-6 w-6" />
            </Button>
            <span className="font-medium text-white text-lg">Scan Ingredients</span>
            <div className="w-10" />
          </div>
        </motion.div>

        <motion.div 
          initial={{ scale: 1.1, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.4, ease: "easeOut" }}
          className="pt-[60px] relative h-screen"
        >
          <Webcam
            ref={webcamRef}
            audio={false}
            screenshotFormat="image/jpeg"
            videoConstraints={{
              facingMode: "environment",
              aspectRatio: 3/4,
              width: { ideal: 1080 },
              height: { ideal: 1440 }
            }}
            className="w-full h-full object-cover"
          />

          <motion.div 
            className="absolute inset-0 pointer-events-none"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
          >
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
              <div className="relative w-72 h-72">
                <div className="absolute top-0 left-0 w-8 h-8 border-l-2 border-t-2 border-white/80 rounded-tl-lg" />
                <div className="absolute top-0 right-0 w-8 h-8 border-r-2 border-t-2 border-white/80 rounded-tr-lg" />
                <div className="absolute bottom-0 left-0 w-8 h-8 border-l-2 border-b-2 border-white/80 rounded-bl-lg" />
                <div className="absolute bottom-0 right-0 w-8 h-8 border-r-2 border-b-2 border-white/80 rounded-br-lg" />

                <motion.div 
                  className="absolute inset-x-8 h-0.5 bg-gradient-to-r from-transparent via-white/80 to-transparent"
                  animate={{
                    y: [-140, 140, -140],
                  }}
                  transition={{
                    duration: 2.5,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                />
              </div>
            </div>

            <div className="absolute bottom-36 left-1/2 -translate-x-1/2 text-white/70 text-sm text-center">
              Position ingredients in the frame
            </div>
          </motion.div>

          <motion.div 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="absolute bottom-16 inset-x-0 flex items-center justify-center"
          >
            <motion.button
              whileTap={{ scale: 0.95 }}
              whileHover={{ scale: 1.05 }}
              disabled={isAnalyzing}
              onClick={captureImage}
              className={`relative w-20 h-20 rounded-full flex items-center justify-center ${
                isAnalyzing 
                  ? 'bg-white/50' 
                  : 'bg-white hover:bg-white/90'
              } disabled:opacity-50 border-[6px] border-white/20 shadow-lg transition-colors`}
            >
              {isAnalyzing ? (
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                >
                  <Loader2 className="h-8 w-8 animate-spin text-black/70" />
                </motion.div>
              ) : (
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                >
                  <Camera className="h-8 w-8 text-black/70" />
                </motion.div>
              )}

              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="absolute -bottom-8 left-1/2 -translate-x-1/2 whitespace-nowrap text-sm text-white/90"
              >
                {isAnalyzing ? 'Analyzing...' : 'Tap to capture'}
              </motion.div>
            </motion.button>
          </motion.div>
        </motion.div>
      </motion.div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-[500px] mx-auto relative min-h-screen flex flex-col">
        <motion.header 
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="sticky top-0 bg-white/80 backdrop-blur-lg border-b border-zinc-100/80 z-10"
        >
          <div className="px-4 py-4">
            <div className="space-y-2.5">
              <motion.h1 
                initial={{ x: -20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                className="text-xl font-semibold bg-gradient-to-r from-gray-900 to-gray-600 bg-clip-text text-transparent"
              >
                Hi, Good morning
              </motion.h1>
              <motion.div 
                initial={{ x: -20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: 0.1 }}
                className="flex items-center gap-8"
              >
                <Link href="/">
                  <span className={`text-sm cursor-pointer transition-all ${
                    location === '/' 
                      ? 'font-semibold text-gray-900' 
                      : 'text-gray-400 hover:text-gray-600 hover:translate-x-0.5'
                  }`}>
                    Home
                  </span>
                </Link>
                <Link href="/recipes">
                  <span className={`text-sm cursor-pointer transition-all ${
                    location === '/recipes' 
                      ? 'font-semibold text-gray-900' 
                      : 'text-gray-400 hover:text-gray-600 hover:translate-x-0.5'
                  }`}>
                    Recipes
                  </span>
                </Link>
              </motion.div>
            </div>
          </div>
        </motion.header>

        <div className="flex-1 px-4 pb-24">
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            <Card 
              className="group p-5 rounded-2xl bg-gradient-to-br from-[#E8F8F7] to-[#F0FFFE] border-0 mb-6 mt-4 cursor-pointer hover:shadow-lg transition-all duration-300"
              onClick={() => setShowCamera(true)}
            >
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-medium mb-1.5 group-hover:text-[#0CC5BA] transition-colors">
                    Create Your Recipe
                  </h3>
                  <p className="text-sm text-gray-600">
                    Scan your ingredients and we'll suggest healthy meals
                  </p>
                </div>
                <motion.div
                  whileHover={{ scale: 1.1, rotate: 90 }}
                  transition={{ type: "spring", stiffness: 400, damping: 10 }}
                >
                  <PlayCircle className="w-14 h-14 text-[#0CC5BA] group-hover:text-[#0AB3A9] transition-colors" />
                </motion.div>
              </div>
            </Card>
          </motion.div>

          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.3 }}
          >
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-lg font-semibold bg-gradient-to-r from-gray-900 to-gray-600 bg-clip-text text-transparent">
                {suggestedRecipes.length > 0 ? 'Suggested Recipes' : 'TOP 100'}
              </h2>
              <Button 
                variant="ghost" 
                size="sm" 
                className="text-[#0CC5BA] hover:text-[#0AB3A9] -mr-2 group"
              >
                View all 
                <ChevronRight className="w-4 h-4 ml-1 group-hover:translate-x-0.5 transition-transform" />
              </Button>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {(suggestedRecipes.length > 0 ? suggestedRecipes : commonRecipes).map((recipe, index) => (
                <motion.div
                  key={recipe.id}
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.1 * index }}
                  onClick={() => setLocation(`/recipe/${recipe.id}`)}
                >
                  <Card className="overflow-hidden rounded-2xl border-0 hover:shadow-lg transition-all duration-300 cursor-pointer group">
                    <div className={`aspect-square ${recipe.bgColor || 'bg-[#E8F8F7]'} relative p-4 flex items-center justify-center group-hover:scale-[1.02] transition-transform duration-300`}>
                      <span className="text-5xl transform group-hover:scale-110 transition-transform duration-300">
                        {recipe.emoji || '🥗'}
                      </span>
                    </div>
                    <div className="p-4">
                      <h3 className="font-medium text-[15px] leading-snug group-hover:text-[#0CC5BA] transition-colors">
                        {recipe.name}
                      </h3>
                      <p className="text-xs text-gray-500 whitespace-pre-line mt-1.5 leading-relaxed">
                        {recipe.description}
                      </p>
                    </div>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>

        <Navigation />
      </div>
    </div>
  );
}

const commonRecipes = [
  {
    id: 1,
    name: "Green Salad",
    description: "Fresh romaine lettuce\nClassic Greek style",
    bgColor: "bg-[#E8F8F7]",
    emoji: "🥗"
  },
  {
    id: 2,
    name: "Thai salad",
    description: "Green papaya salad\nAuthentic Thai spices",
    bgColor: "bg-[#FCE8E8]",
    emoji: "🥘"
  },
  {
    id: 3,
    name: "Chicken salad",
    description: "Grilled chicken breast\nCrisp mixed greens",
    bgColor: "bg-[#E8F8F7]",
    emoji: "🥙"
  },
  {
    id: 4,
    name: "Tuna salad",
    description: "Fresh tuna\nMediterranean style",
    bgColor: "bg-[#FCE8E8]",
    emoji: "🐟"
  },
];