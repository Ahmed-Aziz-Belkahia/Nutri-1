import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useUser } from "@/hooks/use-user";
import { useState } from "react";
import { Link, useLocation } from "wouter";
import WeightLogWidget from "@/components/WeightLogWidget";
import { Camera } from "lucide-react";
import { useProgressPhotos } from "@/hooks/use-progress-photos";

export default function Overview() {
  const { user } = useUser();
  const [currentWeight, setCurrentWeight] = useState(78);
  const [goalWeight, setGoalWeight] = useState(85);
  const [location] = useLocation();
  const { photos = [], isLoading: isLoadingPhotos } = useProgressPhotos();

  const handleWeightUpdate = (newWeight: number) => {
    setCurrentWeight(newWeight);
  };

  // Filter photos by type
  const latestPhoto = photos.find(p => p.type === 'latest');
  const favoritePhoto = photos.find(p => p.type === 'favorite');
  const firstPhoto = photos.find(p => p.type === 'first');

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-[#0CC5BA]/5 to-blue-500/5">
      <header className="sticky top-0 w-full bg-white/80 border-b border-zinc-100/80 backdrop-blur-xl z-10">
        <div className="max-w-[500px] mx-auto px-6 py-6">
          <div className="space-y-6">
            <h1 className="text-3xl font-bold bg-gradient-to-br from-[#0CC5BA] via-[#0CBACC] to-[#0C9CCC] bg-clip-text text-transparent">
              Dashboard
            </h1>
            <div className="flex items-center gap-6">
              <Link href="/dashboard">
                <span className="text-base font-medium bg-gradient-to-br from-[#0CC5BA] via-[#0CBACC] to-[#0C9CCC] bg-clip-text text-transparent">
                  Overview
                </span>
              </Link>
              <Link href="/recipes">
                <span className="text-base font-medium text-gray-500 hover:text-[#0CC5BA] transition-colors">
                  Recipes
                </span>
              </Link>
              <Link href="/progress">
                <span className="text-base font-medium text-gray-500 hover:text-[#0CC5BA] transition-colors">
                  Progress
                </span>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Content Section */}
      <div className="flex-1 p-4 space-y-4 max-w-[500px] mx-auto">
        {/* Current Weight Card */}
        <Card className="p-4 bg-white border-0 shadow-sm">
          <div className="space-y-4">
            <div className="space-y-2">
              <h2 className="text-sm text-gray-600">Current Weight</h2>
              <p className="text-xs text-gray-500">
                Monitor and update your weight regularly to track your progress.
              </p>
            </div>
            <WeightLogWidget 
              currentWeight={currentWeight}
              goalWeight={goalWeight}
              onWeightUpdate={handleWeightUpdate}
            />
          </div>
        </Card>

        {/* Goal Weight Display */}
        <div className="flex items-center justify-between px-2">
          <div className="flex items-center gap-2">
            <span className="text-sm text-gray-500">Goal Weight</span>
            <span className="text-sm font-medium">{goalWeight} kg</span>
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="text-blue-600 hover:text-blue-700"
            onClick={() => {/* TODO: Implement photo upload */}}
          >
            <Camera className="w-4 h-4 mr-2" />
            <span className="text-sm">Add Photo</span>
          </Button>
        </div>

        {/* Progress Photos Section */}
        <div className="mt-6">
          <h3 className="text-lg font-semibold mb-4">PROGRESS</h3>
          <div className="grid grid-cols-3 gap-3">
            {[
              { type: "Latest", photo: latestPhoto },
              { type: "Favorite", photo: favoritePhoto },
              { type: "First", photo: firstPhoto }
            ].map((item, index) => (
              <div key={index} className="space-y-1">
                <div className="aspect-[3/4] bg-gray-100 rounded-lg overflow-hidden shadow-sm">
                  {item.photo ? (
                    <img
                      src={item.photo.photoUrl}
                      alt={`${item.type} photo`}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-gray-400">
                      <Camera className="w-8 h-8" />
                    </div>
                  )}
                </div>
                <p className="text-xs text-center text-gray-600">{item.type}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}