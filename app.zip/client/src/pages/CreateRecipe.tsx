import { useState } from "react";
import { Card } from "@/components/ui/card";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronLeft, Utensils, Clock, DollarSign, Calendar, ChevronRight, Star, Eye } from "lucide-react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";

type MealType = "Breakfast" | "Lunch" | "Dinner" | "Snack" | "Dessert";

interface QuizData {
  mealType: MealType | "";
  calories: number;
  budget: number;
  days: number;
}

interface RecipeProposal {
  name: string;
  description: string;
  ingredients: string[];
  instructions: string;
  nutritionInfo: {
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
  };
  reviews: {
    rating: number;
    comment: string;
    userName: string;
  }[];
  avgRating: number;
  imageUrl: string;
}

const MEAL_TYPES = [
  { value: "Breakfast", label: "Breakfast", emoji: "🍳", description: "Start your day right" },
  { value: "Lunch", label: "Lunch", emoji: "🥗", description: "Midday fuel" },
  { value: "Dinner", label: "Dinner", emoji: "🍝", description: "Evening delight" },
  { value: "Snack", label: "Snack", emoji: "🍎", description: "Quick bites" },
  { value: "Dessert", label: "Dessert", emoji: "🍰", description: "Sweet treats" },
];

const stepIcons = {
  "Calories": <Clock className="h-5 w-5 text-[#0CC5BA]" />,
  "Budget": <DollarSign className="h-5 w-5 text-[#0CC5BA]" />,
  "Duration": <Calendar className="h-5 w-5 text-[#0CC5BA]" />,
};

export default function CreateRecipe() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [quizData, setQuizData] = useState<QuizData>({
    mealType: "",
    calories: 500,
    budget: 10,
    days: 7
  });
  const [step, setStep] = useState(0);
  const [proposals, setProposals] = useState<RecipeProposal[]>([]);
  const [loading, setLoading] = useState(false);
  const [previewRecipe, setPreviewRecipe] = useState<RecipeProposal | null>(null);

  const handleMealTypeSelect = (selectedMealType: MealType) => {
    setQuizData(prev => ({ ...prev, mealType: selectedMealType }));
    setStep(1);
  };

  const fetchProposals = async () => {
    try {
      setLoading(true);
      const response = await fetch("/api/recipe-proposals", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(quizData),
        credentials: "include",
      });

      if (!response.ok) {
        throw new Error(await response.text());
      }

      const data = await response.json();
      setProposals(data);
    } catch (error) {
      console.error("Error fetching proposals:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to fetch recipe proposals",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleUseProposal = async (proposal: RecipeProposal) => {
    try {
      const response = await fetch("/api/recipes", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name: proposal.name,
          description: proposal.description,
          ingredients: proposal.ingredients,
          instructions: proposal.instructions,
          nutritionInfo: proposal.nutritionInfo,
          isPublic: true,
        }),
        credentials: "include",
      });

      if (!response.ok) {
        throw new Error(await response.text());
      }

      setLocation("/recipes");
    } catch (error) {
      console.error("Error saving recipe:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to save recipe",
      });
    }
  };

  const handleNext = async () => {
    if (step < steps.length) {
      setStep(step + 1);
    } else {
      await fetchProposals();
      setStep(step + 1);
    }
  };

  const handleBack = () => {
    if (step > 0) {
      setStep(step - 1);
    } else {
      setLocation("/recipes");
    }
  };

  const steps = [
    {
      title: "Calories",
      description: "How many calories should this meal have?",
      component: (
        <div className="space-y-8">
          <Card className="p-6 border-[#0CC5BA]/10 bg-gradient-to-br from-[#0CC5BA]/5 to-blue-500/5">
            <Slider
              value={[quizData.calories]}
              onValueChange={([value]) =>
                setQuizData(prev => ({ ...prev, calories: value }))
              }
              max={2000}
              step={50}
              defaultValue={[500]}
              className="mt-6"
            />
            <motion.p
              className="text-center text-lg font-bold bg-gradient-to-br from-[#0CC5BA] via-[#0CBACC] to-[#0C9CCC] bg-clip-text text-transparent mt-6"
              animate={{ scale: [1, 1.05, 1] }}
              transition={{ duration: 0.3 }}
            >
              {quizData.calories} calories
            </motion.p>
          </Card>
        </div>
      )
    },
    {
      title: "Budget",
      description: "What's your budget per meal?",
      component: (
        <div className="space-y-8">
          <Card className="p-6 border-[#0CC5BA]/10 bg-gradient-to-br from-[#0CC5BA]/5 to-blue-500/5">
            <Slider
              value={[quizData.budget]}
              onValueChange={([value]) =>
                setQuizData(prev => ({ ...prev, budget: value }))
              }
              max={50}
              step={1}
              defaultValue={[10]}
              className="mt-6"
            />
            <motion.p
              className="text-center text-lg font-bold bg-gradient-to-br from-[#0CC5BA] via-[#0CBACC] to-[#0C9CCC] bg-clip-text text-transparent mt-6"
              animate={{ scale: [1, 1.05, 1] }}
              transition={{ duration: 0.3 }}
            >
              ${quizData.budget.toFixed(2)}
            </motion.p>
          </Card>
        </div>
      )
    },
    {
      title: "Duration",
      description: "How many days should this meal plan cover?",
      component: (
        <div className="space-y-8">
          <Card className="p-6 border-[#0CC5BA]/10 bg-gradient-to-br from-[#0CC5BA]/5 to-blue-500/5">
            <Slider
              value={[quizData.days]}
              onValueChange={([value]) =>
                setQuizData(prev => ({ ...prev, days: value }))
              }
              min={2}
              max={30}
              step={1}
              defaultValue={[7]}
              className="mt-6"
            />
            <motion.p
              className="text-center text-lg font-bold bg-gradient-to-br from-[#0CC5BA] via-[#0CBACC] to-[#0C9CCC] bg-clip-text text-transparent mt-6"
              animate={{ scale: [1, 1.05, 1] }}
              transition={{ duration: 0.3 }}
            >
              {quizData.days} days
            </motion.p>
          </Card>
        </div>
      )
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0CC5BA]/5 to-blue-500/5">
      <motion.div
        className="fixed top-0 left-0 right-0 h-1 bg-[#0CC5BA]/20 z-50"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
      >
        <motion.div
          className="h-full bg-[#0CC5BA]"
          initial={{ width: 0 }}
          animate={{ width: `${((step + 1) / (steps.length + 2)) * 100}%` }}
          transition={{ duration: 0.3 }}
        />
      </motion.div>

      <div className="absolute top-4 left-4">
        <Button
          variant="ghost"
          size="icon"
          className="h-10 w-10 text-gray-600 hover:text-gray-900 hover:bg-black/5"
          onClick={handleBack}
        >
          <ChevronLeft className="h-6 w-6" />
        </Button>
      </div>

      <div className="max-w-[500px] mx-auto px-6 pt-20 pb-12">
        <AnimatePresence mode="wait">
          {step === 0 ? (
            <motion.div
              key="meal-type"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <div className="space-y-6">
                <div className="flex items-center space-x-3">
                  <div className="h-10 w-10 rounded-full bg-[#0CC5BA]/10 flex items-center justify-center">
                    <Utensils className="h-5 w-5 text-[#0CC5BA]" />
                  </div>
                  <h2 className="text-2xl font-bold bg-gradient-to-br from-[#0CC5BA] via-[#0CBACC] to-[#0C9CCC] bg-clip-text text-transparent">
                    Choose Meal Type
                  </h2>
                </div>
                <p className="text-gray-600">
                  What type of meal would you like to create?
                </p>
              </div>

              <div className="grid grid-cols-2 gap-4 mt-8">
                {MEAL_TYPES.map((type) => (
                  <motion.div
                    key={type.value}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <Card
                      className="p-6 cursor-pointer transition-all duration-300 hover:shadow-lg group border-[#0CC5BA]/10 bg-gradient-to-br from-[#0CC5BA]/5 to-blue-500/5 backdrop-blur-xl hover:shadow-[#0CC5BA]/20"
                      onClick={() => handleMealTypeSelect(type.value as MealType)}
                    >
                      <div className="flex flex-col items-center text-center space-y-3">
                        <motion.span
                          className="text-4xl transform group-hover:scale-110 transition-transform duration-300"
                          whileHover={{
                            scale: 1.2,
                            rotate: [0, 10, 0]
                          }}
                        >
                          {type.emoji}
                        </motion.span>
                        <div className="space-y-1">
                          <span className="font-medium block text-gray-900 group-hover:text-[#0CC5BA] transition-colors">
                            {type.label}
                          </span>
                          <span className="text-xs text-gray-500">{type.description}</span>
                        </div>
                      </div>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          ) : step <= steps.length ? (
            <motion.div
              key={`step-${step}`}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-8"
            >
              <div className="space-y-6">
                <div className="flex items-center space-x-3">
                  <div className="h-10 w-10 rounded-full bg-[#0CC5BA]/10 flex items-center justify-center">
                    {stepIcons[steps[step - 1].title as keyof typeof stepIcons]}
                  </div>
                  <h2 className="text-2xl font-bold bg-gradient-to-br from-[#0CC5BA] via-[#0CBACC] to-[#0C9CCC] bg-clip-text text-transparent">
                    {steps[step - 1].title}
                  </h2>
                </div>
                <p className="text-gray-600">
                  {steps[step - 1].description}
                </p>
              </div>

              {steps[step - 1].component}

              <Button
                onClick={handleNext}
                className="w-full h-12 bg-gradient-to-r from-[#0CC5BA] via-[#0CBACC] to-[#0C9CCC] text-white hover:opacity-90 transition-opacity rounded-xl"
              >
                Continue
                <ChevronRight className="ml-2 h-5 w-5" />
              </Button>
            </motion.div>
          ) : (
            <motion.div
              key="proposals"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-8"
            >
              <div className="space-y-6">
                <h2 className="text-2xl font-bold bg-gradient-to-br from-[#0CC5BA] via-[#0CBACC] to-[#0C9CCC] bg-clip-text text-transparent">
                  Recipe Suggestions
                </h2>
                <p className="text-gray-600">
                  Here are some recipes that match your preferences:
                </p>
              </div>

              {loading ? (
                <div className="text-center py-12">
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                    className="inline-block w-8 h-8 border-2 border-[#0CC5BA] border-t-transparent rounded-full"
                  />
                </div>
              ) : (
                <div className="space-y-6">
                  {proposals.map((proposal, index) => (
                    <Card
                      key={index}
                      className="overflow-hidden border border-zinc-100 hover:border-[#0CC5BA]/30 transition-colors"
                    >
                      <div className="aspect-video w-full relative overflow-hidden">
                        <img
                          src={proposal.imageUrl}
                          alt={proposal.name}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
                      </div>
                      <div className="p-6 space-y-4">
                        <div>
                          <h3 className="text-xl font-semibold">{proposal.name}</h3>
                          <p className="text-gray-600 text-sm mt-1">{proposal.description}</p>
                        </div>

                        <div className="flex items-center gap-2">
                          <div className="flex">
                            {Array.from({ length: 5 }).map((_, i) => (
                              <Star
                                key={i}
                                className={`h-4 w-4 ${
                                  i < Math.round(proposal.avgRating)
                                    ? "text-yellow-400 fill-yellow-400"
                                    : "text-gray-300"
                                }`}
                              />
                            ))}
                          </div>
                          <span className="text-sm text-gray-500">{proposal.reviews.length} reviews</span>
                        </div>

                        <div className="space-y-3">
                          {proposal.reviews.map((review, idx) => (
                            <div key={idx} className="bg-gray-50 rounded-lg p-3">
                              <div className="flex items-center gap-2">
                                <span className="font-medium text-sm">{review.userName}</span>
                              </div>
                              <p className="text-sm text-gray-600 mt-1">{review.comment}</p>
                            </div>
                          ))}
                        </div>

                        <div className="flex gap-3">
                          <Button
                            variant="outline"
                            className="flex-1"
                            onClick={() => setPreviewRecipe(proposal)}
                          >
                            <Eye className="mr-2 h-4 w-4" />
                            Preview
                          </Button>
                          <Button
                            className="flex-1 bg-[#0CC5BA] hover:bg-[#0CC5BA]/90 text-white"
                            onClick={() => handleUseProposal(proposal)}
                          >
                            Use This Recipe
                          </Button>
                        </div>
                      </div>
                    </Card>
                  ))}

                  <Button
                    onClick={() => setLocation("/recipes")}
                    variant="outline"
                    className="w-full mt-4"
                  >
                    Create Custom Recipe Instead
                  </Button>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <Dialog open={!!previewRecipe} onOpenChange={(open) => !open && setPreviewRecipe(null)}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          {previewRecipe && (
            <>
              <DialogHeader>
                <DialogTitle>{previewRecipe.name}</DialogTitle>
                <DialogDescription>{previewRecipe.description}</DialogDescription>
              </DialogHeader>

              <div className="space-y-6 py-4">
                <div className="aspect-video w-full rounded-lg overflow-hidden">
                  <img
                    src={previewRecipe.imageUrl}
                    alt={previewRecipe.name}
                    className="w-full h-full object-cover"
                  />
                </div>

                <div className="space-y-2">
                  <h3 className="font-semibold">Nutritional Information</h3>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <p className="text-sm text-gray-500">Calories</p>
                      <p className="font-semibold">{previewRecipe.nutritionInfo.calories}</p>
                    </div>
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <p className="text-sm text-gray-500">Protein</p>
                      <p className="font-semibold">{previewRecipe.nutritionInfo.protein}g</p>
                    </div>
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <p className="text-sm text-gray-500">Carbs</p>
                      <p className="font-semibold">{previewRecipe.nutritionInfo.carbs}g</p>
                    </div>
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <p className="text-sm text-gray-500">Fat</p>
                      <p className="font-semibold">{previewRecipe.nutritionInfo.fat}g</p>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <h3 className="font-semibold">Ingredients</h3>
                  <ul className="list-disc pl-5 space-y-1">
                    {previewRecipe.ingredients.map((ingredient, index) => (
                      <li key={index} className="text-gray-600">{ingredient}</li>
                    ))}
                  </ul>
                </div>

                <div className="space-y-2">
                  <h3 className="font-semibold">Instructions</h3>
                  <div className="space-y-2 text-gray-600">
                    {previewRecipe.instructions.split('\n').map((step, index) => (
                      <p key={index}>{step}</p>
                    ))}
                  </div>
                </div>

                <Button
                  className="w-full bg-[#0CC5BA] hover:bg-[#0CC5BA]/90 text-white"
                  onClick={() => {
                    handleUseProposal(previewRecipe);
                    setPreviewRecipe(null);
                  }}
                >
                  Use This Recipe
                </Button>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}