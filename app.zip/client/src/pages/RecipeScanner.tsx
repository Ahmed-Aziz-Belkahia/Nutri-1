import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { motion } from "framer-motion";
import { Camera, ChevronLeft, X, Check, Plus } from "lucide-react";
import { Link, useLocation } from "wouter";
import Webcam from "react-webcam";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";

interface ScannedIngredient {
  name: string;
  image: string;
}

interface SaveRecipePayload {
  name: string;
  description: string;
  ingredients: string[];
  instructions: string;
  nutritionInfo: {
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
  };
  isPublic: boolean;
}

export default function RecipeScanner() {
  const [, setLocation] = useLocation();
  const [imageSrc, setImageSrc] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [scannedIngredients, setScannedIngredients] = useState<ScannedIngredient[]>([]);
  const [isGeneratingRecipe, setIsGeneratingRecipe] = useState(false);
  const webcamRef = useRef<Webcam>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const saveRecipeMutation = useMutation({
    mutationFn: async (recipe: SaveRecipePayload) => {
      const response = await fetch("/api/recipes", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(recipe),
        credentials: "include",
      });

      if (!response.ok) {
        throw new Error(await response.text());
      }

      return response.json();
    },
    onSuccess: () => {
      // Invalidate both personal and top recipes queries
      queryClient.invalidateQueries({ queryKey: ["/api/recipes"] });
      queryClient.invalidateQueries({ queryKey: ["/api/recipes/top"] });

      toast({
        title: "Success",
        description: "Recipe saved successfully!",
      });
      setLocation("/recipes");
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to save recipe",
      });
    },
  });

  const handleCapture = async () => {
    const imageSrc = webcamRef.current?.getScreenshot();
    if (imageSrc) {
      setImageSrc(imageSrc);
      setIsAnalyzing(true);

      try {
        // Analyze food image
        const response = await fetch("/api/analyze-food", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ image: imageSrc }),
          credentials: "include",
        });

        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }

        const result = await response.json();

        // Add to scanned ingredients
        setScannedIngredients(prev => [...prev, {
          name: result.name,
          image: imageSrc
        }]);

        toast({
          title: "Ingredient Added",
          description: `Added ${result.name} to your recipe`,
        });

        // Reset camera for next scan
        setImageSrc(null);

      } catch (error) {
        console.error("Error processing ingredient:", error);
        toast({
          variant: "destructive",
          title: "Error",
          description: error instanceof Error ? error.message : "Failed to process ingredient",
        });
      } finally {
        setIsAnalyzing(false);
      }
    }
  };

  const handleGenerateRecipe = async () => {
    if (scannedIngredients.length === 0) return;

    setIsGeneratingRecipe(true);
    try {
      const ingredients = scannedIngredients.map(ing => ing.name);

      // Generate recipe from ingredients
      const recipeResponse = await fetch("/api/generate-recipe", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ ingredients }),
        credentials: "include",
      });

      if (!recipeResponse.ok) {
        throw new Error(`HTTP error! status: ${recipeResponse.status}`);
      }

      const recipe = await recipeResponse.json();

      saveRecipeMutation.mutate({
        ...recipe,
        ingredients,
        isPublic: true,
      });

    } catch (error) {
      console.error("Error generating recipe:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to generate recipe",
      });
    } finally {
      setIsGeneratingRecipe(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0CC5BA]/5 to-white/80">
      <div className="max-w-[500px] mx-auto px-4 py-6">
        <div className="flex items-center mb-6">
          <Link href="/recipes">
            <Button variant="ghost" size="icon" className="mr-2">
              <ChevronLeft className="h-5 w-5" />
            </Button>
          </Link>
          <h1 className="text-2xl font-medium text-gray-900">Recipe Scanner</h1>
        </div>

        {/* Scanned Ingredients */}
        {scannedIngredients.length > 0 && (
          <div className="mb-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-medium text-gray-900">Scanned Ingredients</h2>
              <Button onClick={handleGenerateRecipe} disabled={isGeneratingRecipe}>
                {isGeneratingRecipe ? (
                  <div className="flex items-center">
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                    Generating...
                  </div>
                ) : (
                  <>
                    <Check className="h-4 w-4 mr-2" />
                    Generate Recipe
                  </>
                )}
              </Button>
            </div>
            <div className="grid grid-cols-2 gap-4">
              {scannedIngredients.map((ingredient, index) => (
                <div key={index} className="relative rounded-lg overflow-hidden bg-gray-50">
                  <img
                    src={ingredient.image}
                    alt={ingredient.name}
                    className="w-full h-32 object-cover"
                  />
                  <div className="p-2">
                    <p className="text-sm font-medium text-gray-900">{ingredient.name}</p>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute top-2 right-2 bg-black/20 hover:bg-black/30"
                    onClick={() => {
                      setScannedIngredients(prev => prev.filter((_, i) => i !== index));
                    }}
                  >
                    <X className="h-4 w-4 text-white" />
                  </Button>
                </div>
              ))}
              {/* Add More Card */}
              <button
                onClick={() => setImageSrc(null)}
                className="flex flex-col items-center justify-center h-full min-h-[160px] rounded-lg border-2 border-dashed border-gray-300 bg-white hover:bg-gray-50"
              >
                <Plus className="h-8 w-8 text-gray-400" />
                <span className="mt-2 text-sm text-gray-500">Add More</span>
              </button>
            </div>
          </div>
        )}

        {/* Camera View */}
        {!imageSrc && (
          <Card className="p-6 mb-6">
            <div className="aspect-video relative rounded-lg overflow-hidden bg-gray-100">
              <Webcam
                ref={webcamRef}
                screenshotFormat="image/jpeg"
                className="w-full h-full object-cover"
                videoConstraints={{
                  facingMode: "user" 
                }}
              />
            </div>

            <div className="flex gap-4 mt-4">
              <Button
                onClick={() => setLocation("/recipes")}
                variant="outline"
                className="flex-1"
              >
                Cancel
              </Button>
              <Button
                onClick={handleCapture}
                className="flex-1 bg-[#0CC5BA] hover:bg-[#0CC5BA]/90"
                disabled={isAnalyzing}
              >
                <Camera className="w-4 h-4 mr-2" />
                Capture
              </Button>
            </div>
          </Card>
        )}

        {/* Loading States */}
        {isAnalyzing && (
          <div className="text-center py-4">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#0CC5BA] mx-auto" />
            <p className="mt-2 text-gray-600">Analyzing ingredient...</p>
          </div>
        )}
      </div>
    </div>
  );
}