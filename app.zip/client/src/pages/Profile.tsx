import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import Navigation from "../components/Navigation";

export default function Profile() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="sticky top-0 bg-white px-4 py-4 border-b border-zinc-100">
        <div className="flex items-center justify-between">
          <Link href="/">
            <Button variant="ghost" size="icon" className="-ml-2">
              <ArrowLeft className="h-6 w-6" />
            </Button>
          </Link>
          <h1 className="text-lg font-medium">Profile</h1>
          <div className="w-10" /> {/* Spacer for alignment */}
        </div>
      </header>

      {/* Content */}
      <div className="px-4 py-6">
        <div className="flex flex-col items-center py-8">
          <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mb-4">
            <span className="text-4xl">👤</span>
          </div>
          <h2 className="text-xl font-medium">User Profile</h2>
          <p className="text-gray-500 mt-1">Manage your account settings</p>
        </div>
      </div>

      <Navigation />
    </div>
  );
}