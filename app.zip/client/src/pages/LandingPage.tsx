import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { useLocation } from "wouter";
import { ArrowRight, Sparkles, Camera, Activity, Brain } from "lucide-react";

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.3
    }
  }
};

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 }
};

export default function LandingPage() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-[#FCFCFC] overflow-hidden">
      {/* Hero Section */}
      <div className="relative">
        {/* Background Gradient */}
        <div className="absolute inset-0 bg-gradient-to-br from-[#0CC5BA]/10 via-blue-500/5 to-transparent" />

        <div className="relative max-w-[500px] mx-auto px-6 pt-20">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center"
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="w-20 h-20 mx-auto mb-8 rounded-3xl bg-gradient-to-br from-[#0CC5BA] to-blue-500 flex items-center justify-center shadow-lg shadow-[#0CC5BA]/20"
            >
              <Sparkles className="w-10 h-10 text-white" />
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="text-5xl font-bold bg-gradient-to-br from-[#0CC5BA] via-[#0CBACC] to-[#0C9CCC] bg-clip-text text-transparent leading-tight mb-4"
            >
              Transform Your
              <br />
              Health Journey
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="text-xl text-gray-600 mb-12"
            >
              Your personal AI nutrition coach for
              <br />
              a healthier lifestyle
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="space-y-4"
            >
              <Button
                className="w-full h-14 bg-gradient-to-r from-[#0CC5BA] to-[#0CBACC] hover:opacity-90 text-white rounded-2xl text-lg font-medium shadow-lg shadow-[#0CC5BA]/20 transition-all duration-300"
                onClick={() => setLocation("/quiz")}
              >
                Start Your Journey
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button
                variant="ghost"
                className="w-full h-14 bg-white/80 backdrop-blur-sm text-gray-600 hover:text-[#0CC5BA] hover:bg-[#0CC5BA]/5 rounded-2xl text-lg font-medium transition-all duration-300"
                onClick={() => setLocation("/auth?tab=signin")}
              >
                Sign In
              </Button>
            </motion.div>
          </motion.div>

          {/* Features Grid */}
          <motion.div
            variants={container}
            initial="hidden"
            animate="show"
            className="mt-20 grid grid-cols-2 gap-4"
          >
            {[
              {
                icon: <Brain className="w-8 h-8" />,
                title: "AI Coach",
                description: "Smart meal planning powered by AI"
              },
              {
                icon: <Camera className="w-8 h-8" />,
                title: "Quick Scan",
                description: "Log meals with a simple photo"
              },
              {
                icon: <Activity className="w-8 h-8" />,
                title: "Progress",
                description: "Track your transformation"
              },
              {
                icon: <Sparkles className="w-8 h-8" />,
                title: "Personal",
                description: "Tailored to your goals"
              }
            ].map((feature, index) => (
              <motion.div
                key={feature.title}
                variants={item}
                className="relative group"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-[#0CC5BA]/10 to-blue-500/10 rounded-[28px] transform group-hover:scale-105 transition-transform duration-300" />
                <div className="relative p-6 backdrop-blur-sm rounded-[28px] border border-white/20">
                  <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#0CC5BA] to-blue-500 flex items-center justify-center text-white shadow-lg shadow-[#0CC5BA]/20 mb-4">
                    {feature.icon}
                  </div>
                  <h3 className="text-lg font-bold text-gray-900 mb-1">
                    {feature.title}
                  </h3>
                  <p className="text-sm text-gray-600">
                    {feature.description}
                  </p>
                </div>
              </motion.div>
            ))}
          </motion.div>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.2 }}
            className="text-center text-sm text-gray-500 mt-12 mb-8"
          >
            Takes only 2 minutes to start your journey
          </motion.p>
        </div>
      </div>
    </div>
  );
}