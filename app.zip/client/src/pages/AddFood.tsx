import { useState, useRef } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import Webcam from "react-webcam";
import { useToast } from "@/hooks/use-toast";

export default function AddFood() {
  const [, setLocation] = useLocation();
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const webcamRef = useRef<Webcam>(null);
  const { toast } = useToast();

  const handleCapture = async () => {
    if (!webcamRef.current) return;

    let capturedImageData: string | null = null;
    setIsAnalyzing(true);

    try {
      // Capture the image
      capturedImageData = webcamRef.current.getScreenshot();
      if (!capturedImageData) {
        throw new Error('Failed to capture image');
      }

      // Set UI state
      setCapturedImage(capturedImageData);

      // Analyze the image
      const response = await fetch("/api/analyze-food", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ image: capturedImageData }),
        credentials: "include",
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      toast({
        title: "Success",
        description: `Added ${result.name} to your log`,
      });

      setLocation("/dashboard");
    } catch (error) {
      console.error('Analysis Error:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to analyze food",
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="min-h-screen bg-black">
      <div className="relative h-screen">
        {cameraError ? (
          <div className="h-screen flex items-center justify-center text-center bg-gray-900">
            <div className="text-white">
              <p className="text-lg mb-2">Camera access denied</p>
              <p className="text-sm text-gray-400">Please enable camera access to use this feature</p>
            </div>
          </div>
        ) : (
          <>
            <div className="relative h-screen">
              <Webcam
                ref={webcamRef}
                audio={false}
                screenshotFormat="image/jpeg"
                videoConstraints={{
                  facingMode: "environment",
                }}
                className="h-screen w-full object-cover"
                onUserMediaError={(error) => {
                  console.error('Camera error:', error);
                  setCameraError('Camera access denied');
                }}
              />
              <div className="absolute top-4 left-4">
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-white hover:bg-white/20"
                  onClick={() => setLocation("/dashboard")}
                >
                  ×
                </Button>
              </div>
              <div className="absolute bottom-16 left-0 right-0 flex justify-center">
                <motion.button
                  whileTap={{ scale: 0.95 }}
                  className="w-16 h-16 rounded-full bg-white/20 backdrop-blur-lg flex items-center justify-center border-2 border-white"
                  onClick={handleCapture}
                  disabled={isAnalyzing}
                >
                  <div className="w-14 h-14 rounded-full border-4 border-white" />
                </motion.button>
              </div>
            </div>

            {isAnalyzing && (
              <div className="absolute inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center">
                <div className="text-white text-center">
                  <Loader2 className="h-8 w-8 animate-spin mx-auto mb-2" />
                  <p>Processing...</p>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}