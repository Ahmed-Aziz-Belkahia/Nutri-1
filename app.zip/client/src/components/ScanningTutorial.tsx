import { motion } from "framer-motion";
import { Camera, ArrowRight, Smartphone, Check } from "lucide-react";
import { Button } from "@/components/ui/button";

interface ScanningTutorialProps {
  onComplete: () => void;
}

export default function ScanningTutorial({ onComplete }: ScanningTutorialProps) {
  const steps = [
    {
      title: "Quick & Easy Scanning",
      description: "Simply point your camera at any food item or nutrition label",
      icon: Camera,
      animation: "scan"
    },
    {
      title: "Instant Recognition",
      description: "Our AI instantly identifies the food and its nutritional content",
      icon: Smartphone,
      animation: "process"
    },
    {
      title: "Automatic Logging",
      description: "Food is automatically added to your daily log with accurate nutrition data",
      icon: Check,
      animation: "complete"
    }
  ];

  return (
    <div className="fixed inset-0 bg-white z-50">
      <div className="min-h-screen flex flex-col">
        {/* Header */}
        <div className="py-6 px-4 text-center">
          <h2 className="text-2xl font-bold text-gray-900">Experience the Magic</h2>
          <p className="text-gray-600 mt-2">See how easy tracking can be with AI</p>
        </div>

        {/* Demo Content */}
        <div className="flex-1 flex flex-col justify-center px-4">
          <div className="space-y-8">
            {steps.map((step, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.2 }}
                className="flex items-center gap-4"
              >
                <div className="w-12 h-12 rounded-full bg-[#0CC5BA]/10 flex items-center justify-center">
                  <step.icon className="w-6 h-6 text-[#0CC5BA]" />
                </div>
                <div className="flex-1">
                  <h3 className="font-medium text-gray-900">{step.title}</h3>
                  <p className="text-sm text-gray-600">{step.description}</p>
                </div>
              </motion.div>
            ))}

            {/* Demo Animation */}
            <div className="aspect-[9/16] bg-gray-100 rounded-2xl overflow-hidden relative">
              <motion.div
                className="absolute inset-0 bg-gradient-to-t from-[#0CC5BA]/20 to-transparent"
                animate={{
                  opacity: [0, 1, 0],
                  y: [0, -20, 0],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "linear",
                }}
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <Camera className="w-16 h-16 text-[#0CC5BA]" />
              </div>
            </div>

            {/* Success Message */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1 }}
              className="text-center space-y-4"
            >
              <p className="text-lg font-medium text-gray-900">
                Ready to transform your nutrition journey?
              </p>
              <p className="text-sm text-gray-600">
                Join thousands who've already discovered the easiest way to track their nutrition
              </p>
            </motion.div>
          </div>
        </div>

        {/* Action Button */}
        <div className="p-6">
          <Button
            onClick={onComplete}
            className="w-full h-14 bg-gradient-to-r from-[#0CC5BA] to-blue-500 text-white rounded-xl text-lg font-medium hover:opacity-90 transition-opacity"
          >
            Continue
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </div>
    </div>
  );
}
