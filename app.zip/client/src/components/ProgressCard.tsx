import { motion } from "framer-motion";
import { Star, Award } from "lucide-react";
import { Card } from "@/components/ui/card";
import { useUser } from "../hooks/use-user";
import { useQuery } from "@tanstack/react-query";

interface BadgeData {
  id: number;
  name: string;
  description: string;
  icon: string;
  earnedAt: string;
}

export default function ProgressCard() {
  const { user } = useUser();

  const { data: badges } = useQuery<BadgeData[]>({
    queryKey: ['/api/user/badges'],
    enabled: !!user,
  });

  const { data: notifications } = useQuery({
    queryKey: ['/api/notifications'],
    enabled: !!user,
  });

  const getExperienceProgress = () => {
    if (!user) return 0;
    const levelThreshold = user.level * 1000; // Example: each level requires 1000 XP
    return Math.min((user.experiencePoints % levelThreshold) / levelThreshold * 100, 100);
  };

  return (
    <Card className="p-6 rounded-[28px] border-[#0CC5BA]/10 bg-white/80 backdrop-blur-xl overflow-hidden group hover:shadow-lg hover:shadow-[#0CC5BA]/20 transition-all duration-300">
      <div className="space-y-6">
        {/* Level Progress */}
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium text-gray-900">Level {user?.level || 1}</span>
            <span className="text-sm text-gray-500">{user?.experiencePoints || 0} XP</span>
          </div>
          <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
            <motion.div
              className="h-full bg-gradient-to-r from-[#0CC5BA] to-blue-500 rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${getExperienceProgress()}%` }}
              transition={{ duration: 1 }}
            />
          </div>
        </div>

        {/* Recent Badges */}
        {badges && badges.length > 0 && (
          <div className="space-y-3">
            <h3 className="text-sm font-medium text-gray-900">Recent Achievements</h3>
            <div className="flex gap-2 overflow-x-auto pb-2">
              {badges.slice(0, 3).map((badge) => (
                <div
                  key={badge.id}
                  className="flex-shrink-0 w-12 h-12 rounded-xl bg-gradient-to-br from-[#0CC5BA]/10 to-blue-500/10 flex items-center justify-center"
                  title={badge.name}
                >
                  <Award className="w-6 h-6 text-[#0CC5BA]" />
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Motivation Message */}
        <div className="text-sm text-gray-600 bg-[#0CC5BA]/5 p-4 rounded-xl">
          <p className="font-medium">🎯 Keep up the momentum!</p>
          <p className="mt-1">You're making great progress on your health journey.</p>
        </div>
      </div>
    </Card>
  );
}