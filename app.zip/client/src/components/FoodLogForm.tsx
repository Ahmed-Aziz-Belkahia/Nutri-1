import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useFoodLog } from "../hooks/use-food-log";
import { useToast } from "@/hooks/use-toast";
import { Loader2, AlertCircle } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface FoodData {
  name: string;
  calories: number;
  protein: string;
  carbs: string;
  fat: string;
  image?: string;
  confidence?: number;
  isEstimate?: boolean;
  servingSize?: string;
}

export default function FoodLogForm() {
  const { addFood } = useFoodLog();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState<FoodData>({
    name: "",
    calories: 0,
    protein: "0",
    carbs: "0",
    fat: "0"
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isLoading) return; // Prevent double submission
    setIsLoading(true);

    try {
      await addFood(formData);

      setFormData({
        name: "",
        calories: 0,
        protein: "0",
        carbs: "0",
        fat: "0"
      });

      toast({
        title: "Food logged",
        description: "Your food has been successfully logged!",
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to log food. Please try again.",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === 'number' ? (name === 'calories' ? parseInt(value) || 0 : value) : value,
    }));
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {formData.isEstimate && (
        <Alert className="bg-yellow-50 text-yellow-800 border-yellow-200">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            These are estimated values. Feel free to adjust them for accuracy.
            {formData.confidence && formData.confidence < 0.8 && (
              <span className="block mt-1 text-sm">
                Low confidence detection ({Math.round(formData.confidence * 100)}%)
              </span>
            )}
          </AlertDescription>
        </Alert>
      )}

      <div className="space-y-2">
        <Label htmlFor="name">Food Name</Label>
        <Input
          id="name"
          name="name"
          value={formData.name}
          onChange={handleChange}
          required
        />
        {formData.servingSize && (
          <p className="text-sm text-gray-500 mt-1">
            Serving size: {formData.servingSize}
          </p>
        )}
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="calories">Calories</Label>
          <Input
            id="calories"
            name="calories"
            type="number"
            value={formData.calories}
            onChange={handleChange}
            required
            min="0"
            max="2000"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="protein">Protein (g)</Label>
          <Input
            id="protein"
            name="protein"
            type="number"
            step="0.1"
            value={formData.protein}
            onChange={handleChange}
            required
            min="0"
            max="100"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="carbs">Carbs (g)</Label>
          <Input
            id="carbs"
            name="carbs"
            type="number"
            step="0.1"
            value={formData.carbs}
            onChange={handleChange}
            required
            min="0"
            max="200"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="fat">Fat (g)</Label>
          <Input
            id="fat"
            name="fat"
            type="number"
            step="0.1"
            value={formData.fat}
            onChange={handleChange}
            required
            min="0"
            max="100"
          />
        </div>
      </div>

      <Button type="submit" className="w-full" disabled={isLoading}>
        {isLoading ? (
          <Loader2 className="h-4 w-4 animate-spin" />
        ) : (
          "Add Food"
        )}
      </Button>
    </form>
  );
}