import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ChevronUp, ChevronDown, Check, Trophy } from "lucide-react";

interface WeightLogWidgetProps {
  currentWeight: number;
  goalWeight: number;
  onWeightUpdate: (weight: number) => void;
}

export default function WeightLogWidget({ currentWeight, goalWeight, onWeightUpdate }: WeightLogWidgetProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [weight, setWeight] = useState(currentWeight);
  const [showSuccess, setShowSuccess] = useState(false);

  const handleSubmit = () => {
    onWeightUpdate(weight);
    setIsEditing(false);
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 2000);
  };

  const getMotivationalMessage = (current: number, goal: number) => {
    if (current === goal) return "Amazing! You've hit your goal! 🎉";
    const diff = Math.abs(current - goal);
    const isGaining = goal > current;
    return isGaining 
      ? `Keep pushing! ${diff.toFixed(1)}kg to go for your bulk goal 💪`
      : `Keep going! ${diff.toFixed(1)}kg to go for your cut goal 🔥`;
  };

  return (
    <div className="relative w-full">
      <AnimatePresence mode="wait">
        {!isEditing && !showSuccess && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="w-full"
          >
            <Button 
              variant="outline" 
              className="w-full py-6 bg-blue-50/50 border-blue-200 hover:bg-blue-100 rounded-xl shadow-sm"
              onClick={() => setIsEditing(true)}
            >
              <div className="flex flex-col items-center w-full gap-2">
                <span className="text-lg font-medium text-blue-600">{currentWeight} kg</span>
                <span className="text-sm text-gray-500">
                  {getMotivationalMessage(currentWeight, goalWeight)}
                </span>
              </div>
            </Button>
          </motion.div>
        )}

        {isEditing && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="flex flex-col items-center gap-4 bg-white p-6 rounded-xl border border-blue-200 shadow-lg"
          >
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="sm"
                className="p-2 hover:bg-blue-50"
                onClick={() => setWeight(prev => +(prev + 0.1).toFixed(1))}
              >
                <ChevronUp className="w-6 h-6 text-blue-600" />
              </Button>
              <Input
                type="number"
                value={weight.toFixed(1)}
                onChange={(e) => setWeight(parseFloat(e.target.value))}
                className="w-24 text-center text-xl font-medium focus:ring-blue-200"
                step="0.1"
              />
              <Button
                variant="ghost"
                size="sm"
                className="p-2 hover:bg-blue-50"
                onClick={() => setWeight(prev => +(Math.max(0, prev - 0.1)).toFixed(1))}
              >
                <ChevronDown className="w-6 h-6 text-blue-600" />
              </Button>
            </div>
            <div className="flex gap-2 w-full">
              <Button
                variant="outline"
                className="flex-1 border-blue-200 hover:bg-blue-50"
                onClick={() => setIsEditing(false)}
              >
                Anuluj
              </Button>
              <Button
                className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
                onClick={handleSubmit}
              >
                Zapisz
              </Button>
            </div>
          </motion.div>
        )}

        {showSuccess && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="absolute inset-0 flex items-center justify-center bg-green-500 rounded-xl shadow-lg"
          >
            <motion.div 
              initial={{ rotate: -180, scale: 0 }}
              animate={{ rotate: 0, scale: 1 }}
              transition={{ type: "spring", damping: 10 }}
              className="flex items-center gap-2 text-white"
            >
              <Check className="w-6 h-6" />
              <span className="font-medium">Zapisano!</span>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}