import { Home, Scale, Plus } from "lucide-react";
import { Link, useLocation } from "wouter";
import { motion } from "framer-motion";

export default function Navigation() {
  const [location] = useLocation();

  const navItems = [
    { icon: Scale, path: "/logs", label: "Logs" },
    { icon: Plus, path: "/add", label: "Add" },
    { icon: Home, path: "/dashboard", label: "Home" },
  ];

  return (
    <motion.div 
      initial={{ y: 100 }}
      animate={{ y: 0 }}
      className="fixed bottom-0 left-0 right-0 z-50"
    >
      {/* Premium glassmorphic container */}
      <div className="relative mx-4 mb-4">
        {/* Neural interface background */}
        <div className="absolute inset-0 bg-white/80 backdrop-blur-2xl rounded-2xl border border-[#0CC5BA]/20
          shadow-[0_8px_32px_rgba(12,197,186,0.1)] overflow-hidden">
          {/* Animated gradient overlay */}
          <motion.div
            className="absolute inset-0 bg-gradient-to-r from-[#0CC5BA]/5 via-blue-500/5 to-[#0CC5BA]/5"
            animate={{
              x: ['0%', '100%', '0%'],
            }}
            transition={{
              duration: 15,
              ease: "linear",
              repeat: Infinity,
            }}
          />
        </div>

        {/* Navigation content */}
        <div className="relative flex justify-between items-center px-12 py-5">
          {navItems.map((item) => {
            const isActive = location === item.path;
            return (
              <Link key={item.path} href={item.path}>
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.95 }}
                  className="relative"
                >
                  {/* Icon container with hover effects */}
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center transition-all duration-300
                    ${isActive 
                      ? 'bg-[#0CC5BA]/10 shadow-[0_0_15px_rgba(12,197,186,0.15)]' 
                      : 'hover:bg-white/40'}`}
                  >
                    {/* Neural interface glow for active state */}
                    {isActive && (
                      <motion.div
                        className="absolute inset-0 rounded-xl bg-[#0CC5BA]/5"
                        animate={{
                          opacity: [0.5, 0.8, 0.5],
                        }}
                        transition={{
                          duration: 2,
                          repeat: Infinity,
                          ease: "easeInOut",
                        }}
                      />
                    )}

                    <item.icon
                      className={`h-5 w-5 relative z-10 transition-all duration-300 ${
                        isActive 
                          ? 'text-[#0CC5BA] drop-shadow-[0_0_8px_rgba(12,197,186,0.5)]' 
                          : 'text-gray-400 hover:text-gray-600'
                      }`}
                    />
                  </div>

                  {/* Animated active indicator */}
                  {isActive && (
                    <motion.div
                      layoutId="navIndicator"
                      className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-[#0CC5BA]
                        shadow-[0_0_8px_rgba(12,197,186,0.5)] before:absolute before:inset-0 before:rounded-full 
                        before:bg-[#0CC5BA]/30 before:animate-ping"
                      transition={{ 
                        type: "spring", 
                        bounce: 0.2, 
                        duration: 0.6 
                      }}
                    />
                  )}
                </motion.button>
              </Link>
            );
          })}
        </div>
      </div>

      {/* Safe area padding for iOS */}
      <div className="h-[env(safe-area-inset-bottom,0px)]" />
    </motion.div>
  );
}