import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useUser } from "../hooks/use-user";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowRight, ArrowLeft, Utensils, Scale, Target, Zap, Apple } from "lucide-react";

interface TutorialStep {
  id: number;
  title: string;
  description: string;
  icon: JSX.Element;
  tips: string[];
  action?: {
    label: string;
    onClick: () => void;
  };
}

export default function NutritionTutorial({ onComplete }: { onComplete: () => void }) {
  const [currentStep, setCurrentStep] = useState(1);

  const steps: TutorialStep[] = [
    {
      id: 1,
      title: "Welcome to Nutrition Basics",
      description: "Let's learn about the fundamentals of healthy eating and how to make better food choices.",
      icon: <Utensils className="w-12 h-12 text-[#10c4bc]" />,
      tips: [
        "Eat a variety of colorful foods",
        "Stay hydrated throughout the day",
        "Listen to your body's hunger cues"
      ]
    },
    {
      id: 2,
      title: "Understanding Calories",
      description: "Calories are units of energy. Your daily needs depend on various factors including age, height, weight, and activity level.",
      icon: <Zap className="w-12 h-12 text-[#10c4bc]" />,
      tips: [
        "Quality of food matters as much as quantity",
        "Track your intake regularly for best results",
        "Everyone's needs are different"
      ]
    },
    {
      id: 3,
      title: "Macronutrients 101",
      description: "Proteins, carbs, and fats are essential for your body. Each plays a unique role in your health.",
      icon: <Apple className="w-12 h-12 text-[#10c4bc]" />,
      tips: [
        "Proteins help build muscle",
        "Carbs provide energy",
        "Healthy fats support brain function"
      ]
    },
    {
      id: 4,
      title: "Setting Realistic Goals",
      description: "The key to success is setting achievable goals and tracking your progress consistently.",
      icon: <Target className="w-12 h-12 text-[#10c4bc]" />,
      tips: [
        "Start with small, achievable goals",
        "Celebrate your progress",
        "Adjust goals as needed"
      ]
    },
    {
      id: 5,
      title: "Tracking Your Journey",
      description: "Regular tracking helps you stay accountable and see your progress over time.",
      icon: <Scale className="w-12 h-12 text-[#10c4bc]" />,
      tips: [
        "Log your meals daily",
        "Take progress photos",
        "Monitor your weight weekly"
      ],
      action: {
        label: "Start Your Journey",
        onClick: onComplete
      }
    }
  ];

  const currentStepData = steps[currentStep - 1];

  return (
    <div className="min-h-screen w-full flex flex-col bg-[#10c4bc]">
      <div className="flex-1 flex flex-col items-center justify-center p-6">
        <div className="w-full max-w-2xl">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentStep}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-8"
            >
              {/* Progress indicator */}
              <div className="flex justify-between items-center mb-12">
                <div className="flex gap-2">
                  {steps.map((step) => (
                    <div
                      key={step.id}
                      className={`h-2 rounded-full transition-all duration-300 ${
                        step.id <= currentStep ? "bg-white w-12" : "bg-white/30 w-6"
                      }`}
                    />
                  ))}
                </div>
                <span className="text-sm text-white font-medium">
                  {currentStep}/{steps.length}
                </span>
              </div>

              {/* Content */}
              <Card className="p-8 bg-white rounded-3xl shadow-2xl">
                <div className="flex flex-col items-center text-center space-y-8">
                  <div className="w-28 h-28 rounded-3xl bg-[#E8F8F7] flex items-center justify-center">
                    {currentStepData.icon}
                  </div>
                  <h2 className="text-4xl font-bold text-gray-900">
                    {currentStepData.title}
                  </h2>
                  <p className="text-gray-600 text-xl leading-relaxed max-w-md">
                    {currentStepData.description}
                  </p>

                  <div className="w-full space-y-4 mt-8">
                    {currentStepData.tips.map((tip, index) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.1 }}
                        className="flex items-center gap-4 p-4 rounded-2xl bg-gray-50"
                      >
                        <div className="w-2 h-2 rounded-full bg-[#10c4bc]" />
                        <p className="text-gray-700 text-lg">{tip}</p>
                      </motion.div>
                    ))}
                  </div>
                </div>
              </Card>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      {/* Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white/90 backdrop-blur-xl border-t border-white/10">
        <div className="w-full max-w-2xl mx-auto px-6 py-6">
          <div className="flex justify-between gap-6">
            {currentStep > 1 ? (
              <Button
                variant="outline"
                onClick={() => setCurrentStep(current => current - 1)}
                className="flex-1 h-16 text-lg border-2"
              >
                <ArrowLeft className="w-6 h-6 mr-2" />
                Previous
              </Button>
            ) : (
              <div className="flex-1" /> // Spacer
            )}

            {currentStepData.action ? (
              <Button
                onClick={currentStepData.action.onClick}
                className="flex-1 h-16 text-lg bg-[#10c4bc] text-white hover:bg-[#0fb3ab]"
              >
                {currentStepData.action.label}
                <ArrowRight className="w-6 h-6 ml-2" />
              </Button>
            ) : (
              <Button
                onClick={() => setCurrentStep(current => current + 1)}
                className="flex-1 h-16 text-lg bg-[#10c4bc] text-white hover:bg-[#0fb3ab]"
              >
                Next
                <ArrowRight className="w-6 h-6 ml-2" />
              </Button>
            )}
          </div>
        </div>
        {/* Safe area padding for iOS */}
        <div className="h-[env(safe-area-inset-bottom,0px)]" />
      </div>
    </div>
  );
}