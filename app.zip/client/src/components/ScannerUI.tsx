import { Button } from "@/components/ui/button";
import { XIcon, Camera, Barcode, FileText, Image, ChevronLeft, Share2, MoreVertical } from "lucide-react";
import { useState, useRef } from "react";
import { motion } from "framer-motion";
import Webcam from "react-webcam";
import { analyzeFoodImage } from "../lib/vision";
import { useToast } from "@/hooks/use-toast";
import { useFoodLog } from "../hooks/use-food-log";
import { useLocation } from "wouter";

interface ScannerUIProps {
  onClose: () => void;
}

interface FoodAnalysis {
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
  healthScore?: number;
}

export default function ScannerUI({ onClose }: ScannerUIProps) {
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analyzedFood, setAnalyzedFood] = useState<FoodAnalysis | null>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [quantity, setQuantity] = useState(1);
  const webcamRef = useRef<Webcam>(null);
  const { toast } = useToast();
  const { addFood } = useFoodLog();
  const [, setLocation] = useLocation();

  const resetState = () => {
    setAnalyzedFood(null);
    setCapturedImage(null);
    setIsAnalyzing(false);
    setQuantity(1);
  };

  const handleCapture = async () => {
    if (!webcamRef.current) return;

    try {
      // Reset state before new capture
      resetState();
      setIsAnalyzing(true);

      const imageSrc = webcamRef.current.getScreenshot();
      if (!imageSrc) {
        throw new Error('Failed to capture image');
      }

      setCapturedImage(imageSrc);

      // Analyze the food using Vision API
      const result = await analyzeFoodImage(imageSrc);
      setAnalyzedFood({
        name: result.name,
        calories: parseInt(result.calories.toString()),
        protein: parseFloat(result.protein),
        carbs: parseFloat(result.carbs),
        fats: parseFloat(result.fat),
        healthScore: 6
      });

    } catch (error) {
      console.error('Failed to process food:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to analyze food",
      });
      resetState();
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleReanalyze = async () => {
    if (!capturedImage) return;

    try {
      setIsAnalyzing(true);
      setAnalyzedFood(null); // Clear previous result

      const result = await analyzeFoodImage(capturedImage);
      setAnalyzedFood({
        name: result.name,
        calories: parseInt(result.calories.toString()),
        protein: parseFloat(result.protein),
        carbs: parseFloat(result.carbs),
        fats: parseFloat(result.fat),
        healthScore: 6
      });
    } catch (error) {
      console.error('Failed to reanalyze food:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to analyze food",
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleSave = async () => {
    if (!analyzedFood || !capturedImage) return;

    try {
      await addFood({
        name: analyzedFood.name,
        calories: analyzedFood.calories * quantity,
        protein: (analyzedFood.protein * quantity).toString(),
        carbs: (analyzedFood.carbs * quantity).toString(),
        fat: (analyzedFood.fats * quantity).toString(),
        image: capturedImage
      });

      toast({
        title: "Success",
        description: "Food has been logged successfully!",
      });

      setLocation("/dashboard");
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to save food log. Please try again.",
      });
    }
  };

  if (analyzedFood && capturedImage) {
    return (
      <div className="fixed inset-0 bg-white z-50">
        {/* Top Navigation */}
        <div className="px-4 py-4 flex items-center justify-between border-b">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => {
              resetState();
            }}
          >
            <ChevronLeft className="h-6 w-6" />
          </Button>
          <h2 className="text-lg font-medium">Nutrition</h2>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon">
              <Share2 className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon">
              <MoreVertical className="h-5 w-5" />
            </Button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6">
          {/* Bookmark and Time */}
          <div className="flex justify-between items-center mb-4">
            <div>
              <h3 className="text-2xl font-semibold">{analyzedFood.name}</h3>
            </div>
            <div className="text-sm text-gray-500">02:37</div>
          </div>

          {/* Quantity Control */}
          <div className="flex items-center justify-end gap-4 mb-6">
            <button
              className="w-8 h-8 rounded-full border border-gray-300 flex items-center justify-center"
              onClick={() => setQuantity(Math.max(1, quantity - 1))}
            >
              -
            </button>
            <span className="text-lg">{quantity}</span>
            <button
              className="w-8 h-8 rounded-full border border-gray-300 flex items-center justify-center"
              onClick={() => setQuantity(quantity + 1)}
            >
              +
            </button>
          </div>

          {/* Calories Card */}
          <div className="bg-gray-50 rounded-2xl p-4 mb-4">
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-bold">{analyzedFood.calories * quantity}</span>
              <span className="text-gray-500">Calories</span>
            </div>
          </div>

          {/* Macros */}
          <div className="grid grid-cols-3 gap-4 mb-6">
            <div className="bg-gray-50 rounded-2xl p-4">
              <div className="text-sm text-gray-500">Protein</div>
              <div className="text-lg font-semibold">{analyzedFood.protein * quantity}g</div>
            </div>
            <div className="bg-gray-50 rounded-2xl p-4">
              <div className="text-sm text-gray-500">Carbs</div>
              <div className="text-lg font-semibold">{analyzedFood.carbs * quantity}g</div>
            </div>
            <div className="bg-gray-50 rounded-2xl p-4">
              <div className="text-sm text-gray-500">Fats</div>
              <div className="text-lg font-semibold">{analyzedFood.fats * quantity}g</div>
            </div>
          </div>

          {/* Health Score */}
          <div className="bg-gray-50 rounded-2xl p-4 mb-6">
            <div className="flex justify-between items-center mb-2">
              <span className="text-gray-500">Health Score</span>
              <span className="font-semibold">{analyzedFood.healthScore}/10</span>
            </div>
            <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
              <div
                className="h-full bg-green-500 rounded-full transition-all duration-300"
                style={{ width: `${(analyzedFood.healthScore || 0) * 10}%` }}
              />
            </div>
          </div>
        </div>

        {/* Bottom Buttons */}
        <div className="fixed bottom-0 left-0 right-0 p-4 bg-white border-t">
          <div className="flex gap-4">
            <Button
              variant="outline"
              className="flex-1 h-12 rounded-xl"
              onClick={handleReanalyze}
            >
              Reanalyze
            </Button>
            <Button
              className="flex-1 h-12 bg-black text-white hover:bg-black/90 rounded-xl"
              onClick={handleSave}
            >
              Save
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black z-50"
    >
      {/* Close Button */}
      <div className="absolute top-4 left-4 z-20">
        <Button
          variant="ghost"
          size="icon"
          className="rounded-full bg-black/50 hover:bg-black/70"
          onClick={onClose}
        >
          <XIcon className="h-6 w-6 text-white" />
        </Button>
      </div>

      {/* Camera View */}
      <div className="absolute inset-0">
        {cameraError ? (
          <div className="h-full flex items-center justify-center text-white text-center px-4">
            <div>
              <p className="text-lg mb-2">Camera access denied</p>
              <p className="text-sm text-gray-400">Please enable camera access to use this feature</p>
            </div>
          </div>
        ) : (
          <div className="relative h-full">
            <Webcam
              ref={webcamRef}
              audio={false}
              screenshotFormat="image/jpeg"
              videoConstraints={{
                facingMode: "environment"
              }}
              className="w-full h-full object-cover"
              onUserMediaError={(error) => {
                console.error('Camera error:', error);
                setCameraError('Camera access denied');
              }}
            />

            {/* Viewfinder Overlay */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="relative w-[80%] max-w-sm aspect-square">
                <div className="absolute inset-0 border-2 border-white/50"></div>
              </div>
            </div>

            {/* Bottom Bar */}
            <div className="absolute bottom-0 left-0 right-0 bg-black/50 backdrop-blur-sm p-4">
              <div className="grid grid-cols-4 gap-4">
                <Button
                  variant="ghost"
                  size="lg"
                  className="flex flex-col items-center justify-center h-20 bg-black/30 border border-white/20 rounded-lg text-white hover:bg-black/50"
                  onClick={handleCapture}
                  disabled={isAnalyzing}
                >
                  <Camera className="h-6 w-6 mb-1" />
                  <span className="text-xs">Scan Food</span>
                </Button>
                <Button
                  variant="ghost"
                  size="lg"
                  className="flex flex-col items-center justify-center h-20 bg-black/30 border border-white/20 rounded-lg text-white hover:bg-black/50"
                >
                  <Barcode className="h-6 w-6 mb-1" />
                  <span className="text-xs">Barcode</span>
                </Button>
                <Button
                  variant="ghost"
                  size="lg"
                  className="flex flex-col items-center justify-center h-20 bg-black/30 border border-white/20 rounded-lg text-white hover:bg-black/50"
                >
                  <FileText className="h-6 w-6 mb-1" />
                  <span className="text-xs">Food Label</span>
                </Button>
                <Button
                  variant="ghost"
                  size="lg"
                  className="flex flex-col items-center justify-center h-20 bg-black/30 border border-white/20 rounded-lg text-white hover:bg-black/50"
                >
                  <Image className="h-6 w-6 mb-1" />
                  <span className="text-xs">Gallery</span>
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Loading Overlay */}
      {isAnalyzing && (
        <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
          <div className="text-white text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-4 border-white border-t-transparent mx-auto mb-4" />
            <p>Analyzing food...</p>
          </div>
        </div>
      )}
    </motion.div>
  );
}