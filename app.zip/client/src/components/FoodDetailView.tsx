import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { XIcon, Camera, ChevronLeft, Share2, MoreVertical } from "lucide-react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { useToast } from "@/hooks/use-toast";

interface FoodDetailViewProps {
  food?: {
    id?: number;
    name: string;
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
    image?: string;
  };
  isLoading?: boolean;
  onSave?: (food: any) => void;
}

export default function FoodDetailView({ food, isLoading, onSave }: FoodDetailViewProps) {
  const { toast } = useToast();
  const [quantity, setQuantity] = useState(1);
  const [editing, setEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: food?.name || '',
    calories: food?.calories || 0,
    protein: food?.protein || 0,
    carbs: food?.carbs || 0,
    fat: food?.fat || 0,
  });

  if (isLoading || !food) {
    return (
      <div className="fixed inset-0 bg-white">
        <div className="flex items-center justify-center h-screen">
          <div className="animate-spin rounded-full h-12 w-12 border-4 border-gray-900 border-t-transparent" />
        </div>
      </div>
    );
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'number' ? parseFloat(value) || 0 : value,
    }));
  };

  return (
    <div className="fixed inset-0 bg-[#F8F9FA] overflow-y-auto">
      {/* Top Bar */}
      <div className="flex items-center justify-between p-3 fixed top-0 left-0 right-0 z-10">
        <button className="w-9 h-9 rounded-full bg-white flex items-center justify-center">
          <ChevronLeft className="w-5 h-5" />
        </button>
        <div className="flex gap-2">
          <button className="w-9 h-9 rounded-full bg-white flex items-center justify-center">
            <Share2 className="w-5 h-5" />
          </button>
          <button className="w-9 h-9 rounded-full bg-white flex items-center justify-center">
            <MoreVertical className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="p-3 pt-16">
        {/* Food Photo Card */}
        <div className="bg-white rounded-3xl overflow-hidden mb-4">
          <div className="aspect-square bg-gray-50">
            {food.image ? (
              <img src={food.image} alt={food.name} className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                <span className="text-6xl">🍽️</span>
              </div>
            )}
          </div>

          {/* Food Info */}
          <div className="p-4">
            <div className="flex justify-between items-center mb-4">
              {editing ? (
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  className="text-xl font-semibold bg-gray-50 rounded-xl px-3 py-2 w-48 border-none focus:outline-none focus:ring-0"
                />
              ) : (
                <h1 className="text-xl font-semibold">{food.name}</h1>
              )}
              <span className="text-sm text-gray-500">02:37</span>
            </div>

            {/* Quantity Selector */}
            <div className="flex justify-end gap-4 items-center mb-4">
              <button 
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="w-7 h-7 rounded-full border border-gray-200 flex items-center justify-center text-sm"
              >
                -
              </button>
              <span className="text-base w-4 text-center">{quantity}</span>
              <button
                onClick={() => setQuantity(quantity + 1)}
                className="w-7 h-7 rounded-full border border-gray-200 flex items-center justify-center text-sm"
              >
                +
              </button>
            </div>

            {/* Calories */}
            <div className="flex items-center gap-2 mb-1">
              <div className="w-5 h-5">
                <svg viewBox="0 0 24 24" className="w-full h-full text-orange-500">
                  <path fill="currentColor" d="M11.5,20L16.36,10.27H13V4L8.64,13.73H12V20H11.5M12,2A10,10 0 0,1 22,12A10,10 0 0,1 12,22A10,10 0 0,1 2,12A10,10 0 0,1 12,2Z" />
                </svg>
              </div>
              {editing ? (
                <input
                  type="number"
                  name="calories"
                  value={formData.calories}
                  onChange={handleChange}
                  className="text-lg font-semibold bg-gray-50 rounded-xl px-3 py-1 w-20 border-none focus:outline-none focus:ring-0"
                />
              ) : (
                <span className="text-lg font-semibold">{food.calories * quantity}</span>
              )}
              <span className="text-gray-500">Calories</span>
            </div>

            {/* Macros Grid */}
            <div className="grid grid-cols-3 gap-3 my-4">
              <div className="bg-gray-50 rounded-2xl p-3">
                <div className="flex items-center gap-1 mb-1">
                  <div className="w-4 h-4">
                    <svg viewBox="0 0 24 24" className="w-full h-full text-rose-500">
                      <path fill="currentColor" d="M8.5,3A5.5,5.5 0 0,1 14,8.5C14,9.83 13.53,11.05 12.74,12H21V21H12V12.74C11.05,13.53 9.83,14 8.5,14A5.5,5.5 0 0,1 3,8.5A5.5,5.5 0 0,1 8.5,3Z" />
                    </svg>
                  </div>
                  <span className="text-xs text-gray-500">Protein</span>
                </div>
                {editing ? (
                  <input
                    type="number"
                    name="protein"
                    value={formData.protein}
                    onChange={handleChange}
                    className="text-base font-medium bg-white rounded-xl px-3 py-1 w-16 border-none focus:outline-none focus:ring-0"
                  />
                ) : (
                  <div className="text-base font-medium">{food.protein * quantity}g</div>
                )}
              </div>

              <div className="bg-gray-50 rounded-2xl p-3">
                <div className="flex items-center gap-1 mb-1">
                  <div className="w-4 h-4">
                    <svg viewBox="0 0 24 24" className="w-full h-full text-amber-500">
                      <path fill="currentColor" d="M12,2L6.5,11H17.5L12,2M12,5.84L13.93,9H10.06L12,5.84M17.5,13C15.17,13 13.89,14.98 14.33,17.23L22,13V17L14.33,21.23C13.89,23.48 15.17,25.46 17.5,25.46A3.5,3.5 0 0,0 21,21.96V17.46A3.5,3.5 0 0,0 17.5,13M6.5,13A3.5,3.5 0 0,0 3,16.46V20.96A3.5,3.5 0 0,0 6.5,24.46C8.83,24.46 10.11,22.48 9.67,20.23L2,24V20L9.67,15.77C10.11,13.52 8.83,13 6.5,13Z" />
                    </svg>
                  </div>
                  <span className="text-xs text-gray-500">Carbs</span>
                </div>
                {editing ? (
                  <input
                    type="number"
                    name="carbs"
                    value={formData.carbs}
                    onChange={handleChange}
                    className="text-base font-medium bg-white rounded-xl px-3 py-1 w-16 border-none focus:outline-none focus:ring-0"
                  />
                ) : (
                  <div className="text-base font-medium">{food.carbs * quantity}g</div>
                )}
              </div>

              <div className="bg-gray-50 rounded-2xl p-3">
                <div className="flex items-center gap-1 mb-1">
                  <div className="w-4 h-4">
                    <svg viewBox="0 0 24 24" className="w-full h-full text-blue-500">
                      <path fill="currentColor" d="M19.5,9.5C19.5,13.09 16.09,16.5 12.5,16.5H11.5A3,3 0 0,1 8.5,13.5A3,3 0 0,1 11.5,10.5H13A2,2 0 0,0 15,8.5A2,2 0 0,0 13,6.5H7.5A3,3 0 0,0 4.5,9.5A3,3 0 0,0 7.5,12.5H9A2,2 0 0,1 11,14.5A2,2 0 0,1 9,16.5H3" />
                    </svg>
                  </div>
                  <span className="text-xs text-gray-500">Fats</span>
                </div>
                {editing ? (
                  <input
                    type="number"
                    name="fat"
                    value={formData.fat}
                    onChange={handleChange}
                    className="text-base font-medium bg-white rounded-xl px-3 py-1 w-16 border-none focus:outline-none focus:ring-0"
                  />
                ) : (
                  <div className="text-base font-medium">{food.fat * quantity}g</div>
                )}
              </div>
            </div>

            {/* Health Score */}
            <div>
              <div className="flex items-center gap-1 mb-1">
                <div className="w-4 h-4">
                  <svg viewBox="0 0 24 24" className="w-full h-full text-rose-500">
                    <path fill="currentColor" d="M12,21.35L10.55,20.03C5.4,15.36 2,12.27 2,8.5C2,5.41 4.42,3 7.5,3C9.24,3 10.91,3.81 12,5.08C13.09,3.81 14.76,3 16.5,3C19.58,3 22,5.41 22,8.5C22,12.27 18.6,15.36 13.45,20.03L12,21.35Z" />
                  </svg>
                </div>
                <span className="text-sm text-gray-500">Health Score</span>
                <span className="text-sm font-medium ml-auto">6/10</span>
              </div>
              <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-rose-500 rounded-full"
                  initial={{ width: 0 }}
                  animate={{ width: '60%' }}
                  transition={{ duration: 1 }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Buttons */}
      <div className="fixed bottom-0 left-0 right-0 p-3 bg-[#F8F9FA]">
        <div className="flex gap-2">
          <Button
            variant="outline"
            className="flex-1 h-12 bg-white border-gray-200 hover:bg-gray-50 rounded-2xl"
            onClick={() => setEditing(!editing)}
          >
            {editing ? "Cancel" : "Fix Results"}
          </Button>
          <Button
            className="flex-1 h-12 bg-black text-white hover:bg-black/90 rounded-2xl"
            onClick={() => {
              if (editing) {
                onSave?.(formData);
                setEditing(false);
                toast({
                  title: "Changes Saved",
                  description: "Your changes have been saved successfully."
                });
              } else {
                toast({
                  title: "Added to Diet",
                  description: "Your meal has been added to your daily diet plan."
                });
              }
            }}
          >
            {editing ? "Save Changes" : "Save"}
          </Button>
        </div>
      </div>
    </div>
  );
}