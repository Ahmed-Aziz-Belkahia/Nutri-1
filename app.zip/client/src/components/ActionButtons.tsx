import { Button } from "@/components/ui/button";
import { Bookmark, Search, Camera } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";
import ScannerUI from "./ScannerUI";

interface ActionButtonsProps {
  onClose: () => void;
}

export default function ActionButtons({ onClose }: ActionButtonsProps) {
  const [showScanner, setShowScanner] = useState(false);
  const [, setLocation] = useLocation();

  if (showScanner) {
    return <ScannerUI onClose={() => {
      setShowScanner(false);
      onClose();
    }} />;
  }

  return (
    <div className="absolute inset-0 bg-black/20 z-50 flex items-end">
      <div className="bg-white w-full px-4 pb-8 pt-4 space-y-4 rounded-t-[2rem]">
        <div className="grid grid-cols-2 gap-4">
          <Button 
            variant="outline" 
            className="flex flex-col items-center justify-center h-[108px] border border-gray-100 rounded-[1.25rem] bg-white hover:bg-gray-50"
            onClick={() => {
              onClose();
              setLocation("/recipes");
            }}
          >
            <Camera className="h-6 w-6" />
            <span className="mt-3 text-sm font-normal">Recipe Ideas</span>
          </Button>
          <Button 
            variant="outline" 
            className="flex flex-col items-center justify-center h-[108px] border border-gray-100 rounded-[1.25rem] bg-white hover:bg-gray-50"
            onClick={() => {
              // TODO: Implement saved foods
              onClose();
            }}
          >
            <Bookmark className="h-6 w-6" />
            <span className="mt-3 text-sm font-normal">Saved foods</span>
          </Button>
          <Button 
            variant="outline" 
            className="flex flex-col items-center justify-center h-[108px] border border-gray-100 rounded-[1.25rem] bg-white hover:bg-gray-50"
            onClick={() => {
              // TODO: Implement food database search
              onClose();
            }}
          >
            <Search className="h-6 w-6" />
            <span className="mt-3 text-sm font-normal">Food Database</span>
          </Button>
          <Button 
            variant="outline" 
            className="flex flex-col items-center justify-center h-[108px] border border-gray-100 rounded-[1.25rem] bg-white hover:bg-gray-50"
            onClick={() => {
              setShowScanner(true);
            }}
          >
            <Camera className="h-6 w-6" />
            <span className="mt-3 text-sm font-normal">Scan food</span>
          </Button>
        </div>
        
        <Button 
          variant="default" 
          className="w-full bg-black text-white rounded-2xl h-12 mt-6"
          onClick={onClose}
        >
          Cancel
        </Button>
      </div>
    </div>
  );
}
