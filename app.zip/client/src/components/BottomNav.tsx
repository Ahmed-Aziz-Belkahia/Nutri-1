import { Home, Plus, ChartBar, Settings } from "lucide-react";
import { useLocation, Link } from "wouter";
import { motion } from "framer-motion";

export default function BottomNav() {
  const [location] = useLocation();

  const navItems = [
    { icon: Home, label: "Overview", href: "/dashboard" },
    { icon: ChartBar, label: "Progress", href: "/progress" },
    { icon: Settings, label: "Settings", href: "/settings" }
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50">
      {/* Background with blur effect */}
      <div className="absolute inset-0 bg-white/90 backdrop-blur-lg border-t border-zinc-100/80" />

      {/* Safe area padding for mobile */}
      <div className="relative max-w-lg mx-auto px-6 py-3 flex items-center justify-between">
        {navItems.map(({ icon: Icon, label, href }) => (
          <Link
            key={href}
            href={href}
            className="flex-1"
          >
            <div className="flex flex-col items-center justify-center group">
              <div 
                className={`relative p-2.5 rounded-xl transition-all duration-300 ease-out
                  ${location === href 
                    ? "text-[#0CC5BA]" 
                    : "text-gray-400 hover:text-[#0CC5BA]"
                  }`}
              >
                {/* Active state indicator */}
                {location === href && (
                  <span className="absolute inset-0 bg-[#0CC5BA]/10 rounded-xl" />
                )}

                <Icon className={`h-6 w-6 transition-transform duration-300 ease-out relative z-10
                  ${location === href ? "scale-110" : "group-hover:scale-105"}`} 
                />
              </div>

              <span className={`text-xs font-medium transition-colors duration-300 mt-0.5
                ${location === href 
                  ? "bg-gradient-to-br from-[#0CC5BA] via-[#0CBACC] to-[#0C9CCC] bg-clip-text text-transparent" 
                  : "text-gray-400 group-hover:text-[#0CC5BA]"
                }`}>
                {label}
              </span>
            </div>
          </Link>
        ))}

        {/* Add Food Button */}
        <Link href="/create-recipe" className="flex-1">
          <div className="flex flex-col items-center justify-center -mt-8">
            <motion.div 
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="w-14 h-14 rounded-full bg-gradient-to-br from-[#0CC5BA] to-blue-500
                flex items-center justify-center shadow-lg shadow-[#0CC5BA]/20
                transition-all duration-300 ease-out
                border-4 border-white">
              <Plus className="h-7 w-7 text-white" />
            </motion.div>
            <span className="text-xs font-medium mt-1 bg-gradient-to-br from-[#0CC5BA] via-[#0CBACC] to-[#0C9CCC] bg-clip-text text-transparent">Add</span>
          </div>
        </Link>
      </div>

      {/* iOS safe area padding */}
      <div className="h-[env(safe-area-inset-bottom,0px)]" />
    </nav>
  );
}