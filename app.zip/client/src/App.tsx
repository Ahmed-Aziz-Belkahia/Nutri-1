import { Switch, Route, useLocation } from "wouter";
import { Loader2 } from "lucide-react";
import { useUser } from "./hooks/use-user";
import AuthPage from "./pages/AuthPage";
import Dashboard from "./pages/Dashboard";
import LandingPage from "./pages/LandingPage";
import Progress from "./pages/Progress";
import Settings from "./pages/Settings";
import AddFood from "./pages/AddFood";
import FoodDetail from "./pages/FoodDetail";
import Recipes from "./pages/Recipes";
import CreateRecipe from "./pages/CreateRecipe";
import RecipeScanner from "./pages/RecipeScanner";
import { useEffect } from "react";
import BottomNav from "./components/BottomNav";
import TransformationQuiz from "./pages/Onboarding/TransformationQuiz";

// Redirect component for navigation
function NavigationRedirect({ to }: { to: string }) {
  const [, navigate] = useLocation();
  useEffect(() => {
    navigate(to);
  }, [to, navigate]);
  return null;
}

function App() {
  const { user, isLoading } = useUser();
  const [location] = useLocation();

  // Show loading state while checking auth
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-[#0CC5BA]" />
      </div>
    );
  }

  // Show bottom nav only on main app pages when authenticated
  const showBottomNav = user && ['/dashboard', '/progress', '/recipes', '/settings'].includes(location);

  return (
    <div className="min-h-screen">
      <Switch>
        {user ? (
          // Protected routes for authenticated users
          <>
            <Route path="/dashboard" component={Dashboard} />
            <Route path="/progress" component={Progress} />
            <Route path="/settings" component={Settings} />
            <Route path="/add-food" component={AddFood} />
            <Route path="/food/:id" component={FoodDetail} />
            <Route path="/recipes" component={Recipes} />
            <Route path="/create-recipe" component={CreateRecipe} />
            <Route path="/recipe-scanner" component={RecipeScanner} />

            {/* Redirect authenticated users to dashboard */}
            <Route path="/">
              <NavigationRedirect to="/dashboard" />
            </Route>
          </>
        ) : (
          // Public routes for unauthenticated users
          <>
            <Route path="/auth" component={AuthPage} />
            <Route path="/" component={LandingPage} />
            <Route path="/quiz" component={TransformationQuiz} />

            {/* Redirect unknown routes to landing */}
            <Route>
              <NavigationRedirect to="/" />
            </Route>
          </>
        )}
      </Switch>

      {/* Show bottom navigation for authenticated users on main pages */}
      {showBottomNav && <BottomNav />}
    </div>
  );
}

export default App;