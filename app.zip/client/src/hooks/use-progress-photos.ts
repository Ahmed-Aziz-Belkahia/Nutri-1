import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import type { ProgressPhoto } from "@db/schema";

export function useProgressPhotos() {
  const queryClient = useQueryClient();

  const { data: photos = [], isLoading } = useQuery<ProgressPhoto[]>({
    queryKey: ["/api/progress-photos"],
    refetchInterval: 5000, // Refetch every 5 seconds
    staleTime: 0, // Consider data stale immediately to allow instant updates
  });

  const addPhoto = useMutation({
    mutationFn: async (data: { photoUrl: string; caption?: string; type: 'latest' | 'favorite' | 'first' }) => {
      const res = await fetch("/api/progress-photos", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });

      if (!res.ok) {
        throw new Error(await res.text());
      }

      return res.json();
    },
    onSuccess: () => {
      // Invalidate the query to trigger an immediate refresh
      queryClient.invalidateQueries({ queryKey: ["/api/progress-photos"] });
    },
  });

  return {
    photos,
    isLoading,
    addPhoto: addPhoto.mutateAsync,
    isAddingPhoto: addPhoto.isPending,
  };
}