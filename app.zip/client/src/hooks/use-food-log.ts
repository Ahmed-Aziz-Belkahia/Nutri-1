import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import type { FoodLog } from "@db/schema";

interface FoodLogResponse {
  logs: FoodLog[];
  totals: {
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
  };
}

export function useFoodLog() {
  const queryClient = useQueryClient();

  const { data: foodLogData, isLoading: isLoadingLogs } = useQuery<FoodLogResponse>({
    queryKey: ["/api/food-logs"],
    staleTime: 0, // Always fetch fresh data
  });

  const { data: activeDays } = useQuery<string[]>({
    queryKey: ["/api/food-logs/active-days"],
    staleTime: 0,
  });

  const addFoodMutation = useMutation({
    mutationFn: async (food: Omit<FoodLog, "id" | "date" | "userId">) => {
      const res = await fetch("/api/food-logs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(food),
        credentials: "include",
      });

      if (!res.ok) {
        throw new Error(await res.text());
      }

      return res.json();
    },
    onSettled: () => {
      // Use Promise.all to ensure both queries are invalidated together
      return Promise.all([
        queryClient.invalidateQueries({ queryKey: ["/api/food-logs"] }),
        queryClient.invalidateQueries({ queryKey: ["/api/food-logs/active-days"] })
      ]);
    },
  });

  const deleteFoodMutation = useMutation({
    mutationFn: async (foodId: number) => {
      const res = await fetch(`/api/food-logs/${foodId}`, {
        method: "DELETE",
        credentials: "include",
      });

      if (!res.ok) {
        throw new Error(await res.text());
      }

      return res.json();
    },
    onSettled: () => {
      return Promise.all([
        queryClient.invalidateQueries({ queryKey: ["/api/food-logs"] }),
        queryClient.invalidateQueries({ queryKey: ["/api/food-logs/active-days"] })
      ]);
    },
  });

  return {
    foodLogs: foodLogData?.logs || [],
    todayTotals: foodLogData?.totals || { calories: 0, protein: 0, carbs: 0, fat: 0 },
    isLoadingLogs,
    activeDays: activeDays || [],
    addFood: addFoodMutation.mutateAsync,
    deleteFood: deleteFoodMutation.mutateAsync,
  };
}