import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import type { WeightLog } from "@db/schema";

export function useWeightLogs() {
  const queryClient = useQueryClient();

  const { data: weightLogs = [], isLoading } = useQuery<WeightLog[]>({
    queryKey: ["/api/weight-logs"],
  });

  const addWeightLog = useMutation({
    mutationFn: async (data: { weight: number; note?: string }) => {
      const res = await fetch("/api/weight-logs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });

      if (!res.ok) {
        throw new Error(await res.text());
      }

      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/weight-logs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user/profile"] });
    },
  });

  return {
    weightLogs,
    isLoading,
    addWeightLog: addWeightLog.mutateAsync,
    isAddingWeight: addWeightLog.isPending,
  };
}
