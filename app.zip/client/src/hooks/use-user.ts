import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';

type RequestResult = {
  ok: true;
} | {
  ok: false;
  message: string;
};

type RegisterData = {
  email: string;
  password: string;
  profile?: {
    weight: number;
    goalWeight: number;
    activityLevel: string;
    weightGoal: string;
    calorieGoal: number;
    proteinGoal: number;
    carbsGoal: number;
    fatGoal: number;
  };
};

type ProfileData = {
  weight: number;
  goalWeight: number;
  activityLevel: string;
  weightGoal: string;
  calorieGoal: number;
  proteinGoal: number;
  carbsGoal: number;
  fatGoal: number;
};

async function handleRequest(
  url: string,
  method: string,
  data?: any
): Promise<RequestResult> {
  try {
    const response = await fetch(url, {
      method,
      headers: {
        'Content-Type': 'application/json',
      },
      body: data ? JSON.stringify(data) : undefined,
      credentials: "include",
    });

    if (!response.ok) {
      const errorData = await response.json();
      return { 
        ok: false, 
        message: errorData.details || errorData.error || 'Operation failed'
      };
    }

    return { ok: true };
  } catch (e: any) {
    return { 
      ok: false, 
      message: e.toString()
    };
  }
}

export function useUser() {
  const queryClient = useQueryClient();

  const { data: user, error, isLoading } = useQuery({
    queryKey: ['/api/user'],
    queryFn: async () => {
      try {
        const res = await fetch("/api/user", {
          credentials: "include",
        });

        if (res.status === 401) {
          return null;
        }

        if (!res.ok) {
          throw new Error(await res.text());
        }

        return res.json();
      } catch (error) {
        console.error('Error fetching user:', error);
        return null;
      }
    },
    retry: false,
    staleTime: Infinity,
  });

  const loginMutation = useMutation({
    mutationFn: async (credentials: { email: string; password: string }) => {
      return handleRequest("/api/login", "POST", credentials);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/user'] });
    },
  });

  const registerMutation = useMutation({
    mutationFn: async (data: RegisterData) => {
      return handleRequest("/api/register", "POST", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/user'] });
    },
  });

  const updateProfileMutation = useMutation({
    mutationFn: async (profile: ProfileData) => {
      return handleRequest("/api/user/profile", "PUT", profile);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/user/profile'] });
    },
  });

  const logoutMutation = useMutation({
    mutationFn: async () => {
      return handleRequest("/api/logout", "POST");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/user'] });
    },
  });

  return {
    user,
    isLoading,
    error,
    login: loginMutation.mutateAsync,
    register: registerMutation.mutateAsync,
    updateProfile: updateProfileMutation.mutateAsync,
    logout: logoutMutation.mutateAsync,
  };
}